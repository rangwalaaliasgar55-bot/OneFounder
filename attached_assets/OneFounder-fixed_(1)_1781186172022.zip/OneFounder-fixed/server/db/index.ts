import 'dotenv/config'
import { neon } from '@neondatabase/serverless'
import { drizzle } from 'drizzle-orm/neon-http'
import * as schema from './schema'

const DATABASE_URL = process.env.NEON_DATABASE_URL || process.env.DATABASE_URL

if (!DATABASE_URL) {
  // In production/runtime this is a fatal error. During CI type-checking with
  // a stub DATABASE_URL env var the stub value is used so this never throws.
  throw new Error(
    'NEON_DATABASE_URL or DATABASE_URL environment variable is required. ' +
    'Add it to your .env file or deployment environment.'
  )
}

const sql = neon(DATABASE_URL)

export const db = drizzle(sql, { schema })
export { schema }
