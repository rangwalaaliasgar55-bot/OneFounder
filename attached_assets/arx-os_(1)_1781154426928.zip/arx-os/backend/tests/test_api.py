"""
ARX OS — Backend Tests
"""
import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker

from app.main import app
from app.db.session import Base, get_db
from app.core.security import create_access_token

# ─── Test Database ───────────────────────────────────────────────────────────

TEST_DB_URL = "sqlite+aiosqlite:///:memory:"

test_engine = create_async_engine(TEST_DB_URL, echo=False)
TestSessionLocal = async_sessionmaker(
    test_engine, class_=AsyncSession, expire_on_commit=False
)


async def override_get_db():
    async with TestSessionLocal() as session:
        yield session


app.dependency_overrides[get_db] = override_get_db


@pytest_asyncio.fixture(scope="session", autouse=True)
async def create_tables():
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


@pytest_asyncio.fixture
async def client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


@pytest_asyncio.fixture
async def auth_headers(client: AsyncClient):
    """Register + login and return auth headers."""
    await client.post("/api/v1/auth/register", json={
        "username": "testuser",
        "password": "testpass123",
        "display_name": "Test User",
    })
    resp = await client.post("/api/v1/auth/login", json={
        "username": "testuser",
        "password": "testpass123",
    })
    token = resp.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


# ─── Auth Tests ──────────────────────────────────────────────────────────────

class TestAuth:
    @pytest.mark.asyncio
    async def test_register(self, client: AsyncClient):
        resp = await client.post("/api/v1/auth/register", json={
            "username": "newuser_test",
            "password": "securepass",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "access_token" in data
        assert "refresh_token" in data
        assert data["username"] == "newuser_test"

    @pytest.mark.asyncio
    async def test_register_duplicate_username(self, client: AsyncClient):
        await client.post("/api/v1/auth/register", json={
            "username": "dupuser", "password": "pass"
        })
        resp = await client.post("/api/v1/auth/register", json={
            "username": "dupuser", "password": "pass"
        })
        assert resp.status_code == 400

    @pytest.mark.asyncio
    async def test_login_success(self, client: AsyncClient):
        await client.post("/api/v1/auth/register", json={
            "username": "logintest", "password": "mypassword"
        })
        resp = await client.post("/api/v1/auth/login", json={
            "username": "logintest", "password": "mypassword"
        })
        assert resp.status_code == 200
        assert "access_token" in resp.json()

    @pytest.mark.asyncio
    async def test_login_wrong_password(self, client: AsyncClient):
        await client.post("/api/v1/auth/register", json={
            "username": "wrongpass", "password": "correct"
        })
        resp = await client.post("/api/v1/auth/login", json={
            "username": "wrongpass", "password": "wrong"
        })
        assert resp.status_code == 401

    @pytest.mark.asyncio
    async def test_get_me(self, client: AsyncClient, auth_headers: dict):
        resp = await client.get("/api/v1/auth/me", headers=auth_headers)
        assert resp.status_code == 200
        assert resp.json()["username"] == "testuser"

    @pytest.mark.asyncio
    async def test_unauthorized_without_token(self, client: AsyncClient):
        resp = await client.get("/api/v1/auth/me")
        assert resp.status_code == 403


# ─── Goals Tests ─────────────────────────────────────────────────────────────

class TestGoals:
    @pytest.mark.asyncio
    async def test_create_goal(self, client: AsyncClient, auth_headers: dict):
        resp = await client.post("/api/v1/goals", headers=auth_headers, json={
            "title": "Learn Python", "category": "learning", "priority": 4
        })
        assert resp.status_code == 200
        assert "id" in resp.json()

    @pytest.mark.asyncio
    async def test_list_goals(self, client: AsyncClient, auth_headers: dict):
        await client.post("/api/v1/goals", headers=auth_headers, json={
            "title": "Goal A", "category": "personal"
        })
        resp = await client.get("/api/v1/goals", headers=auth_headers)
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    @pytest.mark.asyncio
    async def test_update_goal(self, client: AsyncClient, auth_headers: dict):
        create = await client.post("/api/v1/goals", headers=auth_headers, json={
            "title": "Update Me", "category": "career"
        })
        goal_id = create.json()["id"]
        resp = await client.patch(
            f"/api/v1/goals/{goal_id}",
            headers=auth_headers,
            json={"progress": 50.0, "priority": 5},
        )
        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_delete_goal(self, client: AsyncClient, auth_headers: dict):
        create = await client.post("/api/v1/goals", headers=auth_headers, json={
            "title": "Delete Me"
        })
        goal_id = create.json()["id"]
        resp = await client.delete(f"/api/v1/goals/{goal_id}", headers=auth_headers)
        assert resp.status_code == 200


# ─── Habits Tests ────────────────────────────────────────────────────────────

class TestHabits:
    @pytest.mark.asyncio
    async def test_create_habit(self, client: AsyncClient, auth_headers: dict):
        resp = await client.post("/api/v1/habits", headers=auth_headers, json={
            "title": "Morning Run", "frequency": "daily", "target_count": 1
        })
        assert resp.status_code == 200
        assert "id" in resp.json()

    @pytest.mark.asyncio
    async def test_list_habits(self, client: AsyncClient, auth_headers: dict):
        resp = await client.get("/api/v1/habits", headers=auth_headers)
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    @pytest.mark.asyncio
    async def test_today_status(self, client: AsyncClient, auth_headers: dict):
        resp = await client.get("/api/v1/habits/today", headers=auth_headers)
        assert resp.status_code == 200


# ─── Projects Tests ──────────────────────────────────────────────────────────

class TestProjects:
    @pytest.mark.asyncio
    async def test_create_project(self, client: AsyncClient, auth_headers: dict):
        resp = await client.post("/api/v1/projects", headers=auth_headers, json={
            "title": "ARX OS", "description": "Build the OS"
        })
        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_create_task(self, client: AsyncClient, auth_headers: dict):
        resp = await client.post("/api/v1/projects/tasks", headers=auth_headers, json={
            "title": "Write tests", "priority": "high"
        })
        assert resp.status_code == 200


# ─── Learning Tests ──────────────────────────────────────────────────────────

class TestLearning:
    @pytest.mark.asyncio
    async def test_create_item(self, client: AsyncClient, auth_headers: dict):
        resp = await client.post("/api/v1/learning", headers=auth_headers, json={
            "title": "Clean Code", "resource_type": "book", "author": "Robert Martin"
        })
        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_log_session(self, client: AsyncClient, auth_headers: dict):
        resp = await client.post("/api/v1/learning/sessions", headers=auth_headers, json={
            "duration_minutes": 45, "topic": "Chapter 1", "focus_score": 8.5
        })
        assert resp.status_code == 200


# ─── Health Check ────────────────────────────────────────────────────────────

class TestHealth:
    @pytest.mark.asyncio
    async def test_health(self, client: AsyncClient):
        resp = await client.get("/api/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"

    @pytest.mark.asyncio
    async def test_docs(self, client: AsyncClient):
        resp = await client.get("/api/docs")
        assert resp.status_code == 200
