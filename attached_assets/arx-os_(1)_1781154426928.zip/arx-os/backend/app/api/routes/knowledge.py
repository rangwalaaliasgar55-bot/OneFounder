"""
ARX OS — Knowledge Graph Routes
"""
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel

from app.db.session import get_db
from app.db.models import KnowledgeNode, KnowledgeEdge
from app.core.security import get_current_user_id

router = APIRouter()


class NodeCreate(BaseModel):
    title: str
    content: Optional[str] = None
    node_type: str = "concept"
    tags: Optional[List[str]] = []
    properties: Optional[dict] = {}


class EdgeCreate(BaseModel):
    source_id: str
    target_id: str
    relationship: str
    weight: float = 1.0


@router.get("/nodes")
async def list_nodes(
    node_type: Optional[str] = None,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    query = select(KnowledgeNode).where(KnowledgeNode.user_id == user_id)
    if node_type:
        query = query.where(KnowledgeNode.node_type == node_type)
    result = await db.execute(query)
    nodes = result.scalars().all()
    return [{"id": n.id, "title": n.title, "node_type": n.node_type, "tags": n.tags} for n in nodes]


@router.post("/nodes")
async def create_node(
    req: NodeCreate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    node = KnowledgeNode(user_id=user_id, **req.model_dump())
    db.add(node)
    await db.commit()
    await db.refresh(node)
    return {"id": node.id, "title": node.title}


@router.post("/edges")
async def create_edge(
    req: EdgeCreate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    edge = KnowledgeEdge(user_id=user_id, **req.model_dump())
    db.add(edge)
    await db.commit()
    await db.refresh(edge)
    return {"id": edge.id}


@router.get("/graph")
async def get_full_graph(
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    nodes_result = await db.execute(
        select(KnowledgeNode).where(KnowledgeNode.user_id == user_id)
    )
    edges_result = await db.execute(
        select(KnowledgeEdge).where(KnowledgeEdge.user_id == user_id)
    )
    nodes = nodes_result.scalars().all()
    edges = edges_result.scalars().all()

    return {
        "nodes": [
            {"id": n.id, "title": n.title, "type": n.node_type, "tags": n.tags}
            for n in nodes
        ],
        "edges": [
            {"source": e.source_id, "target": e.target_id,
             "relationship": e.relationship, "weight": e.weight}
            for e in edges
        ],
    }


@router.post("/search")
async def semantic_search_knowledge(
    query: str,
    limit: int = 10,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    from app.memory.manager import MemoryManager
    from app.db.models import MemoryType
    manager = MemoryManager(db)
    results = await manager.search(
        user_id=user_id,
        query=query,
        memory_types=[MemoryType.SEMANTIC],
        limit=limit,
    )
    return {"results": results}
