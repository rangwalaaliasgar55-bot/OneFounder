"""
ARX OS — Memory Routes
"""
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel

from app.db.session import get_db
from app.db.models import MemoryType
from app.memory.manager import MemoryManager
from app.core.security import get_current_user_id

router = APIRouter()


class MemoryCreate(BaseModel):
    content: str
    memory_type: MemoryType = MemoryType.SEMANTIC
    title: Optional[str] = None
    importance: float = 0.5
    tags: Optional[List[str]] = None


class MemorySearch(BaseModel):
    query: str
    memory_types: Optional[List[MemoryType]] = None
    limit: int = 10


@router.post("/search")
async def search_memories(
    req: MemorySearch,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    manager = MemoryManager(db)
    results = await manager.search(
        user_id=user_id,
        query=req.query,
        memory_types=req.memory_types,
        limit=req.limit,
    )
    return {"results": results, "count": len(results)}


@router.post("")
async def create_memory(
    req: MemoryCreate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    manager = MemoryManager(db)
    memory = await manager.store(
        user_id=user_id,
        content=req.content,
        memory_type=req.memory_type,
        title=req.title,
        source="manual",
        importance=req.importance,
        tags=req.tags,
    )
    return {"id": memory.id, "type": memory.memory_type}


@router.get("")
async def list_memories(
    memory_type: Optional[MemoryType] = None,
    limit: int = 50,
    offset: int = 0,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    manager = MemoryManager(db)
    memories = await manager.list_memories(user_id, memory_type, limit, offset)
    return [
        {
            "id": m.id,
            "memory_type": m.memory_type,
            "title": m.title,
            "content": m.content[:500],
            "importance": m.importance,
            "tags": m.tags,
            "source": m.source,
            "access_count": m.access_count,
            "created_at": m.created_at,
        }
        for m in memories
    ]


@router.delete("/{memory_id}")
async def delete_memory(
    memory_id: str,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    manager = MemoryManager(db)
    deleted = await manager.delete_memory(user_id, memory_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Memory not found")
    return {"status": "deleted"}


@router.get("/stats")
async def memory_stats(
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    """Get memory system statistics."""
    from sqlalchemy import func, select
    from app.db.models import Memory
    from app.memory.vector_store import get_collection_stats
    from app.core.config import settings

    type_counts = await db.execute(
        select(Memory.memory_type, func.count(Memory.id))
        .where(Memory.user_id == user_id)
        .group_by(Memory.memory_type)
    )
    counts = {row[0]: row[1] for row in type_counts.all()}

    return {
        "total_memories": sum(counts.values()),
        "by_type": counts,
        "collections": {
            "episodic": settings.COLLECTION_EPISODIC,
            "semantic": settings.COLLECTION_SEMANTIC,
            "knowledge": settings.COLLECTION_KNOWLEDGE,
            "reflection": settings.COLLECTION_REFLECTION,
        }
    }
