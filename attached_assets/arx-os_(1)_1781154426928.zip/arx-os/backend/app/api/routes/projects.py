"""
ARX OS — Projects Routes
"""
from typing import Optional, List
from datetime import date
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel

from app.db.session import get_db
from app.db.models import Project, Task, ProjectStatus, TaskStatus, TaskPriority
from app.core.security import get_current_user_id

router = APIRouter()


# ─── Schemas ─────────────────────────────────────────────────────────────────

class ProjectCreate(BaseModel):
    title: str
    description: Optional[str] = None
    goal_id: Optional[str] = None
    category: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    tags: Optional[List[str]] = []


class ProjectUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[ProjectStatus] = None
    progress: Optional[float] = None
    end_date: Optional[date] = None


class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    project_id: Optional[str] = None
    parent_id: Optional[str] = None
    priority: TaskPriority = TaskPriority.MEDIUM
    due_date: Optional[str] = None
    estimated_minutes: Optional[int] = None
    tags: Optional[List[str]] = []


class TaskUpdate(BaseModel):
    title: Optional[str] = None
    status: Optional[TaskStatus] = None
    priority: Optional[TaskPriority] = None
    due_date: Optional[str] = None
    actual_minutes: Optional[int] = None


# ─── Projects ────────────────────────────────────────────────────────────────

@router.get("")
async def list_projects(
    status: Optional[ProjectStatus] = None,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    query = select(Project).where(Project.user_id == user_id)
    if status:
        query = query.where(Project.status == status)
    query = query.order_by(Project.updated_at.desc())

    result = await db.execute(query)
    projects = result.scalars().all()

    # Get task counts per project
    task_counts = await db.execute(
        select(Task.project_id, func.count(Task.id).label("total"),
               func.sum((Task.status == TaskStatus.DONE).cast(func.Integer())).label("done"))
        .where(Task.project_id.in_([p.id for p in projects]))
        .group_by(Task.project_id)
    )
    counts = {row[0]: {"total": row[1], "done": row[2] or 0} for row in task_counts.all()}

    return [
        {
            "id": p.id,
            "title": p.title,
            "description": p.description,
            "status": p.status,
            "category": p.category,
            "progress": p.progress,
            "goal_id": p.goal_id,
            "start_date": p.start_date,
            "end_date": p.end_date,
            "tags": p.tags,
            "task_count": counts.get(p.id, {}).get("total", 0),
            "tasks_done": counts.get(p.id, {}).get("done", 0),
            "created_at": p.created_at,
            "updated_at": p.updated_at,
        }
        for p in projects
    ]


@router.post("")
async def create_project(
    req: ProjectCreate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    project = Project(user_id=user_id, **req.model_dump())
    db.add(project)
    await db.commit()
    await db.refresh(project)
    return {"id": project.id, "title": project.title, "status": project.status}


@router.get("/{project_id}")
async def get_project(
    project_id: str,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Project).where(Project.id == project_id, Project.user_id == user_id)
    )
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    tasks_result = await db.execute(
        select(Task).where(Task.project_id == project_id).order_by(Task.created_at)
    )
    tasks = tasks_result.scalars().all()

    return {
        "id": project.id,
        "title": project.title,
        "description": project.description,
        "status": project.status,
        "category": project.category,
        "progress": project.progress,
        "goal_id": project.goal_id,
        "start_date": project.start_date,
        "end_date": project.end_date,
        "tags": project.tags,
        "created_at": project.created_at,
        "tasks": [
            {
                "id": t.id,
                "title": t.title,
                "status": t.status,
                "priority": t.priority,
                "due_date": t.due_date,
                "estimated_minutes": t.estimated_minutes,
                "parent_id": t.parent_id,
            }
            for t in tasks
        ],
    }


@router.patch("/{project_id}")
async def update_project(
    project_id: str,
    req: ProjectUpdate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Project).where(Project.id == project_id, Project.user_id == user_id)
    )
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="Not found")
    for k, v in req.model_dump(exclude_none=True).items():
        setattr(project, k, v)
    await db.commit()
    return {"id": project.id, "status": "updated"}


@router.delete("/{project_id}")
async def delete_project(
    project_id: str,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Project).where(Project.id == project_id, Project.user_id == user_id)
    )
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="Not found")
    await db.delete(project)
    await db.commit()
    return {"status": "deleted"}


# ─── Tasks ───────────────────────────────────────────────────────────────────

@router.get("/tasks/inbox")
async def get_task_inbox(
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    """All tasks not tied to a project, or all incomplete tasks."""
    result = await db.execute(
        select(Task)
        .where(Task.user_id == user_id, Task.status != TaskStatus.DONE)
        .order_by(Task.priority.desc(), Task.created_at)
        .limit(100)
    )
    tasks = result.scalars().all()
    return [
        {
            "id": t.id,
            "title": t.title,
            "status": t.status,
            "priority": t.priority,
            "project_id": t.project_id,
            "due_date": t.due_date,
            "estimated_minutes": t.estimated_minutes,
            "created_at": t.created_at,
        }
        for t in tasks
    ]


@router.post("/tasks")
async def create_task(
    req: TaskCreate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    task = Task(user_id=user_id, **req.model_dump())
    db.add(task)

    # Update project progress if linked
    if req.project_id:
        await _recalculate_project_progress(db, req.project_id)

    await db.commit()
    await db.refresh(task)
    return {"id": task.id, "title": task.title, "status": task.status}


@router.patch("/tasks/{task_id}")
async def update_task(
    task_id: str,
    req: TaskUpdate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    from datetime import datetime, timezone
    result = await db.execute(
        select(Task).where(Task.id == task_id, Task.user_id == user_id)
    )
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    for k, v in req.model_dump(exclude_none=True).items():
        setattr(task, k, v)

    if req.status == TaskStatus.DONE and not task.completed_at:
        task.completed_at = datetime.now(timezone.utc)

    if task.project_id:
        await _recalculate_project_progress(db, task.project_id)

    await db.commit()
    return {"id": task.id, "status": task.status}


@router.delete("/tasks/{task_id}")
async def delete_task(
    task_id: str,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Task).where(Task.id == task_id, Task.user_id == user_id)
    )
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Not found")
    project_id = task.project_id
    await db.delete(task)
    if project_id:
        await _recalculate_project_progress(db, project_id)
    await db.commit()
    return {"status": "deleted"}


async def _recalculate_project_progress(db: AsyncSession, project_id: str):
    result = await db.execute(
        select(func.count(Task.id).label("total"),
               func.sum((Task.status == TaskStatus.DONE).cast(func.Integer())).label("done"))
        .where(Task.project_id == project_id)
    )
    row = result.one()
    total, done = row[0] or 0, row[1] or 0
    progress = (done / total * 100) if total > 0 else 0.0

    await db.execute(
        Project.__table__.update()
        .where(Project.id == project_id)
        .values(progress=progress)
    )
