"""
ARX OS — Learning Routes
"""
from typing import Optional, List
from datetime import date, datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel

from app.db.session import get_db
from app.db.models import LearningItem, LearningSession, LearningStatus
from app.core.security import get_current_user_id

router = APIRouter()


class LearningItemCreate(BaseModel):
    title: str
    description: Optional[str] = None
    resource_type: str = "book"  # book, course, video, article, podcast
    resource_url: Optional[str] = None
    author: Optional[str] = None
    category: Optional[str] = None
    tags: Optional[List[str]] = []
    total_pages: Optional[int] = None
    duration_hours: Optional[float] = None


class LearningItemUpdate(BaseModel):
    status: Optional[LearningStatus] = None
    progress: Optional[float] = None
    current_page: Optional[int] = None
    hours_spent: Optional[float] = None
    rating: Optional[int] = None
    notes: Optional[str] = None
    key_insights: Optional[List[str]] = None


class SessionCreate(BaseModel):
    learning_item_id: Optional[str] = None
    duration_minutes: int
    topic: Optional[str] = None
    notes: Optional[str] = None
    focus_score: Optional[float] = None
    session_date: Optional[date] = None


@router.get("")
async def list_learning_items(
    status: Optional[LearningStatus] = None,
    resource_type: Optional[str] = None,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    query = select(LearningItem).where(LearningItem.user_id == user_id)
    if status:
        query = query.where(LearningItem.status == status)
    if resource_type:
        query = query.where(LearningItem.resource_type == resource_type)
    query = query.order_by(LearningItem.updated_at.desc())

    result = await db.execute(query)
    items = result.scalars().all()
    return [
        {
            "id": i.id,
            "title": i.title,
            "resource_type": i.resource_type,
            "author": i.author,
            "category": i.category,
            "status": i.status,
            "progress": i.progress,
            "hours_spent": i.hours_spent,
            "rating": i.rating,
            "tags": i.tags,
            "started_at": i.started_at,
            "completed_at": i.completed_at,
            "created_at": i.created_at,
        }
        for i in items
    ]


@router.post("")
async def create_learning_item(
    req: LearningItemCreate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    item = LearningItem(user_id=user_id, **req.model_dump())
    db.add(item)
    await db.commit()
    await db.refresh(item)
    return {"id": item.id, "title": item.title}


@router.patch("/{item_id}")
async def update_learning_item(
    item_id: str,
    req: LearningItemUpdate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(LearningItem).where(LearningItem.id == item_id, LearningItem.user_id == user_id)
    )
    item = result.scalar_one_or_none()
    if not item:
        raise HTTPException(status_code=404, detail="Not found")

    updates = req.model_dump(exclude_none=True)
    for k, v in updates.items():
        setattr(item, k, v)

    if req.status == LearningStatus.IN_PROGRESS and not item.started_at:
        item.started_at = datetime.now(timezone.utc)
    if req.status == LearningStatus.COMPLETED and not item.completed_at:
        item.completed_at = datetime.now(timezone.utc)
        item.progress = 100.0

    await db.commit()
    return {"id": item.id, "status": "updated"}


@router.get("/{item_id}")
async def get_learning_item(
    item_id: str,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(LearningItem).where(LearningItem.id == item_id, LearningItem.user_id == user_id)
    )
    item = result.scalar_one_or_none()
    if not item:
        raise HTTPException(status_code=404, detail="Not found")

    sessions_result = await db.execute(
        select(LearningSession)
        .where(LearningSession.learning_item_id == item_id)
        .order_by(LearningSession.session_date.desc())
        .limit(20)
    )
    sessions = sessions_result.scalars().all()

    return {
        "id": item.id,
        "title": item.title,
        "description": item.description,
        "resource_type": item.resource_type,
        "resource_url": item.resource_url,
        "author": item.author,
        "category": item.category,
        "status": item.status,
        "progress": item.progress,
        "total_pages": item.total_pages,
        "current_page": item.current_page,
        "duration_hours": item.duration_hours,
        "hours_spent": item.hours_spent,
        "rating": item.rating,
        "key_insights": item.key_insights,
        "notes": item.notes,
        "tags": item.tags,
        "started_at": item.started_at,
        "completed_at": item.completed_at,
        "recent_sessions": [
            {
                "id": s.id,
                "duration_minutes": s.duration_minutes,
                "topic": s.topic,
                "focus_score": s.focus_score,
                "session_date": s.session_date,
            }
            for s in sessions
        ],
    }


@router.post("/sessions")
async def log_learning_session(
    req: SessionCreate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    session = LearningSession(
        user_id=user_id,
        session_date=req.session_date or date.today(),
        **req.model_dump(exclude={"session_date"}),
    )
    db.add(session)

    # Update hours spent on item
    if req.learning_item_id:
        item_result = await db.execute(
            select(LearningItem).where(
                LearningItem.id == req.learning_item_id,
                LearningItem.user_id == user_id,
            )
        )
        item = item_result.scalar_one_or_none()
        if item:
            item.hours_spent += req.duration_minutes / 60

    await db.commit()
    await db.refresh(session)
    return {"id": session.id, "duration_minutes": session.duration_minutes}


@router.get("/stats/overview")
async def learning_stats(
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    total_items = await db.execute(
        select(func.count(LearningItem.id)).where(LearningItem.user_id == user_id)
    )
    completed_items = await db.execute(
        select(func.count(LearningItem.id)).where(
            LearningItem.user_id == user_id,
            LearningItem.status == LearningStatus.COMPLETED,
        )
    )
    total_hours = await db.execute(
        select(func.sum(LearningSession.duration_minutes))
        .where(LearningSession.user_id == user_id)
    )
    return {
        "total_items": total_items.scalar() or 0,
        "completed_items": completed_items.scalar() or 0,
        "total_hours_spent": round((total_hours.scalar() or 0) / 60, 1),
    }


@router.post("/{item_id}/generate-path")
async def generate_learning_path(
    item_id: str,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    """Use AI to generate a structured learning path for this item."""
    from app.agents.career_agent import LearningAgent
    result = await db.execute(
        select(LearningItem).where(LearningItem.id == item_id, LearningItem.user_id == user_id)
    )
    item = result.scalar_one_or_none()
    if not item:
        raise HTTPException(status_code=404, detail="Not found")

    agent = LearningAgent(db, user_id)
    path = await agent.create_learning_path(
        topic=item.title,
        current_level="beginner",
        target_level="proficient",
        timeline_weeks=8,
    )
    return path
