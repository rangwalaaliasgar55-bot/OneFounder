"""
ARX OS — Analytics Routes
"""
from typing import Optional
from datetime import date, datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_

from app.db.session import get_db
from app.db.models import (
    Goal, GoalStatus, Habit, HabitLog, Task, TaskStatus,
    LearningSession, LearningItem, LearningStatus,
    Reflection, DailyAnalytics, Report, Conversation, Message,
)
from app.core.security import get_current_user_id

router = APIRouter()


async def compute_date_range_metrics(db: AsyncSession, user_id: str, start: date, end: date) -> dict:
    """Core metrics computation for any date range."""

    # Goals
    active_goals = await db.execute(
        select(func.count(Goal.id)).where(
            Goal.user_id == user_id, Goal.status == GoalStatus.ACTIVE
        )
    )
    completed_goals = await db.execute(
        select(func.count(Goal.id)).where(
            Goal.user_id == user_id, Goal.status == GoalStatus.COMPLETED,
            Goal.completed_at >= datetime.combine(start, datetime.min.time()),
            Goal.completed_at <= datetime.combine(end, datetime.max.time()),
        )
    )
    avg_goal_progress = await db.execute(
        select(func.avg(Goal.progress)).where(
            Goal.user_id == user_id, Goal.status == GoalStatus.ACTIVE
        )
    )

    # Tasks
    tasks_completed = await db.execute(
        select(func.count(Task.id)).where(
            Task.user_id == user_id, Task.status == TaskStatus.DONE,
            Task.completed_at >= datetime.combine(start, datetime.min.time()),
            Task.completed_at <= datetime.combine(end, datetime.max.time()),
        )
    )
    tasks_created = await db.execute(
        select(func.count(Task.id)).where(
            Task.user_id == user_id,
            Task.created_at >= datetime.combine(start, datetime.min.time()),
            Task.created_at <= datetime.combine(end, datetime.max.time()),
        )
    )

    # Habits
    habit_logs = await db.execute(
        select(func.count(HabitLog.id)).where(
            HabitLog.user_id == user_id,
            HabitLog.completed_date >= start,
            HabitLog.completed_date <= end,
        )
    )
    active_habits = await db.execute(
        select(func.count(Habit.id)).where(Habit.user_id == user_id, Habit.is_active == True)
    )

    # Learning
    learning_minutes = await db.execute(
        select(func.sum(LearningSession.duration_minutes)).where(
            LearningSession.user_id == user_id,
            LearningSession.session_date >= start,
            LearningSession.session_date <= end,
        )
    )
    learning_completed = await db.execute(
        select(func.count(LearningItem.id)).where(
            LearningItem.user_id == user_id,
            LearningItem.status == LearningStatus.COMPLETED,
            LearningItem.completed_at >= datetime.combine(start, datetime.min.time()),
            LearningItem.completed_at <= datetime.combine(end, datetime.max.time()),
        )
    )

    # Conversations
    conversations_count = await db.execute(
        select(func.count(Conversation.id)).where(
            Conversation.user_id == user_id,
            Conversation.created_at >= datetime.combine(start, datetime.min.time()),
            Conversation.created_at <= datetime.combine(end, datetime.max.time()),
        )
    )

    days_in_range = (end - start).days + 1
    habit_log_count = habit_logs.scalar() or 0
    active_habit_count = active_habits.scalar() or 0
    possible_habit_completions = active_habit_count * days_in_range
    habit_adherence = (
        round(habit_log_count / possible_habit_completions * 100, 1)
        if possible_habit_completions > 0 else 0
    )

    return {
        "period": {"start": str(start), "end": str(end), "days": days_in_range},
        "goals": {
            "active": active_goals.scalar() or 0,
            "completed_in_period": completed_goals.scalar() or 0,
            "avg_progress": round(avg_goal_progress.scalar() or 0, 1),
        },
        "tasks": {
            "completed": tasks_completed.scalar() or 0,
            "created": tasks_created.scalar() or 0,
            "completion_rate": round(
                (tasks_completed.scalar() or 0) / max(tasks_created.scalar() or 1, 1) * 100, 1
            ),
        },
        "habits": {
            "active": active_habit_count,
            "completions": habit_log_count,
            "adherence_pct": habit_adherence,
        },
        "learning": {
            "minutes": learning_minutes.scalar() or 0,
            "hours": round((learning_minutes.scalar() or 0) / 60, 1),
            "items_completed": learning_completed.scalar() or 0,
        },
        "conversations": conversations_count.scalar() or 0,
    }


@router.get("/dashboard")
async def get_dashboard_metrics(
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    """Real-time dashboard metrics."""
    today = date.today()
    week_start = today - timedelta(days=today.weekday())

    today_metrics = await compute_date_range_metrics(db, user_id, today, today)
    week_metrics = await compute_date_range_metrics(db, user_id, week_start, today)

    # Recent activity
    recent_tasks = await db.execute(
        select(Task).where(
            Task.user_id == user_id, Task.status == TaskStatus.DONE
        ).order_by(Task.completed_at.desc()).limit(5)
    )

    # Streaks
    habits_result = await db.execute(
        select(Habit).where(Habit.user_id == user_id, Habit.is_active == True)
        .order_by(Habit.streak_current.desc()).limit(3)
    )
    top_streaks = habits_result.scalars().all()

    return {
        "today": today_metrics,
        "this_week": week_metrics,
        "top_streaks": [
            {"title": h.title, "streak": h.streak_current, "color": h.color}
            for h in top_streaks
        ],
        "recent_completions": [
            {"title": t.title, "completed_at": t.completed_at}
            for t in recent_tasks.scalars().all()
        ],
    }


@router.get("/weekly")
async def get_weekly_report(
    week_offset: int = 0,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    today = date.today()
    week_start = today - timedelta(days=today.weekday()) - timedelta(weeks=week_offset)
    week_end = week_start + timedelta(days=6)

    metrics = await compute_date_range_metrics(db, user_id, week_start, week_end)

    # Habit daily breakdown
    daily_habits = await db.execute(
        select(HabitLog.completed_date, func.count(HabitLog.id))
        .where(
            HabitLog.user_id == user_id,
            HabitLog.completed_date >= week_start,
            HabitLog.completed_date <= week_end,
        )
        .group_by(HabitLog.completed_date)
    )
    habit_by_day = {str(row[0]): row[1] for row in daily_habits.all()}

    # Learning by day
    daily_learning = await db.execute(
        select(LearningSession.session_date, func.sum(LearningSession.duration_minutes))
        .where(
            LearningSession.user_id == user_id,
            LearningSession.session_date >= week_start,
            LearningSession.session_date <= week_end,
        )
        .group_by(LearningSession.session_date)
    )
    learning_by_day = {str(row[0]): row[1] for row in daily_learning.all()}

    return {
        **metrics,
        "habit_by_day": habit_by_day,
        "learning_by_day": learning_by_day,
    }


@router.get("/monthly")
async def get_monthly_report(
    month_offset: int = 0,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    from calendar import monthrange
    today = date.today()
    year = today.year
    month = today.month - month_offset
    while month <= 0:
        month += 12
        year -= 1

    _, last_day = monthrange(year, month)
    start = date(year, month, 1)
    end = date(year, month, last_day)

    metrics = await compute_date_range_metrics(db, user_id, start, end)

    # Goal progress trend
    goals_result = await db.execute(
        select(Goal).where(Goal.user_id == user_id, Goal.status == GoalStatus.ACTIVE)
    )
    goals = goals_result.scalars().all()

    return {
        **metrics,
        "month": f"{year}-{month:02d}",
        "goals_snapshot": [
            {"title": g.title, "progress": g.progress, "category": g.category}
            for g in goals[:10]
        ],
    }


@router.get("/quarterly")
async def get_quarterly_report(
    quarter_offset: int = 0,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    today = date.today()
    current_q = (today.month - 1) // 3
    year = today.year
    q = current_q - quarter_offset
    while q < 0:
        q += 4
        year -= 1

    month_start = q * 3 + 1
    start = date(year, month_start, 1)
    from calendar import monthrange
    end_month = month_start + 2
    _, last_day = monthrange(year, end_month)
    end = date(year, end_month, last_day)

    metrics = await compute_date_range_metrics(db, user_id, start, end)
    return {**metrics, "quarter": f"Q{q+1} {year}"}


@router.post("/generate-ai-report")
async def generate_ai_report(
    report_type: str = "weekly",
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
    background_tasks: BackgroundTasks = None,
):
    """Generate an AI-written narrative report."""
    from app.services.ollama_service import get_ollama
    import json

    today = date.today()
    if report_type == "weekly":
        start = today - timedelta(days=7)
    elif report_type == "monthly":
        start = today - timedelta(days=30)
    else:
        start = today - timedelta(days=7)

    metrics = await compute_date_range_metrics(db, user_id, start, today)
    ollama = get_ollama()

    ai_report = await ollama.chat(
        messages=[
            {"role": "user", "content": f"""Generate a personal {report_type} review report.

Metrics:
{json.dumps(metrics, indent=2)}

Write a comprehensive, insightful narrative report that:
1. Celebrates wins honestly
2. Identifies patterns
3. Calls out areas needing attention
4. Gives specific recommendations
5. Sets the tone for the next period

Be direct, personal, and motivating. Format with clear sections."""}
        ],
        system="You are ARX, a personal AI coach generating a private review report for the user.",
    )

    # Store as a Report record
    report = Report(
        user_id=user_id,
        report_type=report_type,
        period_start=start,
        period_end=today,
        title=f"{report_type.capitalize()} Report — {today.strftime('%B %d, %Y')}",
        content=metrics,
        ai_summary=ai_report,
    )
    db.add(report)
    await db.commit()
    await db.refresh(report)

    return {
        "id": report.id,
        "title": report.title,
        "ai_summary": ai_report,
        "metrics": metrics,
    }


@router.get("/reports")
async def list_reports(
    report_type: Optional[str] = None,
    limit: int = 20,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    query = select(Report).where(Report.user_id == user_id)
    if report_type:
        query = query.where(Report.report_type == report_type)
    query = query.order_by(Report.created_at.desc()).limit(limit)

    result = await db.execute(query)
    reports = result.scalars().all()
    return [
        {
            "id": r.id,
            "report_type": r.report_type,
            "title": r.title,
            "period_start": r.period_start,
            "period_end": r.period_end,
            "ai_summary": r.ai_summary,
            "created_at": r.created_at,
        }
        for r in reports
    ]
