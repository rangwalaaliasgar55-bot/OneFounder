"""
ARX OS — Habits Routes
"""
from typing import Optional, List
from datetime import date, datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, func
from pydantic import BaseModel

from app.db.session import get_db
from app.db.models import Habit, HabitLog, HabitFrequency
from app.core.security import get_current_user_id

router = APIRouter()


class HabitCreate(BaseModel):
    title: str
    description: Optional[str] = None
    frequency: HabitFrequency = HabitFrequency.DAILY
    target_count: int = 1
    unit: Optional[str] = None
    color: Optional[str] = "#6366f1"
    icon: Optional[str] = "check"
    category: Optional[str] = None
    cue: Optional[str] = None
    reward: Optional[str] = None


class HabitLogCreate(BaseModel):
    completed_date: date
    count: float = 1.0
    notes: Optional[str] = None
    mood: Optional[int] = None


@router.get("")
async def list_habits(
    active_only: bool = True,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    query = select(Habit).where(Habit.user_id == user_id)
    if active_only:
        query = query.where(Habit.is_active == True)
    query = query.order_by(Habit.created_at)

    result = await db.execute(query)
    habits = result.scalars().all()
    return [
        {
            "id": h.id,
            "title": h.title,
            "description": h.description,
            "frequency": h.frequency,
            "target_count": h.target_count,
            "unit": h.unit,
            "color": h.color,
            "icon": h.icon,
            "is_active": h.is_active,
            "streak_current": h.streak_current,
            "streak_best": h.streak_best,
            "total_completions": h.total_completions,
            "category": h.category,
            "created_at": h.created_at,
        }
        for h in habits
    ]


@router.post("")
async def create_habit(
    req: HabitCreate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    habit = Habit(user_id=user_id, start_date=date.today(), **req.model_dump())
    db.add(habit)
    await db.commit()
    await db.refresh(habit)
    return {"id": habit.id, "title": habit.title}


@router.post("/{habit_id}/log")
async def log_habit(
    habit_id: str,
    req: HabitLogCreate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Habit).where(Habit.id == habit_id, Habit.user_id == user_id)
    )
    habit = result.scalar_one_or_none()
    if not habit:
        raise HTTPException(status_code=404, detail="Habit not found")

    # Check if already logged today
    existing = await db.execute(
        select(HabitLog).where(
            HabitLog.habit_id == habit_id,
            HabitLog.completed_date == req.completed_date,
        )
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Already logged for this date")

    log = HabitLog(
        habit_id=habit_id,
        user_id=user_id,
        completed_date=req.completed_date,
        count=req.count,
        notes=req.notes,
        mood=req.mood,
    )
    db.add(log)

    # Update habit stats
    habit.total_completions += 1
    habit.streak_current = await _calculate_streak(db, habit_id, req.completed_date)
    if habit.streak_current > habit.streak_best:
        habit.streak_best = habit.streak_current

    await db.commit()
    return {"id": log.id, "streak": habit.streak_current}


@router.get("/today")
async def get_today_status(
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    """Get all habits with today's completion status."""
    today = date.today()

    habits_result = await db.execute(
        select(Habit).where(Habit.user_id == user_id, Habit.is_active == True)
    )
    habits = habits_result.scalars().all()

    logs_result = await db.execute(
        select(HabitLog).where(
            HabitLog.user_id == user_id,
            HabitLog.completed_date == today,
        )
    )
    today_logs = {log.habit_id: log for log in logs_result.scalars().all()}

    return [
        {
            "id": h.id,
            "title": h.title,
            "color": h.color,
            "icon": h.icon,
            "target_count": h.target_count,
            "unit": h.unit,
            "streak_current": h.streak_current,
            "completed_today": h.id in today_logs,
            "today_count": today_logs[h.id].count if h.id in today_logs else 0,
        }
        for h in habits
    ]


@router.get("/heatmap")
async def get_habit_heatmap(
    habit_id: str,
    days: int = 90,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    """Get habit completion heatmap data for the last N days."""
    from_date = date.today() - timedelta(days=days)

    result = await db.execute(
        select(HabitLog).where(
            HabitLog.habit_id == habit_id,
            HabitLog.user_id == user_id,
            HabitLog.completed_date >= from_date,
        ).order_by(HabitLog.completed_date)
    )
    logs = result.scalars().all()
    return [{"date": str(l.completed_date), "count": l.count} for l in logs]


async def _calculate_streak(db: AsyncSession, habit_id: str, through_date: date) -> int:
    """Calculate the current streak for a habit."""
    result = await db.execute(
        select(HabitLog.completed_date)
        .where(HabitLog.habit_id == habit_id)
        .order_by(HabitLog.completed_date.desc())
        .limit(366)
    )
    logged_dates = {row[0] for row in result.all()}

    streak = 0
    check_date = through_date
    while check_date in logged_dates:
        streak += 1
        check_date = check_date - timedelta(days=1)
    return streak
