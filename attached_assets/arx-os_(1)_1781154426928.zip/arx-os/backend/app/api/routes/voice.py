"""
ARX OS — Voice Routes
Speech-to-Text (Whisper) + Text-to-Speech (Piper)
"""
import os
import io
import uuid
import tempfile
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from fastapi.responses import FileResponse
from pydantic import BaseModel

from app.core.security import get_current_user_id
from app.core.config import settings

router = APIRouter()


class TTSRequest(BaseModel):
    text: str
    voice: str = "en_US-lessac-medium"


@router.post("/transcribe")
async def transcribe_audio(
    audio: UploadFile = File(...),
    user_id: str = Depends(get_current_user_id),
):
    """
    Transcribe audio using OpenAI Whisper (local).
    Accepts: wav, mp3, webm, ogg, m4a
    Returns: transcribed text
    """
    import whisper

    allowed_types = {"audio/wav", "audio/mpeg", "audio/webm", "audio/ogg", "audio/mp4"}
    if audio.content_type and audio.content_type not in allowed_types:
        raise HTTPException(status_code=400, detail=f"Unsupported audio type: {audio.content_type}")

    # Save to temp file
    suffix = Path(audio.filename or "audio.wav").suffix or ".wav"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        content = await audio.read()
        tmp.write(content)
        tmp_path = tmp.name

    try:
        model = whisper.load_model(settings.WHISPER_MODEL)
        result = model.transcribe(tmp_path, language="en")
        text = result["text"].strip()
        return {
            "text": text,
            "language": result.get("language", "en"),
            "segments": len(result.get("segments", [])),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Transcription failed: {str(e)}")
    finally:
        os.unlink(tmp_path)


@router.post("/synthesize")
async def synthesize_speech(
    req: TTSRequest,
    user_id: str = Depends(get_current_user_id),
):
    """
    Synthesize speech using Piper TTS (local).
    Returns audio file.
    """
    if not req.text.strip():
        raise HTTPException(status_code=400, detail="Text cannot be empty")

    if len(req.text) > 2000:
        raise HTTPException(status_code=400, detail="Text too long (max 2000 chars)")

    audio_dir = Path(settings.AUDIO_DIR)
    audio_dir.mkdir(parents=True, exist_ok=True)
    output_path = audio_dir / f"{uuid.uuid4()}.wav"

    try:
        import subprocess
        # Piper TTS: echo "text" | piper --model model.onnx --output_file out.wav
        process = subprocess.run(
            ["piper", "--model", req.voice, "--output_file", str(output_path)],
            input=req.text.encode(),
            capture_output=True,
            timeout=30,
        )
        if process.returncode != 0:
            # Fallback: return error (Piper may not be installed)
            raise HTTPException(
                status_code=503,
                detail="TTS service unavailable. Install Piper TTS."
            )
        return FileResponse(
            str(output_path),
            media_type="audio/wav",
            filename="speech.wav",
        )
    except FileNotFoundError:
        raise HTTPException(
            status_code=503,
            detail="Piper TTS not installed. Run: pip install piper-tts"
        )
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=504, detail="TTS synthesis timed out")
