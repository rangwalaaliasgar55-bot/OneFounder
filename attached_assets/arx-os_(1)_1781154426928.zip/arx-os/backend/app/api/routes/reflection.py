"""
ARX OS — Reflection Routes
"""
from typing import Optional, List
from datetime import date
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel

from app.db.session import get_db
from app.db.models import Reflection, DecisionJournal
from app.core.security import get_current_user_id

router = APIRouter()


class ReflectionCreate(BaseModel):
    reflection_type: str = "daily"  # daily, weekly, monthly, quarterly, annual, decision
    title: Optional[str] = None
    content: str
    mood: Optional[int] = None
    energy: Optional[int] = None
    wins: Optional[List[str]] = []
    challenges: Optional[List[str]] = []
    lessons: Optional[List[str]] = []
    gratitude: Optional[List[str]] = []
    next_actions: Optional[List[str]] = []
    tags: Optional[List[str]] = []
    reflection_date: Optional[date] = None


class DecisionCreate(BaseModel):
    title: str
    context: str
    options_considered: Optional[List[str]] = []
    decision_made: str
    rationale: Optional[str] = None
    expected_outcome: Optional[str] = None
    confidence_level: Optional[int] = None
    reversibility: Optional[str] = "partially"
    follow_up_date: Optional[date] = None
    tags: Optional[List[str]] = []


@router.get("")
async def list_reflections(
    reflection_type: Optional[str] = None,
    limit: int = 30,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    query = select(Reflection).where(Reflection.user_id == user_id)
    if reflection_type:
        query = query.where(Reflection.reflection_type == reflection_type)
    query = query.order_by(Reflection.reflection_date.desc()).limit(limit)
    result = await db.execute(query)
    reflections = result.scalars().all()
    return [
        {
            "id": r.id, "reflection_type": r.reflection_type,
            "title": r.title, "content": r.content[:300],
            "mood": r.mood, "energy": r.energy,
            "wins": r.wins, "lessons": r.lessons,
            "reflection_date": r.reflection_date,
            "created_at": r.created_at,
        }
        for r in reflections
    ]


@router.post("")
async def create_reflection(
    req: ReflectionCreate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    reflection = Reflection(
        user_id=user_id,
        reflection_date=req.reflection_date or date.today(),
        **req.model_dump(exclude={"reflection_date"}),
    )
    db.add(reflection)

    # Store in memory system
    from app.memory.manager import MemoryManager
    from app.db.models import MemoryType
    manager = MemoryManager(db)
    await manager.store_insight(
        user_id=user_id,
        insight=f"{req.reflection_type} reflection: {req.content[:500]}",
        insight_type=req.reflection_type,
    )

    await db.commit()
    await db.refresh(reflection)
    return {"id": reflection.id}


@router.get("/{reflection_id}")
async def get_reflection(
    reflection_id: str,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Reflection).where(
            Reflection.id == reflection_id, Reflection.user_id == user_id
        )
    )
    reflection = result.scalar_one_or_none()
    if not reflection:
        raise HTTPException(status_code=404, detail="Not found")
    return {
        "id": reflection.id,
        "reflection_type": reflection.reflection_type,
        "title": reflection.title,
        "content": reflection.content,
        "mood": reflection.mood,
        "energy": reflection.energy,
        "wins": reflection.wins,
        "challenges": reflection.challenges,
        "lessons": reflection.lessons,
        "gratitude": reflection.gratitude,
        "next_actions": reflection.next_actions,
        "ai_insights": reflection.ai_insights,
        "reflection_date": reflection.reflection_date,
    }


@router.post("/{reflection_id}/ai-insights")
async def generate_insights(
    reflection_id: str,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    """Generate AI insights for a reflection."""
    from app.services.ollama_service import get_ollama
    import json
    result = await db.execute(
        select(Reflection).where(
            Reflection.id == reflection_id, Reflection.user_id == user_id
        )
    )
    reflection = result.scalar_one_or_none()
    if not reflection:
        raise HTTPException(status_code=404, detail="Not found")

    ollama = get_ollama()
    insights = await ollama.chat(
        messages=[{"role": "user", "content": f"""
Reflection ({reflection.reflection_type}):
{reflection.content}

Wins: {json.dumps(reflection.wins)}
Challenges: {json.dumps(reflection.challenges)}
Lessons: {json.dumps(reflection.lessons)}

Provide 3-5 deep, personalized insights that help the user grow.
Point out patterns, blind spots, and opportunities they may have missed."""}],
        system="You are ARX Reflect, a wise and caring personal coach helping with deep self-reflection.",
    )

    reflection.ai_insights = insights
    await db.commit()
    return {"ai_insights": insights}


# ─── Decisions ───────────────────────────────────────────────────────────────

@router.get("/decisions/list")
async def list_decisions(
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(DecisionJournal).where(DecisionJournal.user_id == user_id)
        .order_by(DecisionJournal.created_at.desc()).limit(50)
    )
    decisions = result.scalars().all()
    return [
        {
            "id": d.id, "title": d.title,
            "decision_made": d.decision_made,
            "confidence_level": d.confidence_level,
            "reversibility": d.reversibility,
            "follow_up_date": d.follow_up_date,
            "created_at": d.created_at,
        }
        for d in decisions
    ]


@router.post("/decisions")
async def create_decision(
    req: DecisionCreate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    decision = DecisionJournal(user_id=user_id, **req.model_dump())
    db.add(decision)
    await db.commit()
    await db.refresh(decision)
    return {"id": decision.id}


@router.patch("/decisions/{decision_id}/outcome")
async def update_decision_outcome(
    decision_id: str,
    actual_outcome: str,
    lesson_learned: Optional[str] = None,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(DecisionJournal).where(
            DecisionJournal.id == decision_id, DecisionJournal.user_id == user_id
        )
    )
    decision = result.scalar_one_or_none()
    if not decision:
        raise HTTPException(status_code=404, detail="Not found")
    decision.actual_outcome = actual_outcome
    decision.lesson_learned = lesson_learned
    await db.commit()
    return {"status": "updated"}
