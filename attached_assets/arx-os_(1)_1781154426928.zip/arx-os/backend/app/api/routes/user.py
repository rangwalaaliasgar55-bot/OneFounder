"""
ARX OS — User Profile Routes
"""
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel

from app.db.session import get_db
from app.db.models import User, UserProfile
from app.core.security import get_current_user_id

router = APIRouter()


class ProfileUpdate(BaseModel):
    bio: Optional[str] = None
    occupation: Optional[str] = None
    location: Optional[str] = None
    display_name: Optional[str] = None
    skills: Optional[List[dict]] = None
    strengths: Optional[List[str]] = None
    weaknesses: Optional[List[str]] = None
    interests: Optional[List[str]] = None
    values: Optional[List[str]] = None
    career_stage: Optional[str] = None
    industry: Optional[str] = None
    experience_years: Optional[int] = None
    career_goals: Optional[List[str]] = None
    current_focus: Optional[str] = None
    work_style: Optional[dict] = None


@router.get("/profile")
async def get_profile(
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    user_result = await db.execute(select(User).where(User.id == user_id))
    user = user_result.scalar_one_or_none()

    profile_result = await db.execute(
        select(UserProfile).where(UserProfile.user_id == user_id)
    )
    profile = profile_result.scalar_one_or_none()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    return {
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "display_name": user.display_name,
        "avatar_url": user.avatar_url,
        "timezone": user.timezone,
        "created_at": user.created_at,
        "profile": {
            "bio": profile.bio if profile else None,
            "occupation": profile.occupation if profile else None,
            "location": profile.location if profile else None,
            "skills": profile.skills if profile else [],
            "strengths": profile.strengths if profile else [],
            "weaknesses": profile.weaknesses if profile else [],
            "interests": profile.interests if profile else [],
            "values": profile.values if profile else [],
            "career_stage": profile.career_stage if profile else None,
            "industry": profile.industry if profile else None,
            "experience_years": profile.experience_years if profile else None,
            "career_goals": profile.career_goals if profile else [],
            "current_focus": profile.current_focus if profile else None,
            "work_style": profile.work_style if profile else {},
            "productivity_score": profile.productivity_score if profile else 0.0,
            "learning_velocity": profile.learning_velocity if profile else 0.0,
            "goal_completion_rate": profile.goal_completion_rate if profile else 0.0,
            "habit_adherence_rate": profile.habit_adherence_rate if profile else 0.0,
            "ai_observations": profile.ai_observations if profile else [],
        } if profile else {},
    }


@router.patch("/profile")
async def update_profile(
    req: ProfileUpdate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    profile_result = await db.execute(
        select(UserProfile).where(UserProfile.user_id == user_id)
    )
    profile = profile_result.scalar_one_or_none()

    if not profile:
        profile = UserProfile(user_id=user_id)
        db.add(profile)

    for k, v in req.model_dump(exclude_none=True).items():
        if k == "display_name":
            user_result = await db.execute(select(User).where(User.id == user_id))
            user = user_result.scalar_one_or_none()
            if user:
                user.display_name = v
        else:
            setattr(profile, k, v)

    await db.commit()
    return {"status": "updated"}


@router.post("/profile/analyze")
async def analyze_profile_with_ai(
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    """Ask AI to analyze the user profile and generate observations."""
    from app.services.ollama_service import get_ollama
    import json

    profile_result = await db.execute(
        select(UserProfile).where(UserProfile.user_id == user_id)
    )
    profile = profile_result.scalar_one_or_none()
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")

    ollama = get_ollama()
    analysis = await ollama.generate_json(
        prompt=f"""Analyze this user profile and generate insights:
{json.dumps({
    "occupation": profile.occupation,
    "skills": profile.skills,
    "career_goals": profile.career_goals,
    "interests": profile.interests,
    "current_focus": profile.current_focus,
    "strengths": profile.strengths,
    "weaknesses": profile.weaknesses,
}, indent=2)}

Return JSON:
{{
  "observations": ["observation1", "observation2"],
  "strengths_identified": [],
  "growth_areas": [],
  "alignment_score": 8.5,
  "recommendations": []
}}""",
    )

    if "observations" in analysis:
        profile.ai_observations = analysis.get("observations", [])
        await db.commit()

    return analysis
