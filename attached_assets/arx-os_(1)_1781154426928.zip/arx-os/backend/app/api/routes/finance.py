"""
ARX OS — Finance Routes
"""
from typing import Optional, List
from datetime import date
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel

from app.db.session import get_db
from app.db.models import FinanceEntry
from app.core.security import get_current_user_id

router = APIRouter()


class FinanceCreate(BaseModel):
    entry_type: str  # income, expense, investment, saving
    category: str
    amount: float
    currency: str = "USD"
    description: Optional[str] = None
    tags: Optional[List[str]] = []
    entry_date: Optional[date] = None


@router.get("")
async def list_entries(
    entry_type: Optional[str] = None,
    limit: int = 100,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    query = select(FinanceEntry).where(FinanceEntry.user_id == user_id)
    if entry_type:
        query = query.where(FinanceEntry.entry_type == entry_type)
    query = query.order_by(FinanceEntry.entry_date.desc()).limit(limit)
    result = await db.execute(query)
    entries = result.scalars().all()
    return [
        {
            "id": e.id, "entry_type": e.entry_type, "category": e.category,
            "amount": e.amount, "currency": e.currency,
            "description": e.description, "entry_date": e.entry_date,
        }
        for e in entries
    ]


@router.post("")
async def create_entry(
    req: FinanceCreate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    entry = FinanceEntry(
        user_id=user_id,
        entry_date=req.entry_date or date.today(),
        **req.model_dump(exclude={"entry_date"}),
    )
    db.add(entry)
    await db.commit()
    await db.refresh(entry)
    return {"id": entry.id}


@router.get("/summary")
async def finance_summary(
    year: Optional[int] = None,
    month: Optional[int] = None,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    query = select(
        FinanceEntry.entry_type,
        func.sum(FinanceEntry.amount).label("total")
    ).where(FinanceEntry.user_id == user_id)

    if year:
        query = query.where(func.extract("year", FinanceEntry.entry_date) == year)
    if month:
        query = query.where(func.extract("month", FinanceEntry.entry_date) == month)

    query = query.group_by(FinanceEntry.entry_type)
    result = await db.execute(query)
    by_type = {row[0]: row[1] for row in result.all()}

    income = by_type.get("income", 0)
    expenses = by_type.get("expense", 0)
    return {
        "income": income, "expenses": expenses,
        "net": income - expenses,
        "savings": by_type.get("saving", 0),
        "investments": by_type.get("investment", 0),
        "by_type": by_type,
    }
