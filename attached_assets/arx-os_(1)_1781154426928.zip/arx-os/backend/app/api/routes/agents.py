"""
ARX OS — Agents Routes
Direct invocation of specialized agents.
"""
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from typing import Optional, List

from app.db.session import get_db
from app.core.security import get_current_user_id

router = APIRouter()


class AgentRequest(BaseModel):
    prompt: str
    context: Optional[str] = None


class CareerAnalysisRequest(BaseModel):
    target_role: str
    current_skills: Optional[List[str]] = []


class StartupRequest(BaseModel):
    idea: str
    context: Optional[str] = None


class WeekPlanRequest(BaseModel):
    goals: Optional[List[str]] = []
    focus_areas: Optional[List[str]] = []


@router.post("/career/skill-gap")
async def career_skill_gap(
    req: CareerAnalysisRequest,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    from app.agents.career_agent import CareerAgent
    agent = CareerAgent(db, user_id)
    result = await agent.analyze_skill_gaps(req.current_skills, req.target_role)
    return result


@router.post("/career/roadmap")
async def career_roadmap(
    current_state: str,
    target: str,
    timeline_months: int = 12,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    from app.agents.career_agent import CareerAgent
    agent = CareerAgent(db, user_id)
    result = await agent.generate_career_roadmap(current_state, target, timeline_months)
    return result


@router.post("/startup/evaluate")
async def evaluate_startup(
    req: StartupRequest,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    from app.agents.career_agent import StartupAgent
    agent = StartupAgent(db, user_id)
    result = await agent.evaluate_idea(req.idea, req.context or "")
    return result


@router.post("/startup/lean-canvas")
async def lean_canvas(
    idea: str,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    from app.agents.career_agent import StartupAgent
    agent = StartupAgent(db, user_id)
    return await agent.create_lean_canvas(idea)


@router.post("/productivity/week-plan")
async def plan_week(
    req: WeekPlanRequest,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    from app.agents.career_agent import ProductivityAgent
    from app.db.models import Task, TaskStatus
    from sqlalchemy import select

    tasks_result = await db.execute(
        select(Task).where(
            Task.user_id == user_id,
            Task.status != TaskStatus.DONE,
        ).limit(30)
    )
    tasks = [
        {"title": t.title, "priority": t.priority, "due_date": str(t.due_date) if t.due_date else None}
        for t in tasks_result.scalars().all()
    ]
    agent = ProductivityAgent(db, user_id)
    return await agent.plan_week(req.goals, tasks, req.focus_areas)


@router.post("/research/topic")
async def research_topic(
    topic: str,
    depth: str = "overview",
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    from app.agents.career_agent import ResearchAgent
    agent = ResearchAgent(db, user_id)
    return await agent.research_topic(topic, depth)


@router.post("/reflection/weekly-review")
async def weekly_review(
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    """Generate an AI-facilitated weekly review."""
    from app.agents.career_agent import ReflectionAgent
    from app.api.routes.analytics import compute_date_range_metrics
    from datetime import date, timedelta

    today = date.today()
    week_start = today - timedelta(days=7)
    metrics = await compute_date_range_metrics(db, user_id, week_start, today)

    agent = ReflectionAgent(db, user_id)
    return await agent.generate_weekly_review(metrics)
