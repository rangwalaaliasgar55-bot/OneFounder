"""
ARX OS — Chat Routes
Handles both HTTP and WebSocket chat with streaming.
"""
import json
from typing import List, Optional
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from pydantic import BaseModel

from app.db.session import get_db
from app.db.models import Conversation, Message, User, UserProfile, MessageRole
from app.core.security import get_current_user_id, decode_token
from app.agents.master_agent import MasterAgent

router = APIRouter()


class ChatRequest(BaseModel):
    message: str
    conversation_id: Optional[str] = None
    agent_type: str = "master"


class ConversationCreate(BaseModel):
    title: Optional[str] = None
    agent_type: str = "master"


async def get_or_create_conversation(
    db: AsyncSession, user_id: str,
    conversation_id: Optional[str], agent_type: str
) -> Conversation:
    if conversation_id:
        result = await db.execute(
            select(Conversation).where(
                Conversation.id == conversation_id,
                Conversation.user_id == user_id
            )
        )
        conv = result.scalar_one_or_none()
        if conv:
            return conv

    conv = Conversation(user_id=user_id, agent_type=agent_type)
    db.add(conv)
    await db.flush()
    return conv


async def get_conversation_history(
    db: AsyncSession, conversation_id: str, limit: int = 20
) -> List[dict]:
    result = await db.execute(
        select(Message)
        .where(Message.conversation_id == conversation_id)
        .order_by(Message.created_at.desc())
        .limit(limit)
    )
    messages = list(reversed(result.scalars().all()))
    return [{"role": m.role.value if hasattr(m.role, 'value') else m.role, "content": m.content} for m in messages]


async def get_user_profile_dict(db: AsyncSession, user_id: str) -> dict:
    result = await db.execute(select(UserProfile).where(UserProfile.user_id == user_id))
    profile = result.scalar_one_or_none()
    if not profile:
        return {}
    return {
        "occupation": profile.occupation,
        "skills": profile.skills or [],
        "interests": profile.interests or [],
        "career_goals": profile.career_goals or [],
        "current_focus": profile.current_focus,
        "strengths": profile.strengths or [],
    }


# ─── HTTP Endpoints ──────────────────────────────────────────────────────────

@router.get("/conversations")
async def list_conversations(
    limit: int = 20,
    offset: int = 0,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Conversation)
        .where(Conversation.user_id == user_id, Conversation.is_archived == False)
        .order_by(desc(Conversation.updated_at))
        .limit(limit)
        .offset(offset)
    )
    conversations = result.scalars().all()
    return [
        {
            "id": c.id,
            "title": c.title,
            "agent_type": c.agent_type,
            "summary": c.summary,
            "created_at": c.created_at,
            "updated_at": c.updated_at,
        }
        for c in conversations
    ]


@router.post("/conversations")
async def create_conversation(
    req: ConversationCreate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    conv = Conversation(user_id=user_id, title=req.title, agent_type=req.agent_type)
    db.add(conv)
    await db.commit()
    await db.refresh(conv)
    return {"id": conv.id, "title": conv.title, "agent_type": conv.agent_type}


@router.get("/conversations/{conversation_id}/messages")
async def get_messages(
    conversation_id: str,
    limit: int = 50,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    # Verify ownership
    conv_result = await db.execute(
        select(Conversation).where(
            Conversation.id == conversation_id,
            Conversation.user_id == user_id
        )
    )
    if not conv_result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Conversation not found")

    result = await db.execute(
        select(Message)
        .where(Message.conversation_id == conversation_id)
        .order_by(Message.created_at)
        .limit(limit)
    )
    messages = result.scalars().all()
    return [
        {
            "id": m.id,
            "role": m.role.value if hasattr(m.role, 'value') else m.role,
            "content": m.content,
            "created_at": m.created_at,
        }
        for m in messages
    ]


@router.delete("/conversations/{conversation_id}")
async def delete_conversation(
    conversation_id: str,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Conversation).where(
            Conversation.id == conversation_id,
            Conversation.user_id == user_id
        )
    )
    conv = result.scalar_one_or_none()
    if not conv:
        raise HTTPException(status_code=404, detail="Not found")
    conv.is_archived = True
    await db.commit()
    return {"status": "archived"}


# ─── WebSocket Streaming Chat ────────────────────────────────────────────────

@router.websocket("/ws/{conversation_id}")
async def chat_websocket(
    websocket: WebSocket,
    conversation_id: str,
):
    """
    WebSocket endpoint for streaming chat.
    Protocol:
      Client sends: {"token": "jwt...", "message": "...", "agent_type": "master"}
      Server sends: {"type": "chunk", "content": "..."} 
                    {"type": "done", "message_id": "..."}
                    {"type": "error", "detail": "..."}
    """
    await websocket.accept()

    # Authenticate via first message
    try:
        auth_data = await websocket.receive_json()
        token = auth_data.get("token")
        if not token:
            await websocket.send_json({"type": "error", "detail": "No token"})
            await websocket.close()
            return

        payload = decode_token(token)
        user_id = payload.get("sub")
        message = auth_data.get("message", "")
        agent_type = auth_data.get("agent_type", "master")

        if not message:
            await websocket.send_json({"type": "error", "detail": "No message"})
            return

    except Exception as e:
        await websocket.send_json({"type": "error", "detail": str(e)})
        await websocket.close()
        return

    # Open DB session for this connection
    from app.db.session import AsyncSessionLocal
    async with AsyncSessionLocal() as db:
        try:
            # Get or create conversation
            conv = await get_or_create_conversation(db, user_id, conversation_id, agent_type)
            history = await get_conversation_history(db, conv.id)
            profile = await get_user_profile_dict(db, user_id)

            # Store user message
            user_msg = Message(
                conversation_id=conv.id,
                role=MessageRole.USER,
                content=message,
            )
            db.add(user_msg)
            await db.flush()

            # Stream response
            agent = MasterAgent(db, user_id, conv.id)
            full_response = ""

            async for chunk in agent.chat(message, history, profile):
                full_response += chunk
                await websocket.send_json({"type": "chunk", "content": chunk})

            # Store assistant message
            asst_msg = Message(
                conversation_id=conv.id,
                role=MessageRole.ASSISTANT,
                content=full_response,
                model_used="llama3",
            )
            db.add(asst_msg)

            # Update conversation title if first message
            if not conv.title:
                conv.title = message[:100]

            await db.commit()

            await websocket.send_json({
                "type": "done",
                "message_id": asst_msg.id,
                "conversation_id": conv.id,
            })

        except WebSocketDisconnect:
            pass
        except Exception as e:
            await websocket.send_json({"type": "error", "detail": str(e)})
        finally:
            await db.close()
