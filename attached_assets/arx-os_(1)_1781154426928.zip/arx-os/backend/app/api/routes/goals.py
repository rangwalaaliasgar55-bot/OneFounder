"""
ARX OS — Goals Routes
"""
from typing import Optional, List
from datetime import date
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, update
from pydantic import BaseModel

from app.db.session import get_db
from app.db.models import Goal, GoalCheckIn, GoalStatus, GoalCategory
from app.core.security import get_current_user_id

router = APIRouter()


class GoalCreate(BaseModel):
    title: str
    description: Optional[str] = None
    category: GoalCategory = GoalCategory.PERSONAL
    priority: int = 3
    target_date: Optional[date] = None
    parent_id: Optional[str] = None


class GoalUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[GoalStatus] = None
    progress: Optional[float] = None
    priority: Optional[int] = None
    target_date: Optional[date] = None


class CheckInCreate(BaseModel):
    progress: float
    notes: Optional[str] = None
    mood: Optional[int] = None
    blockers: Optional[str] = None


@router.get("")
async def list_goals(
    status: Optional[GoalStatus] = None,
    category: Optional[GoalCategory] = None,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    query = select(Goal).where(Goal.user_id == user_id)
    if status:
        query = query.where(Goal.status == status)
    if category:
        query = query.where(Goal.category == category)
    query = query.order_by(Goal.priority.desc(), Goal.created_at.desc())

    result = await db.execute(query)
    goals = result.scalars().all()
    return [
        {
            "id": g.id,
            "title": g.title,
            "description": g.description,
            "category": g.category,
            "status": g.status,
            "priority": g.priority,
            "progress": g.progress,
            "target_date": g.target_date,
            "parent_id": g.parent_id,
            "milestones": g.milestones,
            "created_at": g.created_at,
            "updated_at": g.updated_at,
        }
        for g in goals
    ]


@router.post("")
async def create_goal(
    req: GoalCreate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    goal = Goal(user_id=user_id, **req.model_dump())
    db.add(goal)
    await db.commit()
    await db.refresh(goal)
    return {"id": goal.id, "title": goal.title, "status": goal.status}


@router.patch("/{goal_id}")
async def update_goal(
    goal_id: str,
    req: GoalUpdate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Goal).where(Goal.id == goal_id, Goal.user_id == user_id)
    )
    goal = result.scalar_one_or_none()
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")

    for key, value in req.model_dump(exclude_none=True).items():
        setattr(goal, key, value)

    await db.commit()
    return {"id": goal.id, "status": "updated"}


@router.delete("/{goal_id}")
async def delete_goal(
    goal_id: str,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Goal).where(Goal.id == goal_id, Goal.user_id == user_id)
    )
    goal = result.scalar_one_or_none()
    if not goal:
        raise HTTPException(status_code=404, detail="Not found")
    await db.delete(goal)
    await db.commit()
    return {"status": "deleted"}


@router.post("/{goal_id}/checkin")
async def checkin_goal(
    goal_id: str,
    req: CheckInCreate,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Goal).where(Goal.id == goal_id, Goal.user_id == user_id)
    )
    goal = result.scalar_one_or_none()
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")

    checkin = GoalCheckIn(
        goal_id=goal_id,
        user_id=user_id,
        progress=req.progress,
        notes=req.notes,
        mood=req.mood,
        blockers=req.blockers,
    )
    db.add(checkin)
    goal.progress = req.progress
    await db.commit()
    return {"id": checkin.id, "progress": req.progress}


@router.get("/{goal_id}/ai-suggestions")
async def get_ai_suggestions(
    goal_id: str,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    """Get AI-generated suggestions for advancing a goal."""
    from app.services.ollama_service import get_ollama
    result = await db.execute(
        select(Goal).where(Goal.id == goal_id, Goal.user_id == user_id)
    )
    goal = result.scalar_one_or_none()
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")

    ollama = get_ollama()
    suggestions = await ollama.generate_json(
        prompt=f"""Goal: {goal.title}
Description: {goal.description or 'None'}
Category: {goal.category}
Progress: {goal.progress}%
Target date: {goal.target_date}

Generate 5 specific, actionable next steps to advance this goal.
Return JSON: {{"suggestions": ["step1", "step2", ...], "blockers_to_watch": [], "quick_win": "..."}}""",
    )
    return suggestions
