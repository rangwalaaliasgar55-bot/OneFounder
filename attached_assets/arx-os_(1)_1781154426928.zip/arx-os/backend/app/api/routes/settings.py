"""
ARX OS — Settings Routes
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import Optional

from app.db.session import get_db
from app.db.models import User
from app.core.security import get_current_user_id, hash_password, verify_password
from app.services.ollama_service import get_ollama

router = APIRouter()


class PasswordChange(BaseModel):
    current_password: str
    new_password: str


class AppSettings(BaseModel):
    timezone: Optional[str] = None
    ollama_model: Optional[str] = None
    theme: Optional[str] = None


@router.get("")
async def get_settings(
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    from app.core.config import settings
    ollama = get_ollama()
    ollama_ok = await ollama.check_health()
    models = await ollama.list_models() if ollama_ok else []

    return {
        "ollama": {
            "healthy": ollama_ok,
            "base_url": settings.OLLAMA_BASE_URL,
            "current_model": settings.OLLAMA_MODEL,
            "available_models": models,
        },
        "whisper_model": settings.WHISPER_MODEL,
        "environment": settings.ENVIRONMENT,
    }


@router.post("/change-password")
async def change_password(
    req: PasswordChange,
    user_id: str = Depends(get_current_user_id),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if not verify_password(req.current_password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Current password incorrect")
    user.hashed_password = hash_password(req.new_password)
    await db.commit()
    return {"status": "password changed"}


@router.get("/health")
async def system_health():
    from app.memory.vector_store import get_collection_stats, get_qdrant_client
    from app.core.config import settings
    ollama = get_ollama()

    try:
        client = get_qdrant_client()
        collections = await client.get_collections()
        qdrant_ok = True
        collection_count = len(collections.collections)
    except Exception:
        qdrant_ok = False
        collection_count = 0

    return {
        "status": "ok",
        "ollama": await ollama.check_health(),
        "qdrant": qdrant_ok,
        "qdrant_collections": collection_count,
        "version": "1.0.0",
    }
