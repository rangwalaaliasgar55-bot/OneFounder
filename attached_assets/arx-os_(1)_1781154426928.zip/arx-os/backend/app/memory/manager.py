"""
ARX OS — Memory Manager
Unified interface for all 4 memory subsystems:
  - Episodic  : conversations, events, experiences
  - Semantic  : user facts, preferences, skills
  - Procedural: workflows, habits, routines
  - Reflection: lessons learned, reviews, insights
"""
import uuid
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, and_
from loguru import logger

from app.db.models import Memory, MemoryType
from app.memory.embeddings import get_embedding_service
from app.memory.vector_store import (
    upsert_vectors, search_vectors, delete_vectors,
    get_qdrant_client
)
from app.core.config import settings


class MemoryManager:
    """
    Central memory orchestrator. Handles storage, retrieval, and
    consolidation across all memory types.
    """

    COLLECTION_MAP = {
        MemoryType.EPISODIC:   settings.COLLECTION_EPISODIC,
        MemoryType.SEMANTIC:   settings.COLLECTION_SEMANTIC,
        MemoryType.PROCEDURAL: settings.COLLECTION_SEMANTIC,   # stored in semantic
        MemoryType.REFLECTION: settings.COLLECTION_REFLECTION,
    }

    def __init__(self, db: AsyncSession):
        self.db = db
        self.embed = get_embedding_service()

    # ─── STORE ──────────────────────────────────────────────────────────────

    async def store(
        self,
        user_id: str,
        content: str,
        memory_type: MemoryType,
        title: Optional[str] = None,
        source: Optional[str] = None,
        source_id: Optional[str] = None,
        importance: float = 0.5,
        tags: Optional[List[str]] = None,
        expires_at: Optional[datetime] = None,
    ) -> Memory:
        """Store a new memory entry with embedding."""
        # Generate embedding
        vector = await self.embed.embed_document(content)
        point_id = str(uuid.uuid4())

        # Qdrant payload
        collection = self.COLLECTION_MAP[memory_type]
        payload = {
            "user_id": user_id,
            "memory_type": memory_type.value,
            "title": title or "",
            "content": content[:2000],  # truncate for payload
            "source": source or "manual",
            "source_id": source_id or "",
            "importance": importance,
            "tags": tags or [],
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        await upsert_vectors(collection, [{"id": point_id, "vector": vector, "payload": payload}])

        # PostgreSQL record
        memory = Memory(
            user_id=user_id,
            memory_type=memory_type,
            title=title,
            content=content,
            source=source,
            source_id=source_id,
            importance=importance,
            tags=tags or [],
            vector_id=point_id,
            expires_at=expires_at,
        )
        self.db.add(memory)
        await self.db.flush()
        logger.debug(f"Stored {memory_type.value} memory: {memory.id}")
        return memory

    # ─── SEARCH ─────────────────────────────────────────────────────────────

    async def search(
        self,
        user_id: str,
        query: str,
        memory_types: Optional[List[MemoryType]] = None,
        limit: int = 10,
        score_threshold: float = 0.6,
    ) -> List[Dict[str, Any]]:
        """Semantic search across memory types."""
        query_vector = await self.embed.embed_query(query)

        # Determine which collections to search
        types_to_search = memory_types or list(MemoryType)
        collections_to_search = set()
        for mt in types_to_search:
            collections_to_search.add(self.COLLECTION_MAP[mt])

        all_results = []
        for collection in collections_to_search:
            results = await search_vectors(
                collection_name=collection,
                query_vector=query_vector,
                user_id=user_id,
                limit=limit,
                score_threshold=score_threshold,
            )
            all_results.extend(results)

        # Sort by score, deduplicate
        seen_ids = set()
        unique_results = []
        for r in sorted(all_results, key=lambda x: x["score"], reverse=True):
            if r["id"] not in seen_ids:
                seen_ids.add(r["id"])
                unique_results.append(r)

        return unique_results[:limit]

    # ─── EPISODIC ────────────────────────────────────────────────────────────

    async def store_conversation_memory(
        self, user_id: str, conversation_id: str,
        summary: str, key_facts: List[str], importance: float = 0.5
    ) -> Memory:
        """Extract and store episodic memory from a conversation."""
        content = f"Conversation summary: {summary}\n\nKey facts:\n" + "\n".join(f"- {f}" for f in key_facts)
        return await self.store(
            user_id=user_id,
            content=content,
            memory_type=MemoryType.EPISODIC,
            title=f"Conversation: {summary[:80]}",
            source="conversation",
            source_id=conversation_id,
            importance=importance,
        )

    # ─── SEMANTIC ────────────────────────────────────────────────────────────

    async def update_user_fact(
        self, user_id: str, fact: str,
        category: str = "general", importance: float = 0.7
    ) -> Memory:
        """Store or update a semantic fact about the user."""
        return await self.store(
            user_id=user_id,
            content=fact,
            memory_type=MemoryType.SEMANTIC,
            title=f"User fact: {fact[:60]}",
            source="agent",
            importance=importance,
            tags=[category, "user-fact"],
        )

    # ─── PROCEDURAL ──────────────────────────────────────────────────────────

    async def store_workflow(
        self, user_id: str, workflow_name: str,
        steps: List[str], context: str = ""
    ) -> Memory:
        """Store a procedural workflow."""
        content = f"Workflow: {workflow_name}\n\nContext: {context}\n\nSteps:\n" + \
                  "\n".join(f"{i+1}. {s}" for i, s in enumerate(steps))
        return await self.store(
            user_id=user_id,
            content=content,
            memory_type=MemoryType.PROCEDURAL,
            title=workflow_name,
            source="agent",
            importance=0.6,
            tags=["workflow"],
        )

    # ─── REFLECTION ──────────────────────────────────────────────────────────

    async def store_insight(
        self, user_id: str, insight: str,
        insight_type: str = "lesson", source_id: Optional[str] = None
    ) -> Memory:
        """Store a reflection/insight."""
        return await self.store(
            user_id=user_id,
            content=insight,
            memory_type=MemoryType.REFLECTION,
            title=f"Insight: {insight[:60]}",
            source="reflection",
            source_id=source_id,
            importance=0.8,
            tags=[insight_type],
        )

    # ─── RETRIEVAL FOR RAG ───────────────────────────────────────────────────

    async def get_relevant_context(
        self, user_id: str, query: str, max_tokens: int = 2000
    ) -> str:
        """
        Retrieve the most relevant memories for RAG context injection.
        Returns formatted string ready for prompt insertion.
        """
        results = await self.search(user_id, query, limit=8, score_threshold=0.55)
        if not results:
            return ""

        context_parts = ["[Relevant Memory Context]"]
        total_chars = 0
        max_chars = max_tokens * 4  # approx chars per token

        for r in results:
            payload = r.get("payload", {})
            mem_type = payload.get("memory_type", "")
            content = payload.get("content", "")
            score = r.get("score", 0)

            if total_chars + len(content) > max_chars:
                break

            context_parts.append(
                f"[{mem_type.upper()} | relevance: {score:.2f}]\n{content}"
            )
            total_chars += len(content)

            # Update access count
            await self._increment_access(r["id"], payload.get("memory_type"))

        return "\n\n".join(context_parts)

    async def _increment_access(self, vector_id: str, memory_type: str):
        """Increment access count on a memory."""
        await self.db.execute(
            update(Memory)
            .where(Memory.vector_id == vector_id)
            .values(
                access_count=Memory.access_count + 1,
                last_accessed=datetime.now(timezone.utc),
            )
        )

    # ─── LIST ────────────────────────────────────────────────────────────────

    async def list_memories(
        self,
        user_id: str,
        memory_type: Optional[MemoryType] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> List[Memory]:
        """List memories from PostgreSQL with optional type filter."""
        query = select(Memory).where(Memory.user_id == user_id)
        if memory_type:
            query = query.where(Memory.memory_type == memory_type)
        query = query.order_by(Memory.created_at.desc()).limit(limit).offset(offset)
        result = await self.db.execute(query)
        return list(result.scalars().all())

    async def delete_memory(self, user_id: str, memory_id: str) -> bool:
        """Delete a memory from both PostgreSQL and Qdrant."""
        result = await self.db.execute(
            select(Memory).where(and_(Memory.id == memory_id, Memory.user_id == user_id))
        )
        memory = result.scalar_one_or_none()
        if not memory:
            return False

        if memory.vector_id:
            collection = self.COLLECTION_MAP[memory.memory_type]
            await delete_vectors(collection, [memory.vector_id])

        await self.db.delete(memory)
        return True
