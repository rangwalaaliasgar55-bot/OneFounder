"""
ARX OS — Embedding Service
Generates text embeddings using Ollama (nomic-embed-text).
"""
from typing import List, Union
import httpx
from loguru import logger
from tenacity import retry, stop_after_attempt, wait_exponential

from app.core.config import settings


class EmbeddingService:
    def __init__(self):
        self.base_url = settings.OLLAMA_BASE_URL
        self.model = settings.OLLAMA_EMBED_MODEL
        self._client = httpx.AsyncClient(timeout=60.0)

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=10))
    async def embed(self, text: str) -> List[float]:
        """Embed a single text string."""
        response = await self._client.post(
            f"{self.base_url}/api/embeddings",
            json={"model": self.model, "prompt": text},
        )
        response.raise_for_status()
        return response.json()["embedding"]

    async def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """Embed multiple texts."""
        results = []
        for text in texts:
            emb = await self.embed(text)
            results.append(emb)
        return results

    async def embed_query(self, query: str) -> List[float]:
        """Embed a search query (same as embed but semantically distinct)."""
        return await self.embed(f"search_query: {query}")

    async def embed_document(self, text: str) -> List[float]:
        """Embed a document for storage."""
        return await self.embed(f"search_document: {text}")


# Singleton
_embedding_service: EmbeddingService = None


def get_embedding_service() -> EmbeddingService:
    global _embedding_service
    if _embedding_service is None:
        _embedding_service = EmbeddingService()
    return _embedding_service
