"""
ARX OS — Vector Store (Qdrant)
Manages all semantic embedding storage and retrieval.
"""
from typing import List, Optional, Dict, Any
import uuid

from qdrant_client import AsyncQdrantClient
from qdrant_client.models import (
    Distance, VectorParams, PointStruct, Filter,
    FieldCondition, MatchValue, SearchParams,
    UpdateCollection, HnswConfigDiff, PointIdsList
)
from loguru import logger

from app.core.config import settings

# Global client instance
_client: Optional[AsyncQdrantClient] = None

VECTOR_SIZE = 768  # nomic-embed-text dimension


def get_qdrant_client() -> AsyncQdrantClient:
    global _client
    if _client is None:
        _client = AsyncQdrantClient(
            host=settings.QDRANT_HOST,
            port=settings.QDRANT_PORT,
            timeout=30,
        )
    return _client


async def init_vector_store():
    """Create all required collections if they don't exist."""
    client = get_qdrant_client()
    collections = [
        settings.COLLECTION_EPISODIC,
        settings.COLLECTION_SEMANTIC,
        settings.COLLECTION_KNOWLEDGE,
        settings.COLLECTION_REFLECTION,
    ]
    existing = {c.name for c in (await client.get_collections()).collections}

    for collection_name in collections:
        if collection_name not in existing:
            await client.create_collection(
                collection_name=collection_name,
                vectors_config=VectorParams(
                    size=VECTOR_SIZE,
                    distance=Distance.COSINE,
                ),
                hnsw_config=HnswConfigDiff(
                    m=16,
                    ef_construct=100,
                ),
            )
            logger.info(f"✓ Created Qdrant collection: {collection_name}")
        else:
            logger.debug(f"  Collection exists: {collection_name}")


async def upsert_vectors(
    collection_name: str,
    points: List[Dict[str, Any]],
) -> List[str]:
    """
    Upsert vectors into a collection.
    Points: [{id, vector, payload}]
    Returns list of point IDs.
    """
    client = get_qdrant_client()
    qdrant_points = [
        PointStruct(
            id=p.get("id", str(uuid.uuid4())),
            vector=p["vector"],
            payload=p.get("payload", {}),
        )
        for p in points
    ]
    await client.upsert(collection_name=collection_name, points=qdrant_points)
    return [str(p.id) for p in qdrant_points]


async def search_vectors(
    collection_name: str,
    query_vector: List[float],
    user_id: str,
    limit: int = 10,
    score_threshold: float = 0.6,
    filters: Optional[Dict] = None,
) -> List[Dict[str, Any]]:
    """Search for similar vectors, always filtered by user_id."""
    client = get_qdrant_client()

    must_conditions = [
        FieldCondition(key="user_id", match=MatchValue(value=user_id))
    ]

    if filters:
        for key, value in filters.items():
            must_conditions.append(
                FieldCondition(key=key, match=MatchValue(value=value))
            )

    results = await client.search(
        collection_name=collection_name,
        query_vector=query_vector,
        limit=limit,
        score_threshold=score_threshold,
        query_filter=Filter(must=must_conditions),
        with_payload=True,
    )

    return [
        {
            "id": str(r.id),
            "score": r.score,
            "payload": r.payload,
        }
        for r in results
    ]


async def delete_vectors(collection_name: str, point_ids: List[str]):
    """Delete specific vectors by ID."""
    client = get_qdrant_client()
    await client.delete(
        collection_name=collection_name,
        points_selector=PointIdsList(points=point_ids),
    )


async def get_collection_stats(collection_name: str) -> Dict[str, Any]:
    """Get statistics for a collection."""
    client = get_qdrant_client()
    info = await client.get_collection(collection_name)
    return {
        "name": collection_name,
        "vectors_count": info.vectors_count,
        "indexed_vectors_count": info.indexed_vectors_count,
        "status": str(info.status),
    }
