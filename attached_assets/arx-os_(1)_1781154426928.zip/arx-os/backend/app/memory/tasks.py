"""
ARX OS — Memory Background Tasks
Celery tasks for async memory consolidation and profile updates.
"""
from app.core.celery_app import celery_app


@celery_app.task(name="app.memory.tasks.consolidate_memories")
def consolidate_memories(user_id: str):
    """
    Consolidate recent episodic memories into semantic facts.
    Runs periodically to keep semantic memory fresh.
    """
    import asyncio
    from app.db.session import AsyncSessionLocal
    from app.memory.manager import MemoryManager
    from app.db.models import Memory, MemoryType
    from sqlalchemy import select
    from datetime import datetime, timezone, timedelta

    async def _run():
        async with AsyncSessionLocal() as db:
            manager = MemoryManager(db)

            # Get recent episodic memories not yet consolidated
            cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
            result = await db.execute(
                select(Memory).where(
                    Memory.user_id == user_id,
                    Memory.memory_type == MemoryType.EPISODIC,
                    Memory.created_at >= cutoff,
                ).limit(20)
            )
            recent = result.scalars().all()

            if not recent:
                return {"consolidated": 0}

            # Use LLM to extract semantic facts
            from app.services.ollama_service import get_ollama
            ollama = get_ollama()

            combined = "\n\n".join(m.content[:500] for m in recent)
            result = await ollama.generate_json(
                prompt=f"Extract permanent facts about the user from these memories:\n{combined}",
                system="""Extract only concrete, lasting facts.
Return JSON: {{"facts": ["The user is a software engineer", "The user wants to start a company", ...]}}
Max 5 facts. Only new, significant information.""",
            )

            facts = result.get("facts", [])
            for fact in facts:
                await manager.update_user_fact(user_id=user_id, fact=fact, importance=0.7)

            await db.commit()
            return {"consolidated": len(facts)}

    return asyncio.get_event_loop().run_until_complete(_run())


@celery_app.task(name="app.memory.tasks.update_user_metrics")
def update_user_metrics(user_id: str):
    """Update aggregated metrics in UserProfile."""
    import asyncio
    from app.db.session import AsyncSessionLocal
    from app.db.models import (
        UserProfile, Goal, GoalStatus, Habit, HabitLog,
        LearningSession, Task, TaskStatus,
    )
    from sqlalchemy import select, func
    from datetime import date, timedelta

    async def _run():
        async with AsyncSessionLocal() as db:
            today = date.today()
            thirty_days_ago = today - timedelta(days=30)

            # Goal completion rate
            total_goals = await db.execute(
                select(func.count(Goal.id)).where(Goal.user_id == user_id)
            )
            completed_goals = await db.execute(
                select(func.count(Goal.id)).where(
                    Goal.user_id == user_id,
                    Goal.status == GoalStatus.COMPLETED,
                )
            )
            t = total_goals.scalar() or 0
            c = completed_goals.scalar() or 0
            goal_rate = round(c / t, 2) if t > 0 else 0.0

            # Habit adherence (last 30 days)
            active_habits = await db.execute(
                select(func.count(Habit.id)).where(
                    Habit.user_id == user_id, Habit.is_active == True
                )
            )
            habit_logs = await db.execute(
                select(func.count(HabitLog.id)).where(
                    HabitLog.user_id == user_id,
                    HabitLog.completed_date >= thirty_days_ago,
                )
            )
            possible = (active_habits.scalar() or 0) * 30
            actual = habit_logs.scalar() or 0
            habit_rate = round(actual / possible, 2) if possible > 0 else 0.0

            # Learning velocity (hours/week)
            learning_mins = await db.execute(
                select(func.sum(LearningSession.duration_minutes)).where(
                    LearningSession.user_id == user_id,
                    LearningSession.session_date >= thirty_days_ago,
                )
            )
            learning_velocity = round((learning_mins.scalar() or 0) / 60 / 4, 1)  # hrs/week

            # Productivity score (tasks completed / created last 30d)
            tasks_done = await db.execute(
                select(func.count(Task.id)).where(
                    Task.user_id == user_id,
                    Task.status == TaskStatus.DONE,
                )
            )
            tasks_all = await db.execute(
                select(func.count(Task.id)).where(Task.user_id == user_id)
            )
            td = tasks_done.scalar() or 0
            ta = tasks_all.scalar() or 1
            productivity = round(td / ta * 10, 1)

            # Update profile
            result = await db.execute(
                select(UserProfile).where(UserProfile.user_id == user_id)
            )
            profile = result.scalar_one_or_none()
            if profile:
                profile.goal_completion_rate = goal_rate
                profile.habit_adherence_rate = habit_rate
                profile.learning_velocity = learning_velocity
                profile.productivity_score = productivity
                await db.commit()

    return asyncio.get_event_loop().run_until_complete(_run())
