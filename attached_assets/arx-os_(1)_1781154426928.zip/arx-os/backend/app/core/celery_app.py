"""
ARX OS — Celery Application
"""
from celery import Celery
from app.core.config import settings

celery_app = Celery(
    "arxos",
    broker=settings.REDIS_URL,
    backend=settings.REDIS_URL,
    include=[
        "app.services.analytics_tasks",
        "app.memory.tasks",
        "app.services.report_tasks",
    ],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_routes={
        "app.services.analytics_tasks.*": {"queue": "analytics"},
        "app.memory.tasks.*": {"queue": "memory"},
        "app.services.report_tasks.*": {"queue": "default"},
    },
    beat_schedule={
        "daily-analytics": {
            "task": "app.services.analytics_tasks.compute_daily_analytics",
            "schedule": 86400.0,  # every 24h
        },
        "weekly-report": {
            "task": "app.services.report_tasks.generate_weekly_report",
            "schedule": 604800.0,  # every 7 days
        },
    },
)
