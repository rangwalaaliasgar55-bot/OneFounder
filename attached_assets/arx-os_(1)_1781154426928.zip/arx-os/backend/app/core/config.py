"""
ARX OS — Core Configuration
"""
from typing import List
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import field_validator


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # ─── App ──────────────────────────────
    ENVIRONMENT: str = "production"
    LOG_LEVEL: str = "INFO"
    DATA_DIR: str = "/app/data"
    AUDIO_DIR: str = "/app/audio"

    # ─── Database ─────────────────────────
    DATABASE_URL: str = "postgresql+asyncpg://arxos:arxos_secret@postgres:5432/arxos_db"

    # ─── Redis ────────────────────────────
    REDIS_URL: str = "redis://:arxos_redis@redis:6379/0"

    # ─── Security ─────────────────────────
    SECRET_KEY: str = "change-this-in-production"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440
    REFRESH_TOKEN_EXPIRE_DAYS: int = 30

    # ─── CORS ─────────────────────────────
    CORS_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost"]

    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def parse_cors(cls, v):
        if isinstance(v, str):
            return [x.strip() for x in v.split(",")]
        return v

    # ─── Ollama ───────────────────────────
    OLLAMA_BASE_URL: str = "http://ollama:11434"
    OLLAMA_MODEL: str = "llama3"
    OLLAMA_EMBED_MODEL: str = "nomic-embed-text"
    OLLAMA_TEMPERATURE: float = 0.7
    OLLAMA_MAX_TOKENS: int = 4096

    # ─── Qdrant ───────────────────────────
    QDRANT_HOST: str = "qdrant"
    QDRANT_PORT: int = 6333
    QDRANT_COLLECTION_PREFIX: str = "arxos"

    # ─── Voice ────────────────────────────
    WHISPER_MODEL: str = "base"
    PIPER_MODEL: str = "en_US-lessac-medium"

    # ─── Analytics ────────────────────────
    ANALYTICS_RETENTION_DAYS: int = 365

    # ─── Computed ─────────────────────────
    @property
    def COLLECTION_EPISODIC(self) -> str:
        return f"{self.QDRANT_COLLECTION_PREFIX}_episodic"

    @property
    def COLLECTION_SEMANTIC(self) -> str:
        return f"{self.QDRANT_COLLECTION_PREFIX}_semantic"

    @property
    def COLLECTION_KNOWLEDGE(self) -> str:
        return f"{self.QDRANT_COLLECTION_PREFIX}_knowledge"

    @property
    def COLLECTION_REFLECTION(self) -> str:
        return f"{self.QDRANT_COLLECTION_PREFIX}_reflection"


settings = Settings()
