"""
ARX OS — Main Application Entry Point
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

from app.core.config import settings
from app.core.logging import setup_logging
from app.db.session import init_db
from app.memory.vector_store import init_vector_store
from app.api.routes import (
    auth,
    chat,
    memory,
    goals,
    projects,
    habits,
    learning,
    analytics,
    agents,
    voice,
    settings as settings_router,
    user,
    knowledge,
    finance,
    reflection,
)

setup_logging()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown events."""
    # Initialize database
    await init_db()
    # Initialize vector store collections
    await init_vector_store()
    yield
    # Cleanup (if needed)


app = FastAPI(
    title="ARX OS API",
    description="Personal AI Operating System — Local, Private, Intelligent",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
)

# ─── Middleware ──────────────────────────────────────────────────────────────
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Routes ─────────────────────────────────────────────────────────────────
PREFIX = "/api/v1"

app.include_router(auth.router,       prefix=f"{PREFIX}/auth",       tags=["Auth"])
app.include_router(user.router,       prefix=f"{PREFIX}/user",       tags=["User"])
app.include_router(chat.router,       prefix=f"{PREFIX}/chat",       tags=["Chat"])
app.include_router(memory.router,     prefix=f"{PREFIX}/memory",     tags=["Memory"])
app.include_router(goals.router,      prefix=f"{PREFIX}/goals",      tags=["Goals"])
app.include_router(projects.router,   prefix=f"{PREFIX}/projects",   tags=["Projects"])
app.include_router(habits.router,     prefix=f"{PREFIX}/habits",     tags=["Habits"])
app.include_router(learning.router,   prefix=f"{PREFIX}/learning",   tags=["Learning"])
app.include_router(analytics.router,  prefix=f"{PREFIX}/analytics",  tags=["Analytics"])
app.include_router(agents.router,     prefix=f"{PREFIX}/agents",     tags=["Agents"])
app.include_router(voice.router,      prefix=f"{PREFIX}/voice",      tags=["Voice"])
app.include_router(knowledge.router,  prefix=f"{PREFIX}/knowledge",  tags=["Knowledge"])
app.include_router(finance.router,    prefix=f"{PREFIX}/finance",    tags=["Finance"])
app.include_router(reflection.router, prefix=f"{PREFIX}/reflection", tags=["Reflection"])
app.include_router(settings_router.router, prefix=f"{PREFIX}/settings", tags=["Settings"])


@app.get("/api/health")
async def health_check():
    return {"status": "ok", "version": "1.0.0", "system": "ARX OS"}
