"""
ARX OS — Ollama LLM Service
Wraps Ollama API with streaming, retry, and structured output support.
"""
import json
from typing import AsyncGenerator, List, Dict, Optional, Any

import httpx
from loguru import logger
from tenacity import retry, stop_after_attempt, wait_exponential

from app.core.config import settings


class OllamaService:
    def __init__(self):
        self.base_url = settings.OLLAMA_BASE_URL
        self.model = settings.OLLAMA_MODEL
        self.temperature = settings.OLLAMA_TEMPERATURE
        self.max_tokens = settings.OLLAMA_MAX_TOKENS
        self._client = httpx.AsyncClient(timeout=300.0)

    def _build_messages(
        self,
        system: str,
        messages: List[Dict[str, str]],
        context: Optional[str] = None,
    ) -> List[Dict[str, str]]:
        """Build the messages array for the API."""
        system_prompt = system
        if context:
            system_prompt = f"{system}\n\n{context}"

        result = [{"role": "system", "content": system_prompt}]
        result.extend(messages)
        return result

    async def chat(
        self,
        messages: List[Dict[str, str]],
        system: str = "",
        context: str = "",
        temperature: Optional[float] = None,
        json_mode: bool = False,
    ) -> str:
        """Non-streaming chat completion."""
        payload = {
            "model": self.model,
            "messages": self._build_messages(system, messages, context),
            "stream": False,
            "options": {
                "temperature": temperature or self.temperature,
                "num_predict": self.max_tokens,
            },
        }
        if json_mode:
            payload["format"] = "json"

        response = await self._client.post(
            f"{self.base_url}/api/chat",
            json=payload,
        )
        response.raise_for_status()
        data = response.json()
        return data["message"]["content"]

    async def stream_chat(
        self,
        messages: List[Dict[str, str]],
        system: str = "",
        context: str = "",
        temperature: Optional[float] = None,
    ) -> AsyncGenerator[str, None]:
        """Streaming chat completion — yields text chunks."""
        payload = {
            "model": self.model,
            "messages": self._build_messages(system, messages, context),
            "stream": True,
            "options": {
                "temperature": temperature or self.temperature,
                "num_predict": self.max_tokens,
            },
        }

        async with self._client.stream(
            "POST",
            f"{self.base_url}/api/chat",
            json=payload,
        ) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if line:
                    try:
                        data = json.loads(line)
                        if not data.get("done", False):
                            content = data.get("message", {}).get("content", "")
                            if content:
                                yield content
                    except json.JSONDecodeError:
                        continue

    async def generate_json(
        self,
        prompt: str,
        system: str = "",
        schema_hint: str = "",
    ) -> Dict[str, Any]:
        """Generate structured JSON output."""
        full_system = f"{system}\n\nRespond ONLY with valid JSON. No explanation, no markdown.\n{schema_hint}"
        result = await self.chat(
            messages=[{"role": "user", "content": prompt}],
            system=full_system,
            json_mode=True,
        )
        try:
            return json.loads(result)
        except json.JSONDecodeError:
            # Try to extract JSON from the response
            import re
            match = re.search(r'\{.*\}', result, re.DOTALL)
            if match:
                return json.loads(match.group())
            return {"error": "Failed to parse JSON", "raw": result}

    async def check_health(self) -> bool:
        """Check if Ollama is available."""
        try:
            response = await self._client.get(f"{self.base_url}/api/tags", timeout=5.0)
            return response.status_code == 200
        except Exception:
            return False

    async def list_models(self) -> List[str]:
        """List available Ollama models."""
        response = await self._client.get(f"{self.base_url}/api/tags")
        data = response.json()
        return [m["name"] for m in data.get("models", [])]


# Singleton
_ollama: Optional[OllamaService] = None


def get_ollama() -> OllamaService:
    global _ollama
    if _ollama is None:
        _ollama = OllamaService()
    return _ollama
