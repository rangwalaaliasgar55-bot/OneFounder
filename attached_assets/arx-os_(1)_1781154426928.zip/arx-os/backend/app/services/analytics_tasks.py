"""
ARX OS — Analytics + Report Background Tasks
"""
from app.core.celery_app import celery_app


@celery_app.task(name="app.services.analytics_tasks.compute_daily_analytics")
def compute_daily_analytics():
    """Compute and cache daily analytics for all users."""
    import asyncio
    from app.db.session import AsyncSessionLocal
    from app.db.models import User, DailyAnalytics
    from sqlalchemy import select
    from datetime import date

    async def _run():
        async with AsyncSessionLocal() as db:
            users = await db.execute(select(User).where(User.is_active == True))
            today = date.today()

            for user in users.scalars().all():
                from app.api.routes.analytics import compute_date_range_metrics
                metrics = await compute_date_range_metrics(db, user.id, today, today)

                # Upsert daily analytics
                existing = await db.execute(
                    select(DailyAnalytics).where(
                        DailyAnalytics.user_id == user.id,
                        DailyAnalytics.analytics_date == today,
                    )
                )
                record = existing.scalar_one_or_none()
                if record:
                    record.metrics = metrics
                else:
                    record = DailyAnalytics(
                        user_id=user.id,
                        analytics_date=today,
                        metrics=metrics,
                    )
                    db.add(record)

                # Also update user metrics
                from app.memory.tasks import update_user_metrics
                update_user_metrics.delay(user.id)

            await db.commit()

    asyncio.get_event_loop().run_until_complete(_run())


@celery_app.task(name="app.services.report_tasks.generate_weekly_report")
def generate_weekly_report():
    """Auto-generate weekly reports for all active users."""
    import asyncio
    from app.db.session import AsyncSessionLocal
    from app.db.models import User
    from sqlalchemy import select

    async def _run():
        async with AsyncSessionLocal() as db:
            users = await db.execute(select(User).where(User.is_active == True))
            for user in users.scalars().all():
                from app.api.routes.analytics import compute_date_range_metrics
                from app.db.models import Report
                from app.services.ollama_service import get_ollama
                from datetime import date, timedelta
                import json

                today = date.today()
                start = today - timedelta(days=7)
                metrics = await compute_date_range_metrics(db, user.id, start, today)

                ollama = get_ollama()
                try:
                    summary = await ollama.chat(
                        messages=[{"role": "user", "content": f"Weekly data: {json.dumps(metrics, indent=2)}\n\nWrite a concise weekly review highlighting key achievements, patterns, and recommendations for next week. Keep it personal and motivating, under 400 words."}],
                        system="You are ARX, a personal AI coach writing a private weekly report.",
                    )
                except Exception:
                    summary = "Weekly report generation failed - Ollama unavailable."

                report = Report(
                    user_id=user.id,
                    report_type="weekly",
                    period_start=start,
                    period_end=today,
                    title=f"Weekly Report — {today.strftime('%B %d, %Y')}",
                    content=metrics,
                    ai_summary=summary,
                )
                db.add(report)

            await db.commit()

    asyncio.get_event_loop().run_until_complete(_run())
