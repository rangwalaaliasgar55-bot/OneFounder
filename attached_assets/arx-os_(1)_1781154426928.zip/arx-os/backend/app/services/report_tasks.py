# Re-exported from analytics_tasks
from app.services.analytics_tasks import generate_weekly_report
__all__ = ["generate_weekly_report"]
