"""
ARX OS — All Database Models
"""
import uuid
from datetime import datetime, date
from typing import Optional, List
from enum import Enum as PyEnum

from sqlalchemy import (
    String, Text, Boolean, Integer, Float, DateTime, Date,
    ForeignKey, JSON, Enum, UniqueConstraint, Index
)
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.sql import func

from app.db.session import Base


def gen_uuid():
    return str(uuid.uuid4())


# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS
# ═══════════════════════════════════════════════════════════════════════════════

class GoalStatus(str, PyEnum):
    ACTIVE = "active"
    COMPLETED = "completed"
    PAUSED = "paused"
    ABANDONED = "abandoned"

class GoalCategory(str, PyEnum):
    CAREER = "career"
    STARTUP = "startup"
    LEARNING = "learning"
    HEALTH = "health"
    FINANCE = "finance"
    PERSONAL = "personal"
    RELATIONSHIP = "relationship"

class HabitFrequency(str, PyEnum):
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"

class ProjectStatus(str, PyEnum):
    PLANNING = "planning"
    ACTIVE = "active"
    ON_HOLD = "on_hold"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

class TaskStatus(str, PyEnum):
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    DONE = "done"
    BLOCKED = "blocked"

class TaskPriority(str, PyEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"

class LearningStatus(str, PyEnum):
    PLANNED = "planned"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    DROPPED = "dropped"

class MemoryType(str, PyEnum):
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    PROCEDURAL = "procedural"
    REFLECTION = "reflection"

class MessageRole(str, PyEnum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


# ═══════════════════════════════════════════════════════════════════════════════
# USER
# ═══════════════════════════════════════════════════════════════════════════════

class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    username: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    email: Mapped[Optional[str]] = mapped_column(String(255), unique=True, nullable=True)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    display_name: Mapped[Optional[str]] = mapped_column(String(100))
    avatar_url: Mapped[Optional[str]] = mapped_column(String(500))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    timezone: Mapped[str] = mapped_column(String(50), default="UTC")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    last_seen: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))

    # Relationships
    profile: Mapped[Optional["UserProfile"]] = relationship("UserProfile", back_populates="user", uselist=False)
    conversations: Mapped[List["Conversation"]] = relationship("Conversation", back_populates="user")
    goals: Mapped[List["Goal"]] = relationship("Goal", back_populates="user")
    projects: Mapped[List["Project"]] = relationship("Project", back_populates="user")
    habits: Mapped[List["Habit"]] = relationship("Habit", back_populates="user")
    memories: Mapped[List["Memory"]] = relationship("Memory", back_populates="user")


class UserProfile(Base):
    """Evolving user profile — updated automatically by the AI."""
    __tablename__ = "user_profiles"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), unique=True)

    # Personal
    bio: Mapped[Optional[str]] = mapped_column(Text)
    occupation: Mapped[Optional[str]] = mapped_column(String(200))
    location: Mapped[Optional[str]] = mapped_column(String(200))

    # Skills (JSON array)
    skills: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)  # [{name, level, category}]
    strengths: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    weaknesses: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    interests: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    values: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)

    # Career
    career_stage: Mapped[Optional[str]] = mapped_column(String(100))
    industry: Mapped[Optional[str]] = mapped_column(String(100))
    experience_years: Mapped[Optional[int]] = mapped_column(Integer)
    career_goals: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)

    # Personality / Work style
    work_style: Mapped[Optional[dict]] = mapped_column(JSONB, default=dict)  # {peak_hours, focus_duration, etc}
    personality_traits: Mapped[Optional[dict]] = mapped_column(JSONB, default=dict)
    communication_style: Mapped[Optional[str]] = mapped_column(String(100))

    # Aggregated metrics
    productivity_score: Mapped[Optional[float]] = mapped_column(Float, default=0.0)
    learning_velocity: Mapped[Optional[float]] = mapped_column(Float, default=0.0)
    goal_completion_rate: Mapped[Optional[float]] = mapped_column(Float, default=0.0)
    habit_adherence_rate: Mapped[Optional[float]] = mapped_column(Float, default=0.0)

    # AI-inferred context
    current_focus: Mapped[Optional[str]] = mapped_column(Text)
    ai_observations: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    profile_version: Mapped[int] = mapped_column(Integer, default=1)

    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    user: Mapped["User"] = relationship("User", back_populates="profile")


# ═══════════════════════════════════════════════════════════════════════════════
# CONVERSATIONS & MESSAGES
# ═══════════════════════════════════════════════════════════════════════════════

class Conversation(Base):
    __tablename__ = "conversations"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    title: Mapped[Optional[str]] = mapped_column(String(500))
    agent_type: Mapped[str] = mapped_column(String(50), default="master")
    summary: Mapped[Optional[str]] = mapped_column(Text)
    context_tags: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    is_archived: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    user: Mapped["User"] = relationship("User", back_populates="conversations")
    messages: Mapped[List["Message"]] = relationship("Message", back_populates="conversation", order_by="Message.created_at")

    __table_args__ = (Index("ix_conversations_user_id", "user_id"),)


class Message(Base):
    __tablename__ = "messages"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    conversation_id: Mapped[str] = mapped_column(String(36), ForeignKey("conversations.id"), nullable=False)
    role: Mapped[str] = mapped_column(Enum(MessageRole), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    tokens_used: Mapped[Optional[int]] = mapped_column(Integer)
    model_used: Mapped[Optional[str]] = mapped_column(String(100))
    memory_refs: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)  # vector IDs referenced
    metadata: Mapped[Optional[dict]] = mapped_column(JSONB, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    conversation: Mapped["Conversation"] = relationship("Conversation", back_populates="messages")

    __table_args__ = (Index("ix_messages_conversation_id", "conversation_id"),)


# ═══════════════════════════════════════════════════════════════════════════════
# MEMORY SYSTEM
# ═══════════════════════════════════════════════════════════════════════════════

class Memory(Base):
    """Structured memory entries with vector embeddings stored in Qdrant."""
    __tablename__ = "memories"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    memory_type: Mapped[str] = mapped_column(Enum(MemoryType), nullable=False)
    title: Mapped[Optional[str]] = mapped_column(String(500))
    content: Mapped[str] = mapped_column(Text, nullable=False)
    source: Mapped[Optional[str]] = mapped_column(String(100))  # conversation, manual, agent
    source_id: Mapped[Optional[str]] = mapped_column(String(36))  # conversation_id, etc
    importance: Mapped[float] = mapped_column(Float, default=0.5)  # 0-1
    tags: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    vector_id: Mapped[Optional[str]] = mapped_column(String(36))  # Qdrant point ID
    access_count: Mapped[int] = mapped_column(Integer, default=0)
    last_accessed: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    user: Mapped["User"] = relationship("User", back_populates="memories")

    __table_args__ = (
        Index("ix_memories_user_type", "user_id", "memory_type"),
        Index("ix_memories_user_id", "user_id"),
    )


# ═══════════════════════════════════════════════════════════════════════════════
# GOALS
# ═══════════════════════════════════════════════════════════════════════════════

class Goal(Base):
    __tablename__ = "goals"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    parent_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("goals.id"))
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    category: Mapped[str] = mapped_column(Enum(GoalCategory), default=GoalCategory.PERSONAL)
    status: Mapped[str] = mapped_column(Enum(GoalStatus), default=GoalStatus.ACTIVE)
    priority: Mapped[int] = mapped_column(Integer, default=3)  # 1-5
    progress: Mapped[float] = mapped_column(Float, default=0.0)  # 0-100
    target_date: Mapped[Optional[date]] = mapped_column(Date)
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    milestones: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    metrics: Mapped[Optional[dict]] = mapped_column(JSONB, default=dict)
    ai_suggestions: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    user: Mapped["User"] = relationship("User", back_populates="goals")
    children: Mapped[List["Goal"]] = relationship("Goal", back_populates="parent")
    parent: Mapped[Optional["Goal"]] = relationship("Goal", back_populates="children", remote_side="Goal.id")

    __table_args__ = (Index("ix_goals_user_id", "user_id"),)


class GoalCheckIn(Base):
    __tablename__ = "goal_checkins"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    goal_id: Mapped[str] = mapped_column(String(36), ForeignKey("goals.id"), nullable=False)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    progress: Mapped[float] = mapped_column(Float)
    notes: Mapped[Optional[str]] = mapped_column(Text)
    mood: Mapped[Optional[int]] = mapped_column(Integer)  # 1-5
    blockers: Mapped[Optional[str]] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


# ═══════════════════════════════════════════════════════════════════════════════
# PROJECTS & TASKS
# ═══════════════════════════════════════════════════════════════════════════════

class Project(Base):
    __tablename__ = "projects"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    goal_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("goals.id"))
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    status: Mapped[str] = mapped_column(Enum(ProjectStatus), default=ProjectStatus.PLANNING)
    category: Mapped[Optional[str]] = mapped_column(String(100))
    start_date: Mapped[Optional[date]] = mapped_column(Date)
    end_date: Mapped[Optional[date]] = mapped_column(Date)
    progress: Mapped[float] = mapped_column(Float, default=0.0)
    tags: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    metadata: Mapped[Optional[dict]] = mapped_column(JSONB, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    user: Mapped["User"] = relationship("User", back_populates="projects")
    tasks: Mapped[List["Task"]] = relationship("Task", back_populates="project")

    __table_args__ = (Index("ix_projects_user_id", "user_id"),)


class Task(Base):
    __tablename__ = "tasks"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    project_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("projects.id"))
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    parent_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("tasks.id"))
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    status: Mapped[str] = mapped_column(Enum(TaskStatus), default=TaskStatus.TODO)
    priority: Mapped[str] = mapped_column(Enum(TaskPriority), default=TaskPriority.MEDIUM)
    due_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    estimated_minutes: Mapped[Optional[int]] = mapped_column(Integer)
    actual_minutes: Mapped[Optional[int]] = mapped_column(Integer)
    tags: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    project: Mapped[Optional["Project"]] = relationship("Project", back_populates="tasks")
    subtasks: Mapped[List["Task"]] = relationship("Task", back_populates="parent_task")
    parent_task: Mapped[Optional["Task"]] = relationship("Task", back_populates="subtasks", remote_side="Task.id")

    __table_args__ = (
        Index("ix_tasks_user_id", "user_id"),
        Index("ix_tasks_project_id", "project_id"),
    )


# ═══════════════════════════════════════════════════════════════════════════════
# HABITS
# ═══════════════════════════════════════════════════════════════════════════════

class Habit(Base):
    __tablename__ = "habits"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    frequency: Mapped[str] = mapped_column(Enum(HabitFrequency), default=HabitFrequency.DAILY)
    target_count: Mapped[int] = mapped_column(Integer, default=1)
    unit: Mapped[Optional[str]] = mapped_column(String(50))  # minutes, reps, pages, etc
    color: Mapped[Optional[str]] = mapped_column(String(7))  # hex color
    icon: Mapped[Optional[str]] = mapped_column(String(50))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    streak_current: Mapped[int] = mapped_column(Integer, default=0)
    streak_best: Mapped[int] = mapped_column(Integer, default=0)
    total_completions: Mapped[int] = mapped_column(Integer, default=0)
    category: Mapped[Optional[str]] = mapped_column(String(50))
    cue: Mapped[Optional[str]] = mapped_column(Text)  # habit cue/trigger
    reward: Mapped[Optional[str]] = mapped_column(Text)  # habit reward
    start_date: Mapped[Optional[date]] = mapped_column(Date)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    user: Mapped["User"] = relationship("User", back_populates="habits")
    logs: Mapped[List["HabitLog"]] = relationship("HabitLog", back_populates="habit")

    __table_args__ = (Index("ix_habits_user_id", "user_id"),)


class HabitLog(Base):
    __tablename__ = "habit_logs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    habit_id: Mapped[str] = mapped_column(String(36), ForeignKey("habits.id"), nullable=False)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    completed_date: Mapped[date] = mapped_column(Date, nullable=False)
    count: Mapped[float] = mapped_column(Float, default=1.0)
    notes: Mapped[Optional[str]] = mapped_column(Text)
    mood: Mapped[Optional[int]] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    habit: Mapped["Habit"] = relationship("Habit", back_populates="logs")

    __table_args__ = (
        UniqueConstraint("habit_id", "completed_date", name="uq_habit_log_date"),
        Index("ix_habit_logs_user_date", "user_id", "completed_date"),
    )


# ═══════════════════════════════════════════════════════════════════════════════
# LEARNING
# ═══════════════════════════════════════════════════════════════════════════════

class LearningItem(Base):
    __tablename__ = "learning_items"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    resource_type: Mapped[str] = mapped_column(String(50))  # book, course, video, article, podcast
    resource_url: Mapped[Optional[str]] = mapped_column(String(1000))
    author: Mapped[Optional[str]] = mapped_column(String(200))
    category: Mapped[Optional[str]] = mapped_column(String(100))
    tags: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    status: Mapped[str] = mapped_column(Enum(LearningStatus), default=LearningStatus.PLANNED)
    progress: Mapped[float] = mapped_column(Float, default=0.0)
    total_pages: Mapped[Optional[int]] = mapped_column(Integer)
    current_page: Mapped[Optional[int]] = mapped_column(Integer)
    duration_hours: Mapped[Optional[float]] = mapped_column(Float)
    hours_spent: Mapped[float] = mapped_column(Float, default=0.0)
    rating: Mapped[Optional[int]] = mapped_column(Integer)  # 1-5
    key_insights: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    notes: Mapped[Optional[str]] = mapped_column(Text)
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    __table_args__ = (Index("ix_learning_user_id", "user_id"),)


class LearningSession(Base):
    __tablename__ = "learning_sessions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    learning_item_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("learning_items.id"))
    duration_minutes: Mapped[int] = mapped_column(Integer, nullable=False)
    topic: Mapped[Optional[str]] = mapped_column(String(300))
    notes: Mapped[Optional[str]] = mapped_column(Text)
    focus_score: Mapped[Optional[float]] = mapped_column(Float)
    session_date: Mapped[date] = mapped_column(Date, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (Index("ix_learning_sessions_user_date", "user_id", "session_date"),)


# ═══════════════════════════════════════════════════════════════════════════════
# REFLECTION / JOURNAL
# ═══════════════════════════════════════════════════════════════════════════════

class Reflection(Base):
    __tablename__ = "reflections"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    reflection_type: Mapped[str] = mapped_column(String(50))  # daily, weekly, monthly, quarterly, annual, decision
    title: Mapped[Optional[str]] = mapped_column(String(500))
    content: Mapped[str] = mapped_column(Text, nullable=False)
    mood: Mapped[Optional[int]] = mapped_column(Integer)  # 1-5
    energy: Mapped[Optional[int]] = mapped_column(Integer)  # 1-5
    wins: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    challenges: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    lessons: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    gratitude: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    next_actions: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    ai_insights: Mapped[Optional[str]] = mapped_column(Text)
    tags: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    reflection_date: Mapped[date] = mapped_column(Date, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    __table_args__ = (Index("ix_reflections_user_date", "user_id", "reflection_date"),)


class DecisionJournal(Base):
    __tablename__ = "decision_journal"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    context: Mapped[str] = mapped_column(Text, nullable=False)
    options_considered: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    decision_made: Mapped[str] = mapped_column(Text, nullable=False)
    rationale: Mapped[Optional[str]] = mapped_column(Text)
    expected_outcome: Mapped[Optional[str]] = mapped_column(Text)
    actual_outcome: Mapped[Optional[str]] = mapped_column(Text)
    lesson_learned: Mapped[Optional[str]] = mapped_column(Text)
    confidence_level: Mapped[Optional[int]] = mapped_column(Integer)  # 1-10
    reversibility: Mapped[Optional[str]] = mapped_column(String(50))  # reversible, irreversible, partially
    follow_up_date: Mapped[Optional[date]] = mapped_column(Date)
    tags: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    __table_args__ = (Index("ix_decisions_user_id", "user_id"),)


# ═══════════════════════════════════════════════════════════════════════════════
# KNOWLEDGE GRAPH
# ═══════════════════════════════════════════════════════════════════════════════

class KnowledgeNode(Base):
    __tablename__ = "knowledge_nodes"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    content: Mapped[Optional[str]] = mapped_column(Text)
    node_type: Mapped[str] = mapped_column(String(50))  # concept, skill, person, book, project, etc
    tags: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    properties: Mapped[Optional[dict]] = mapped_column(JSONB, default=dict)
    vector_id: Mapped[Optional[str]] = mapped_column(String(36))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    __table_args__ = (Index("ix_knowledge_nodes_user_id", "user_id"),)


class KnowledgeEdge(Base):
    __tablename__ = "knowledge_edges"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    source_id: Mapped[str] = mapped_column(String(36), ForeignKey("knowledge_nodes.id"), nullable=False)
    target_id: Mapped[str] = mapped_column(String(36), ForeignKey("knowledge_nodes.id"), nullable=False)
    relationship: Mapped[str] = mapped_column(String(100))  # relates_to, leads_to, requires, contradicts
    weight: Mapped[float] = mapped_column(Float, default=1.0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint("source_id", "target_id", "relationship", name="uq_knowledge_edge"),
    )


# ═══════════════════════════════════════════════════════════════════════════════
# FINANCE
# ═══════════════════════════════════════════════════════════════════════════════

class FinanceEntry(Base):
    __tablename__ = "finance_entries"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    entry_type: Mapped[str] = mapped_column(String(20))  # income, expense, investment, saving
    category: Mapped[str] = mapped_column(String(100))
    amount: Mapped[float] = mapped_column(Float, nullable=False)
    currency: Mapped[str] = mapped_column(String(3), default="USD")
    description: Mapped[Optional[str]] = mapped_column(Text)
    tags: Mapped[Optional[dict]] = mapped_column(JSONB, default=list)
    entry_date: Mapped[date] = mapped_column(Date, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (Index("ix_finance_user_date", "user_id", "entry_date"),)


# ═══════════════════════════════════════════════════════════════════════════════
# ANALYTICS
# ═══════════════════════════════════════════════════════════════════════════════

class DailyAnalytics(Base):
    __tablename__ = "daily_analytics"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    analytics_date: Mapped[date] = mapped_column(Date, nullable=False)
    metrics: Mapped[dict] = mapped_column(JSONB, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        UniqueConstraint("user_id", "analytics_date", name="uq_daily_analytics"),
        Index("ix_daily_analytics_user_date", "user_id", "analytics_date"),
    )


class Report(Base):
    __tablename__ = "reports"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    report_type: Mapped[str] = mapped_column(String(20))  # daily, weekly, monthly, quarterly, annual
    period_start: Mapped[date] = mapped_column(Date, nullable=False)
    period_end: Mapped[date] = mapped_column(Date, nullable=False)
    title: Mapped[str] = mapped_column(String(500))
    content: Mapped[dict] = mapped_column(JSONB, default=dict)
    ai_summary: Mapped[Optional[str]] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (Index("ix_reports_user_id", "user_id"),)


# ═══════════════════════════════════════════════════════════════════════════════
# AUDIT LOG
# ═══════════════════════════════════════════════════════════════════════════════

class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"), nullable=False)
    action: Mapped[str] = mapped_column(String(100), nullable=False)
    resource_type: Mapped[Optional[str]] = mapped_column(String(50))
    resource_id: Mapped[Optional[str]] = mapped_column(String(36))
    details: Mapped[Optional[dict]] = mapped_column(JSONB, default=dict)
    ip_address: Mapped[Optional[str]] = mapped_column(String(45))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (Index("ix_audit_logs_user_id", "user_id"),)
