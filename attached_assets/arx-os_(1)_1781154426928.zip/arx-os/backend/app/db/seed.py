"""
ARX OS — Database Seed
Creates the initial admin user and default data.
"""
import asyncio
from app.db.session import AsyncSessionLocal, init_db
from app.db.models import User, UserProfile
from app.core.security import hash_password


async def seed():
    await init_db()
    async with AsyncSessionLocal() as session:
        # Check if admin exists
        from sqlalchemy import select
        result = await session.execute(select(User).where(User.username == "admin"))
        if result.scalar_one_or_none():
            print("Admin user already exists, skipping seed.")
            return

        admin = User(
            username="admin",
            email="admin@arxos.local",
            hashed_password=hash_password("arxos2024"),
            display_name="System Admin",
            is_admin=True,
        )
        session.add(admin)
        await session.flush()

        profile = UserProfile(
            user_id=admin.id,
            bio="ARX OS system administrator",
            skills=[],
            strengths=[],
            weaknesses=[],
            interests=[],
            values=[],
            career_goals=[],
            work_style={},
            personality_traits={},
            ai_observations=[],
        )
        session.add(profile)
        await session.commit()
        print(f"✓ Admin user created: admin / arxos2024")
        print(f"  User ID: {admin.id}")


if __name__ == "__main__":
    asyncio.run(seed())
