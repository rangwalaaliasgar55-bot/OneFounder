"""
ARX OS — Base Agent
All specialized agents inherit from this.
"""
from typing import List, Dict, Any, Optional, AsyncGenerator
from abc import ABC, abstractmethod

from app.services.ollama_service import get_ollama
from app.memory.manager import MemoryManager


class BaseAgent(ABC):
    """Base class for all ARX OS agents."""

    SYSTEM_PROMPT = "You are ARX, a helpful AI assistant."

    def __init__(self, db, user_id: str):
        self.db = db
        self.user_id = user_id
        self.ollama = get_ollama()
        self.memory = MemoryManager(db)

    def build_system(self, profile: Optional[Dict] = None) -> str:
        """Build system prompt with optional profile injection."""
        if not profile:
            return self.SYSTEM_PROMPT
        profile_summary = self._summarize_profile(profile)
        return f"{self.SYSTEM_PROMPT}\n\n[User Context]\n{profile_summary}"

    def _summarize_profile(self, profile: Dict) -> str:
        lines = []
        if profile.get("occupation"):
            lines.append(f"Occupation: {profile['occupation']}")
        if profile.get("skills"):
            skills = [s.get("name", s) if isinstance(s, dict) else s for s in profile["skills"][:8]]
            lines.append(f"Skills: {', '.join(skills)}")
        if profile.get("career_goals"):
            goals = profile["career_goals"][:3]
            lines.append(f"Career Goals: {', '.join(str(g) for g in goals)}")
        if profile.get("current_focus"):
            lines.append(f"Current Focus: {profile['current_focus']}")
        return "\n".join(lines) if lines else "No profile data available"

    async def stream_response(
        self,
        message: str,
        history: List[Dict[str, str]],
        context: str = "",
        profile: Optional[Dict] = None,
    ) -> AsyncGenerator[str, None]:
        """Stream a response using this agent's system prompt."""
        messages = [{"role": h["role"], "content": h["content"]} for h in history[-8:]]
        messages.append({"role": "user", "content": message})

        async for chunk in self.ollama.stream_chat(
            messages=messages,
            system=self.build_system(profile),
            context=context,
        ):
            yield chunk

    async def analyze(self, prompt: str, context: str = "") -> Dict[str, Any]:
        """Generate a structured JSON analysis."""
        result = await self.ollama.generate_json(
            prompt=prompt,
            system=self.SYSTEM_PROMPT,
        )
        return result
