"""
ARX OS — Specialized Agents
"""
import json
from typing import List, Dict, Any, Optional, AsyncGenerator

from app.agents.base_agent import BaseAgent


# ═══════════════════════════════════════════════════════════════════════════════
# CAREER AGENT
# ═══════════════════════════════════════════════════════════════════════════════

class CareerAgent(BaseAgent):
    SYSTEM_PROMPT = """You are ARX Career — an elite career strategist and advisor.

Your expertise:
- Skill gap analysis against target roles/industries
- Career roadmap generation with concrete milestones
- Portfolio and certification advice
- Job market intelligence and trends
- Interview preparation and negotiation
- Personal brand building
- Network strategy

Your approach:
- Be brutally honest about gaps and opportunities
- Give specific, actionable recommendations
- Think in 1-year and 5-year timeframes
- Always connect career advice to the user's broader life goals
- Use data-driven reasoning

Format your responses with clear sections when doing analysis.
Always end with 2-3 concrete next actions the user can take this week."""

    async def analyze_skill_gaps(
        self, current_skills: List[str], target_role: str
    ) -> Dict[str, Any]:
        """Perform skill gap analysis for a target role."""
        return await self.analyze(
            prompt=f"""Current skills: {json.dumps(current_skills)}
Target role: {target_role}

Analyze the skill gaps. Return JSON:
{{
  "target_role": "{target_role}",
  "required_skills": ["skill1", ...],
  "gaps": ["missing_skill1", ...],
  "strengths": ["existing_strength1", ...],
  "priority_skills": ["high_priority1", ...],
  "timeline_months": 6,
  "learning_resources": [{{"skill": "x", "resource": "y", "time_weeks": 4}}],
  "readiness_score": 0.65
}}""",
        )

    async def generate_career_roadmap(
        self, current_state: str, target: str, timeline_months: int = 12
    ) -> Dict[str, Any]:
        """Generate a detailed career roadmap."""
        return await self.analyze(
            prompt=f"""Current state: {current_state}
Career target: {target}
Timeline: {timeline_months} months

Generate a detailed roadmap. Return JSON:
{{
  "title": "Career Roadmap",
  "milestones": [
    {{"month": 1, "milestone": "...", "actions": ["action1"], "metrics": "how to measure"}}
  ],
  "skills_to_acquire": [],
  "certifications": [],
  "projects_to_build": [],
  "network_targets": [],
  "monthly_focus": {{}}
}}""",
        )


# ═══════════════════════════════════════════════════════════════════════════════
# STARTUP AGENT
# ═══════════════════════════════════════════════════════════════════════════════

class StartupAgent(BaseAgent):
    SYSTEM_PROMPT = """You are ARX Venture — a seasoned startup advisor and entrepreneur.

Your expertise:
- Startup idea evaluation (problem, market, solution fit)
- Business model analysis and revenue strategy
- Market sizing (TAM, SAM, SOM)
- Competitive landscape analysis
- MVP scoping and validation frameworks
- Fundraising strategy and investor readiness
- Go-to-market planning
- Unit economics and financial modeling

Your approach:
- Apply first-principles thinking
- Be ruthlessly honest about startup viability
- Focus on what can be validated with minimal resources
- Think about moats and defensibility
- Always ask: "Who specifically will pay for this, and why?"

Use frameworks: Jobs-to-be-done, Value Proposition Canvas, Lean Canvas."""

    async def evaluate_idea(self, idea: str, context: str = "") -> Dict[str, Any]:
        """Evaluate a startup idea across key dimensions."""
        return await self.analyze(
            prompt=f"""Evaluate this startup idea: {idea}
Context: {context}

Return JSON:
{{
  "idea": "{idea}",
  "problem_clarity": 1-10,
  "market_size": "small/medium/large/massive",
  "competition": "low/medium/high/saturated",
  "moat_potential": 1-10,
  "technical_complexity": 1-10,
  "capital_intensity": 1-10,
  "go_to_market_clarity": 1-10,
  "overall_score": 1-10,
  "strengths": [],
  "risks": [],
  "validation_experiments": [],
  "mvp_suggestion": "...",
  "verdict": "strong/moderate/weak/pivot"
}}""",
        )

    async def create_lean_canvas(self, idea: str) -> Dict[str, Any]:
        """Generate a Lean Canvas for a business idea."""
        return await self.analyze(
            prompt=f"""Create a Lean Canvas for: {idea}

Return JSON:
{{
  "problem": ["top3 problems"],
  "customer_segments": ["segment1"],
  "unique_value_proposition": "...",
  "solution": ["feature1"],
  "channels": ["channel1"],
  "revenue_streams": ["stream1"],
  "cost_structure": ["cost1"],
  "key_metrics": ["metric1"],
  "unfair_advantage": "..."
}}""",
        )


# ═══════════════════════════════════════════════════════════════════════════════
# LEARNING AGENT
# ═══════════════════════════════════════════════════════════════════════════════

class LearningAgent(BaseAgent):
    SYSTEM_PROMPT = """You are ARX Learn — a master learning coach and educational strategist.

Your expertise:
- Personalized learning path design
- Spaced repetition and retention optimization
- Learning resource curation and evaluation
- Knowledge synthesis and mental model building
- Skill acquisition frameworks
- Study system design (Zettelkasten, Cornell, etc.)
- Learning analytics and progress tracking

Your philosophy:
- Understanding > memorization
- Active recall > passive reading
- Teach to learn
- Build on existing mental models
- Learn in public

Always suggest specific, high-quality resources. Calibrate recommendations to the user's current level."""

    async def create_learning_path(
        self, topic: str, current_level: str, target_level: str, timeline_weeks: int
    ) -> Dict[str, Any]:
        """Design a structured learning path."""
        return await self.analyze(
            prompt=f"""Design a learning path:
Topic: {topic}
Current level: {current_level}
Target level: {target_level}
Timeline: {timeline_weeks} weeks

Return JSON:
{{
  "topic": "{topic}",
  "phases": [
    {{
      "week_range": "1-2",
      "focus": "...",
      "resources": [{{"title": "...", "type": "book|course|video", "hours": 10}}],
      "projects": [],
      "milestones": []
    }}
  ],
  "weekly_hours_recommended": 10,
  "key_concepts": [],
  "assessment_methods": []
}}""",
        )

    async def synthesize_insights(self, learning_notes: str) -> Dict[str, Any]:
        """Extract key insights from learning notes."""
        return await self.analyze(
            prompt=f"""Synthesize insights from these learning notes:
{learning_notes}

Return JSON:
{{
  "key_concepts": [],
  "mental_models": [],
  "applications": [],
  "connections_to_other_topics": [],
  "open_questions": [],
  "summary": "2-3 sentence summary"
}}""",
        )


# ═══════════════════════════════════════════════════════════════════════════════
# PRODUCTIVITY AGENT
# ═══════════════════════════════════════════════════════════════════════════════

class ProductivityAgent(BaseAgent):
    SYSTEM_PROMPT = """You are ARX Flow — a world-class productivity coach and systems designer.

Your expertise:
- Deep work optimization
- Time blocking and scheduling
- Task prioritization (Eisenhower Matrix, MoSCoW)
- Energy management throughout the day
- Focus score analysis
- Weekly review facilitation
- Habit systems design
- Procrastination analysis and interventions
- Decision fatigue reduction
- Personal productivity stack design

Your frameworks:
- GTD (Getting Things Done)
- Time Blocking
- The ONE Thing
- Eat the Frog
- Pomodoro Technique
- Weekly reviews

Be concrete. Give specific time blocks, specific tasks, specific systems."""

    async def plan_week(
        self, goals: List[str], tasks: List[Dict], habits: List[str]
    ) -> Dict[str, Any]:
        """Generate a weekly plan."""
        return await self.analyze(
            prompt=f"""Plan the week:
Goals: {json.dumps(goals)}
Tasks: {json.dumps(tasks[:20])}
Habits: {json.dumps(habits)}

Return JSON:
{{
  "weekly_theme": "...",
  "top_3_priorities": [],
  "daily_blocks": {{
    "monday": [{{"time": "09:00", "duration_min": 90, "task": "...", "type": "deep_work|admin|meeting|habit"}}],
    ...
  }},
  "time_budget": {{"deep_work": 15, "admin": 5, "learning": 5}},
  "risk_factors": [],
  "defer_list": []
}}""",
        )

    async def analyze_focus_patterns(self, sessions: List[Dict]) -> Dict[str, Any]:
        """Analyze focus and productivity patterns."""
        return await self.analyze(
            prompt=f"""Analyze these productivity/focus sessions:
{json.dumps(sessions[:30])}

Return JSON:
{{
  "peak_hours": ["09:00-11:00"],
  "average_focus_score": 7.2,
  "best_session_conditions": [],
  "common_interruptions": [],
  "recommendations": [],
  "weekly_deep_work_hours": 12
}}""",
        )


# ═══════════════════════════════════════════════════════════════════════════════
# RESEARCH AGENT
# ═══════════════════════════════════════════════════════════════════════════════

class ResearchAgent(BaseAgent):
    SYSTEM_PROMPT = """You are ARX Research — a systematic research analyst and knowledge synthesizer.

Your expertise:
- Structured research and information synthesis
- Competitive intelligence gathering frameworks
- Industry trend analysis
- Literature review methodology
- Data interpretation and insight extraction
- Source evaluation and credibility assessment
- Research report generation
- Second-order thinking and implications analysis

Your approach:
- Structured, systematic analysis
- Multiple perspectives before conclusions
- Cite reasoning, not just conclusions
- Distinguish facts from inferences
- Identify information gaps

Note: You work from the user's existing knowledge and what they share with you.
You cannot browse the internet but can synthesize based on your training knowledge."""

    async def research_topic(self, topic: str, depth: str = "overview") -> Dict[str, Any]:
        """Generate a research brief on a topic."""
        return await self.analyze(
            prompt=f"""Research brief on: {topic} (depth: {depth})

Return JSON:
{{
  "topic": "{topic}",
  "executive_summary": "...",
  "key_findings": [],
  "market_trends": [],
  "key_players": [],
  "opportunities": [],
  "risks": [],
  "data_points": [],
  "further_research": [],
  "sources_to_check": []
}}""",
        )


# ═══════════════════════════════════════════════════════════════════════════════
# REFLECTION AGENT
# ═══════════════════════════════════════════════════════════════════════════════

class ReflectionAgent(BaseAgent):
    SYSTEM_PROMPT = """You are ARX Reflect — a Socratic guide for deep self-reflection and introspection.

Your role:
- Facilitate meaningful weekly, monthly, and quarterly reviews
- Help identify patterns in behavior, mood, and outcomes
- Surface lessons from experiences
- Challenge limiting beliefs with curiosity
- Help articulate values and priorities
- Guide decision journaling and post-mortems
- Generate personal insights from accumulated data

Your approach:
- Ask powerful questions
- Reflect back patterns you notice
- Connect current experiences to past patterns
- Be warm, non-judgmental, and honest
- Help distinguish between what matters and what doesn't

Facilitate, don't just answer. Help the user discover insights themselves."""

    async def generate_weekly_review(
        self, week_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Generate a weekly review based on data."""
        return await self.analyze(
            prompt=f"""Generate a weekly review based on this data:
{json.dumps(week_data, indent=2)}

Return JSON:
{{
  "week_summary": "...",
  "wins": [],
  "challenges": [],
  "lessons_learned": [],
  "patterns_noticed": [],
  "goal_progress_assessment": "...",
  "habit_adherence_insights": "...",
  "mood_energy_trend": "...",
  "key_reflection_questions": [],
  "next_week_focus": [],
  "gratitude_prompts": []
}}""",
        )

    async def analyze_decision(self, decision_context: str) -> Dict[str, Any]:
        """Help analyze a decision using structured frameworks."""
        return await self.analyze(
            prompt=f"""Help analyze this decision:
{decision_context}

Return JSON:
{{
  "decision_clarity": "...",
  "key_considerations": [],
  "option_analysis": [],
  "potential_regrets": [],
  "values_alignment": "...",
  "recommended_framework": "...",
  "questions_to_answer_first": [],
  "my_recommendation": "..."
}}""",
        )


# ═══════════════════════════════════════════════════════════════════════════════
# MEMORY AGENT
# ═══════════════════════════════════════════════════════════════════════════════

class MemoryAgent(BaseAgent):
    SYSTEM_PROMPT = """You are ARX Memory — the keeper of all personal knowledge and history.

Your role:
- Retrieve relevant memories and past context
- Help the user understand patterns across time
- Surface forgotten commitments, goals, or insights
- Connect related memories and experiences
- Maintain the user's knowledge graph
- Answer questions about past conversations and decisions

Always be precise about when things were recorded vs inferred.
Never fabricate memories — only work with what's been stored."""

    async def stream_response(
        self,
        message: str,
        history: List[Dict[str, str]],
        context: str = "",
        profile: Optional[Dict] = None,
    ) -> AsyncGenerator[str, None]:
        """Override to search memories before responding."""
        # Add explicit memory search instruction
        memory_context = context
        enhanced_message = f"""User query about their history/memory: {message}

Relevant stored memories:
{memory_context}

Answer based on the memories above. If no relevant memory found, say so clearly."""

        messages = [{"role": h["role"], "content": h["content"]} for h in history[-6:]]
        messages.append({"role": "user", "content": enhanced_message})

        async for chunk in self.ollama.stream_chat(
            messages=messages,
            system=self.SYSTEM_PROMPT,
        ):
            yield chunk
