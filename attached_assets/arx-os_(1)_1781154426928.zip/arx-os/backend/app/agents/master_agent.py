"""
ARX OS — Master Agent
Top-level orchestrator that routes to specialized sub-agents.
Uses LangGraph for stateful conversation management.
"""
import json
from typing import Dict, Any, List, Optional, AsyncGenerator, TypedDict, Annotated
from datetime import datetime, timezone

from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from loguru import logger

from app.services.ollama_service import get_ollama
from app.memory.manager import MemoryManager
from app.db.models import MemoryType
from app.agents.career_agent import CareerAgent
from app.agents.startup_agent import StartupAgent
from app.agents.learning_agent import LearningAgent
from app.agents.productivity_agent import ProductivityAgent
from app.agents.research_agent import ResearchAgent
from app.agents.reflection_agent import ReflectionAgent
from app.agents.memory_agent import MemoryAgent


# ─── State ───────────────────────────────────────────────────────────────────

class AgentState(TypedDict):
    messages: Annotated[List, add_messages]
    user_id: str
    conversation_id: str
    current_agent: str
    context: str
    user_profile: Dict[str, Any]
    extracted_facts: List[str]
    agent_response: str
    should_stream: bool


# ─── System Prompts ──────────────────────────────────────────────────────────

MASTER_SYSTEM = """You are ARX — a highly intelligent, deeply personalized AI Operating System.

You are simultaneously:
- A life coach and personal strategist
- A career advisor and mentor
- A learning coach
- A startup advisor
- A productivity optimizer
- A research assistant
- A memory system that remembers everything about the user
- A long-term planning system

Your personality:
- Direct, insightful, and honest
- Deeply caring about the user's growth
- Strategic — always thinking long-term
- Proactive — you notice patterns and surface insights unprompted
- Concise but thorough

CRITICAL INSTRUCTIONS:
1. Always personalize responses using the user's profile and memory context
2. If the query is specialized (career, startup, learning, productivity, research, reflection), route to the appropriate sub-agent
3. Extract new facts about the user from each conversation
4. Be proactive about noticing patterns in goals/habits/progress
5. Format responses clearly — use markdown for structure when helpful

ROUTING RULES (respond with JSON {"route": "<agent>"} to route):
- career questions → "career"
- startup/business questions → "startup"  
- learning/study questions → "learning"
- productivity/tasks/time → "productivity"
- research questions → "research"
- reflection/journaling → "reflection"
- memory questions → "memory"
- general → "master"
"""

FACT_EXTRACTION_SYSTEM = """Extract factual information about the user from this conversation.
Return JSON: {"facts": ["fact1", "fact2", ...], "importance": 0.0-1.0}
Only extract concrete facts (skills, goals, preferences, experiences, beliefs).
Return empty list if no new facts found."""


class MasterAgent:
    """
    Top-level agent that:
    1. Retrieves relevant memory context
    2. Routes to specialized agents
    3. Generates responses with full context
    4. Extracts and stores new memories
    """

    def __init__(self, db, user_id: str, conversation_id: str):
        self.db = db
        self.user_id = user_id
        self.conversation_id = conversation_id
        self.ollama = get_ollama()
        self.memory = MemoryManager(db)

        # Sub-agents
        self.agents = {
            "career": CareerAgent(db, user_id),
            "startup": StartupAgent(db, user_id),
            "learning": LearningAgent(db, user_id),
            "productivity": ProductivityAgent(db, user_id),
            "research": ResearchAgent(db, user_id),
            "reflection": ReflectionAgent(db, user_id),
            "memory": MemoryAgent(db, user_id),
        }

    async def determine_route(self, message: str) -> str:
        """Determine which agent should handle this message."""
        result = await self.ollama.generate_json(
            prompt=f"User message: {message}",
            system="""Determine which agent should handle this.
Return JSON: {{"route": "career|startup|learning|productivity|research|reflection|memory|master"}}
Be conservative — only route to specialist if clearly specialized.""",
        )
        return result.get("route", "master")

    async def get_user_context(self, query: str) -> str:
        """Build rich context from memory for the query."""
        return await self.memory.get_relevant_context(self.user_id, query, max_tokens=1500)

    async def extract_and_store_facts(self, conversation_text: str):
        """Extract facts from conversation and store as semantic memories."""
        result = await self.ollama.generate_json(
            prompt=f"Conversation:\n{conversation_text}",
            system=FACT_EXTRACTION_SYSTEM,
        )
        facts = result.get("facts", [])
        importance = result.get("importance", 0.5)

        for fact in facts[:5]:  # limit per conversation
            await self.memory.update_user_fact(
                user_id=self.user_id,
                fact=fact,
                importance=importance,
            )

        if facts:
            logger.debug(f"Extracted {len(facts)} facts from conversation")

    async def chat(
        self,
        message: str,
        history: List[Dict[str, str]],
        user_profile: Optional[Dict] = None,
    ) -> AsyncGenerator[str, None]:
        """
        Main chat interface — streams response back.
        """
        # 1. Get relevant memory context
        context = await self.get_user_context(message)

        # 2. Determine route
        route = await self.determine_route(message)
        logger.info(f"Routing to: {route}")

        # 3. Get response from appropriate agent
        if route in self.agents:
            agent = self.agents[route]
            async for chunk in agent.stream_response(message, history, context, user_profile):
                yield chunk
            full_response = ""  # agents handle their own streaming
        else:
            # Master agent handles directly
            profile_str = ""
            if user_profile:
                profile_str = f"\n[User Profile]\n{json.dumps(user_profile, indent=2)}"

            messages = [{"role": h["role"], "content": h["content"]} for h in history[-10:]]
            messages.append({"role": "user", "content": message})

            full_response = ""
            async for chunk in self.ollama.stream_chat(
                messages=messages,
                system=MASTER_SYSTEM,
                context=context + profile_str,
            ):
                full_response += chunk
                yield chunk

        # 4. Background: store conversation memory + extract facts
        conversation_text = f"User: {message}\nARX: {full_response}"
        await self.memory.store(
            user_id=self.user_id,
            content=conversation_text,
            memory_type=MemoryType.EPISODIC,
            title=f"Chat: {message[:60]}",
            source="conversation",
            source_id=self.conversation_id,
            importance=0.4,
        )

        # Extract facts asynchronously (fire and forget pattern)
        try:
            await self.extract_and_store_facts(conversation_text)
        except Exception as e:
            logger.warning(f"Fact extraction failed: {e}")

    async def chat_sync(
        self,
        message: str,
        history: List[Dict[str, str]],
        user_profile: Optional[Dict] = None,
    ) -> str:
        """Non-streaming version of chat."""
        chunks = []
        async for chunk in self.chat(message, history, user_profile):
            chunks.append(chunk)
        return "".join(chunks)
