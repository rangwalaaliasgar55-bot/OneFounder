# ARX OS — Personal AI Operating System

> Fully local, privacy-first Personal AI OS. Runs on your machine. Owns your data.

## Architecture

```
arx-os/
├── backend/                  # FastAPI Python backend
│   ├── app/
│   │   ├── agents/           # Multi-agent system (LangGraph)
│   │   ├── api/routes/       # REST API endpoints
│   │   ├── core/             # Config, security, logging
│   │   ├── db/               # PostgreSQL models + migrations
│   │   ├── memory/           # Memory subsystem (episodic/semantic/procedural)
│   │   ├── services/         # Business logic services
│   │   └── utils/            # Utilities
│   └── tests/
├── frontend/                 # Next.js 14 + TypeScript
│   └── src/
│       ├── app/              # App router pages
│       ├── components/       # React components
│       ├── hooks/            # Custom hooks
│       ├── lib/              # API clients, utils
│       ├── store/            # Zustand state
│       └── types/            # TypeScript types
├── infra/
│   ├── docker/               # Dockerfiles
│   ├── nginx/                # Reverse proxy config
│   └── scripts/              # Setup + migration scripts
└── docker-compose.yml
```

## Stack
- **Backend**: Python 3.11, FastAPI, SQLAlchemy, Alembic
- **Frontend**: Next.js 14, TypeScript, TailwindCSS, Zustand
- **Database**: PostgreSQL 15
- **Vector DB**: Qdrant
- **AI Runtime**: Ollama (llama3, mistral, nomic-embed-text)
- **Agents**: LangGraph
- **Voice**: Whisper (STT) + Piper (TTS)
- **Auth**: JWT (local accounts)
- **Containers**: Docker Compose

## Quick Start

```bash
# 1. Clone and enter
git clone <repo> && cd arx-os

# 2. Configure
cp .env.example .env

# 3. Pull Ollama models
ollama pull llama3
ollama pull nomic-embed-text

# 4. Start everything
docker-compose up -d

# 5. Initialize DB
docker-compose exec backend alembic upgrade head
docker-compose exec backend python -m app.db.seed

# 6. Open
open http://localhost:3000
```

## Default Credentials
- Username: `admin`
- Password: `arxos2024` (change immediately in Settings)
