/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // ARX OS Design System
        arx: {
          bg:       "#0a0a0f",
          surface:  "#111118",
          border:   "#1e1e2e",
          muted:    "#2a2a3e",
          accent:   "#6c63ff",
          "accent-dim": "#4a44b5",
          highlight:"#00d4aa",
          danger:   "#ff4757",
          warning:  "#ffa502",
          success:  "#2ed573",
          text:     "#e8e8f0",
          "text-muted": "#6b6b8a",
        },
      },
      fontFamily: {
        sans:  ["'DM Sans'", "system-ui", "sans-serif"],
        mono:  ["'JetBrains Mono'", "monospace"],
        display: ["'Syne'", "sans-serif"],
      },
      backgroundImage: {
        "arx-gradient": "linear-gradient(135deg, #6c63ff 0%, #00d4aa 100%)",
        "arx-dark":     "radial-gradient(ellipse at top, #111118 0%, #0a0a0f 100%)",
        "arx-glow":     "radial-gradient(circle at 50% 0%, rgba(108,99,255,0.15) 0%, transparent 60%)",
      },
      animation: {
        "fade-in":    "fadeIn 0.3s ease-out",
        "slide-up":   "slideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1)",
        "slide-down": "slideDown 0.3s ease-out",
        "pulse-glow": "pulseGlow 2s ease-in-out infinite",
        "typing":     "typing 1s steps(3) infinite",
      },
      keyframes: {
        fadeIn:    { from: { opacity: "0" }, to: { opacity: "1" } },
        slideUp:   { from: { transform: "translateY(12px)", opacity: "0" }, to: { transform: "translateY(0)", opacity: "1" } },
        slideDown: { from: { transform: "translateY(-8px)", opacity: "0" }, to: { transform: "translateY(0)", opacity: "1" } },
        pulseGlow: {
          "0%, 100%": { boxShadow: "0 0 0 0 rgba(108,99,255,0.3)" },
          "50%":      { boxShadow: "0 0 0 8px rgba(108,99,255,0)" },
        },
        typing: {
          "0%":   { content: "'▋'" },
          "50%":  { content: "''" },
          "100%": { content: "'▋'" },
        },
      },
      borderRadius: {
        "4xl": "2rem",
      },
    },
  },
  plugins: [],
};
