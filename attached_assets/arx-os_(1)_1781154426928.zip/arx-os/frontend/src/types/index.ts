// ═══════════════════════════════════════════════════════════
// ARX OS — TypeScript Type Definitions
// ═══════════════════════════════════════════════════════════

// ─── Auth ────────────────────────────────────────────────

export interface AuthTokens {
  access_token: string;
  refresh_token: string;
  token_type: string;
  user_id: string;
  username: string;
  display_name: string | null;
}

export interface User {
  id: string;
  username: string;
  email: string | null;
  display_name: string | null;
  avatar_url: string | null;
  is_admin: boolean;
  timezone: string;
  created_at: string;
}

// ─── Profile ─────────────────────────────────────────────

export interface Skill {
  name: string;
  level: "beginner" | "intermediate" | "advanced" | "expert";
  category?: string;
}

export interface UserProfile {
  bio: string | null;
  occupation: string | null;
  location: string | null;
  skills: Skill[];
  strengths: string[];
  weaknesses: string[];
  interests: string[];
  values: string[];
  career_stage: string | null;
  industry: string | null;
  experience_years: number | null;
  career_goals: string[];
  current_focus: string | null;
  work_style: Record<string, unknown>;
  productivity_score: number;
  learning_velocity: number;
  goal_completion_rate: number;
  habit_adherence_rate: number;
  ai_observations: string[];
}

// ─── Chat ────────────────────────────────────────────────

export interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  created_at: string;
}

export interface Conversation {
  id: string;
  title: string | null;
  agent_type: string;
  summary: string | null;
  created_at: string;
  updated_at: string;
}

// ─── Goals ───────────────────────────────────────────────

export type GoalStatus = "active" | "completed" | "paused" | "abandoned";
export type GoalCategory = "career" | "startup" | "learning" | "health" | "finance" | "personal" | "relationship";

export interface Goal {
  id: string;
  title: string;
  description: string | null;
  category: GoalCategory;
  status: GoalStatus;
  priority: number;
  progress: number;
  target_date: string | null;
  parent_id: string | null;
  milestones: Milestone[];
  created_at: string;
  updated_at: string;
}

export interface Milestone {
  title: string;
  completed: boolean;
  due_date?: string;
}

// ─── Projects ────────────────────────────────────────────

export type ProjectStatus = "planning" | "active" | "on_hold" | "completed" | "cancelled";
export type TaskStatus = "todo" | "in_progress" | "done" | "blocked";
export type TaskPriority = "low" | "medium" | "high" | "urgent";

export interface Project {
  id: string;
  title: string;
  description: string | null;
  status: ProjectStatus;
  category: string | null;
  progress: number;
  goal_id: string | null;
  start_date: string | null;
  end_date: string | null;
  tags: string[];
  task_count: number;
  tasks_done: number;
  created_at: string;
  updated_at: string;
}

export interface Task {
  id: string;
  title: string;
  description: string | null;
  status: TaskStatus;
  priority: TaskPriority;
  project_id: string | null;
  parent_id: string | null;
  due_date: string | null;
  estimated_minutes: number | null;
  completed_at: string | null;
  created_at: string;
}

// ─── Habits ──────────────────────────────────────────────

export type HabitFrequency = "daily" | "weekly" | "monthly";

export interface Habit {
  id: string;
  title: string;
  description: string | null;
  frequency: HabitFrequency;
  target_count: number;
  unit: string | null;
  color: string | null;
  icon: string | null;
  is_active: boolean;
  streak_current: number;
  streak_best: number;
  total_completions: number;
  category: string | null;
  created_at: string;
}

export interface HabitTodayStatus extends Habit {
  completed_today: boolean;
  today_count: number;
}

export interface HabitHeatmapEntry {
  date: string;
  count: number;
}

// ─── Learning ────────────────────────────────────────────

export type LearningStatus = "planned" | "in_progress" | "completed" | "dropped";
export type ResourceType = "book" | "course" | "video" | "article" | "podcast";

export interface LearningItem {
  id: string;
  title: string;
  description: string | null;
  resource_type: ResourceType;
  resource_url: string | null;
  author: string | null;
  category: string | null;
  status: LearningStatus;
  progress: number;
  hours_spent: number;
  rating: number | null;
  tags: string[];
  started_at: string | null;
  completed_at: string | null;
  created_at: string;
}

// ─── Memory ──────────────────────────────────────────────

export type MemoryType = "episodic" | "semantic" | "procedural" | "reflection";

export interface Memory {
  id: string;
  memory_type: MemoryType;
  title: string | null;
  content: string;
  importance: number;
  tags: string[];
  source: string | null;
  access_count: number;
  created_at: string;
}

export interface MemorySearchResult {
  id: string;
  score: number;
  payload: {
    content: string;
    memory_type: string;
    title: string;
    importance: number;
    created_at: string;
  };
}

// ─── Analytics ───────────────────────────────────────────

export interface DashboardMetrics {
  today: PeriodMetrics;
  this_week: PeriodMetrics;
  top_streaks: { title: string; streak: number; color: string }[];
  recent_completions: { title: string; completed_at: string }[];
}

export interface PeriodMetrics {
  period: { start: string; end: string; days: number };
  goals: { active: number; completed_in_period: number; avg_progress: number };
  tasks: { completed: number; created: number; completion_rate: number };
  habits: { active: number; completions: number; adherence_pct: number };
  learning: { minutes: number; hours: number; items_completed: number };
  conversations: number;
}

// ─── Finance ─────────────────────────────────────────────

export interface FinanceEntry {
  id: string;
  entry_type: "income" | "expense" | "investment" | "saving";
  category: string;
  amount: number;
  currency: string;
  description: string | null;
  entry_date: string;
}

export interface FinanceSummary {
  income: number;
  expenses: number;
  net: number;
  savings: number;
  investments: number;
  by_type: Record<string, number>;
}

// ─── Reflection ──────────────────────────────────────────

export interface Reflection {
  id: string;
  reflection_type: string;
  title: string | null;
  content: string;
  mood: number | null;
  energy: number | null;
  wins: string[];
  challenges: string[];
  lessons: string[];
  gratitude: string[];
  next_actions: string[];
  ai_insights: string | null;
  reflection_date: string;
  created_at: string;
}

// ─── Knowledge Graph ─────────────────────────────────────

export interface KnowledgeNode {
  id: string;
  title: string;
  type: string;
  tags: string[];
}

export interface KnowledgeEdge {
  source: string;
  target: string;
  relationship: string;
  weight: number;
}

export interface KnowledgeGraph {
  nodes: KnowledgeNode[];
  edges: KnowledgeEdge[];
}

// ─── Reports ─────────────────────────────────────────────

export interface Report {
  id: string;
  report_type: string;
  title: string;
  period_start: string;
  period_end: string;
  ai_summary: string | null;
  created_at: string;
}

// ─── API Response ─────────────────────────────────────────

export interface APIError {
  detail: string;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  size: number;
}
