// ═══════════════════════════════════════════════════════════
// ARX OS — API Client
// ═══════════════════════════════════════════════════════════
import axios, { AxiosInstance, AxiosError } from "axios";
import type {
  AuthTokens, User, UserProfile, Conversation, Message, Goal,
  GoalCategory, Project, Task, TaskPriority, Habit, HabitTodayStatus,
  LearningItem, LearningStatus, Memory, MemoryType, MemorySearchResult,
  DashboardMetrics, FinanceEntry, FinanceSummary, Reflection, Report,
  KnowledgeGraph,
} from "@/types";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

// ─── Axios Instance ────────────────────────────────────────

const api: AxiosInstance = axios.create({
  baseURL: `${API_URL}/api/v1`,
  headers: { "Content-Type": "application/json" },
  timeout: 30000,
});

// Request interceptor — attach token
api.interceptors.request.use((config) => {
  const token = getAccessToken();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Response interceptor — handle 401
api.interceptors.response.use(
  (res) => res,
  async (error: AxiosError) => {
    const original = error.config as typeof error.config & { _retry?: boolean };
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true;
      try {
        const refreshed = await refreshTokens();
        if (refreshed && original) {
          original.headers!.Authorization = `Bearer ${refreshed.access_token}`;
          return api(original);
        }
      } catch {
        clearTokens();
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

// ─── Token Helpers ────────────────────────────────────────

export const getAccessToken = () =>
  typeof window !== "undefined" ? localStorage.getItem("arx_access_token") : null;

export const getRefreshToken = () =>
  typeof window !== "undefined" ? localStorage.getItem("arx_refresh_token") : null;

export const setTokens = (tokens: AuthTokens) => {
  localStorage.setItem("arx_access_token", tokens.access_token);
  localStorage.setItem("arx_refresh_token", tokens.refresh_token);
  localStorage.setItem("arx_user_id", tokens.user_id);
  localStorage.setItem("arx_username", tokens.username);
};

export const clearTokens = () => {
  ["arx_access_token", "arx_refresh_token", "arx_user_id", "arx_username"].forEach(
    (k) => localStorage.removeItem(k)
  );
};

export const isAuthenticated = () => !!getAccessToken();

const refreshTokens = async (): Promise<AuthTokens | null> => {
  const refreshToken = getRefreshToken();
  if (!refreshToken) return null;
  const { data } = await api.post<AuthTokens>("/auth/refresh", { refresh_token: refreshToken });
  setTokens(data);
  return data;
};

// ─── Auth API ─────────────────────────────────────────────

export const authAPI = {
  register: async (username: string, password: string, displayName?: string) => {
    const { data } = await api.post<AuthTokens>("/auth/register", {
      username, password, display_name: displayName,
    });
    setTokens(data);
    return data;
  },

  login: async (username: string, password: string) => {
    const { data } = await api.post<AuthTokens>("/auth/login", { username, password });
    setTokens(data);
    return data;
  },

  logout: () => {
    clearTokens();
    window.location.href = "/login";
  },

  me: async () => {
    const { data } = await api.get<User>("/auth/me");
    return data;
  },
};

// ─── User Profile API ─────────────────────────────────────

export const userAPI = {
  getProfile: async () => {
    const { data } = await api.get("/user/profile");
    return data;
  },

  updateProfile: async (updates: Partial<UserProfile & { display_name: string }>) => {
    const { data } = await api.patch("/user/profile", updates);
    return data;
  },

  analyzeProfile: async () => {
    const { data } = await api.post("/user/profile/analyze");
    return data;
  },
};

// ─── Chat API ─────────────────────────────────────────────

export const chatAPI = {
  listConversations: async () => {
    const { data } = await api.get<Conversation[]>("/chat/conversations");
    return data;
  },

  createConversation: async (agentType = "master") => {
    const { data } = await api.post<{ id: string }>("/chat/conversations", { agent_type: agentType });
    return data;
  },

  getMessages: async (conversationId: string) => {
    const { data } = await api.get<Message[]>(`/chat/conversations/${conversationId}/messages`);
    return data;
  },

  deleteConversation: async (id: string) => {
    await api.delete(`/chat/conversations/${id}`);
  },

  // WebSocket URL for streaming
  getWsUrl: (conversationId: string) => {
    const wsBase = process.env.NEXT_PUBLIC_WS_URL || "ws://localhost:8000";
    return `${wsBase}/api/v1/chat/ws/${conversationId}`;
  },
};

// ─── Goals API ────────────────────────────────────────────

export const goalsAPI = {
  list: async (params?: { status?: string; category?: string }) => {
    const { data } = await api.get<Goal[]>("/goals", { params });
    return data;
  },

  create: async (goal: {
    title: string; description?: string; category?: GoalCategory;
    priority?: number; target_date?: string; parent_id?: string;
  }) => {
    const { data } = await api.post<{ id: string }>("/goals", goal);
    return data;
  },

  update: async (id: string, updates: Partial<Goal>) => {
    const { data } = await api.patch(`/goals/${id}`, updates);
    return data;
  },

  delete: async (id: string) => {
    await api.delete(`/goals/${id}`);
  },

  checkIn: async (id: string, progress: number, notes?: string) => {
    const { data } = await api.post(`/goals/${id}/checkin`, { progress, notes });
    return data;
  },

  getAISuggestions: async (id: string) => {
    const { data } = await api.get(`/goals/${id}/ai-suggestions`);
    return data;
  },
};

// ─── Projects API ─────────────────────────────────────────

export const projectsAPI = {
  list: async (status?: string) => {
    const { data } = await api.get<Project[]>("/projects", { params: { status } });
    return data;
  },

  create: async (project: { title: string; description?: string; goal_id?: string }) => {
    const { data } = await api.post<{ id: string }>("/projects", project);
    return data;
  },

  get: async (id: string) => {
    const { data } = await api.get(`/projects/${id}`);
    return data;
  },

  update: async (id: string, updates: Partial<Project>) => {
    const { data } = await api.patch(`/projects/${id}`, updates);
    return data;
  },

  delete: async (id: string) => {
    await api.delete(`/projects/${id}`);
  },

  getInbox: async () => {
    const { data } = await api.get<Task[]>("/projects/tasks/inbox");
    return data;
  },

  createTask: async (task: {
    title: string; project_id?: string; priority?: TaskPriority;
    due_date?: string; estimated_minutes?: number;
  }) => {
    const { data } = await api.post<{ id: string }>("/projects/tasks", task);
    return data;
  },

  updateTask: async (id: string, updates: Partial<Task>) => {
    const { data } = await api.patch(`/projects/tasks/${id}`, updates);
    return data;
  },

  deleteTask: async (id: string) => {
    await api.delete(`/projects/tasks/${id}`);
  },
};

// ─── Habits API ───────────────────────────────────────────

export const habitsAPI = {
  list: async () => {
    const { data } = await api.get<Habit[]>("/habits");
    return data;
  },

  create: async (habit: {
    title: string; frequency?: string; target_count?: number;
    color?: string; icon?: string; category?: string;
  }) => {
    const { data } = await api.post<{ id: string }>("/habits", habit);
    return data;
  },

  getToday: async () => {
    const { data } = await api.get<HabitTodayStatus[]>("/habits/today");
    return data;
  },

  log: async (habitId: string, date?: string, count?: number) => {
    const { data } = await api.post(`/habits/${habitId}/log`, {
      completed_date: date || new Date().toISOString().split("T")[0],
      count: count || 1,
    });
    return data;
  },

  getHeatmap: async (habitId: string, days = 90) => {
    const { data } = await api.get(`/habits/heatmap`, { params: { habit_id: habitId, days } });
    return data;
  },
};

// ─── Learning API ─────────────────────────────────────────

export const learningAPI = {
  list: async (params?: { status?: LearningStatus }) => {
    const { data } = await api.get<LearningItem[]>("/learning", { params });
    return data;
  },

  create: async (item: {
    title: string; resource_type?: string; author?: string;
    category?: string; resource_url?: string;
  }) => {
    const { data } = await api.post<{ id: string }>("/learning", item);
    return data;
  },

  get: async (id: string) => {
    const { data } = await api.get(`/learning/${id}`);
    return data;
  },

  update: async (id: string, updates: Partial<LearningItem>) => {
    const { data } = await api.patch(`/learning/${id}`, updates);
    return data;
  },

  logSession: async (session: {
    learning_item_id?: string; duration_minutes: number;
    topic?: string; focus_score?: number;
  }) => {
    const { data } = await api.post("/learning/sessions", session);
    return data;
  },

  getStats: async () => {
    const { data } = await api.get("/learning/stats/overview");
    return data;
  },

  generatePath: async (id: string) => {
    const { data } = await api.post(`/learning/${id}/generate-path`);
    return data;
  },
};

// ─── Memory API ───────────────────────────────────────────

export const memoryAPI = {
  search: async (query: string, types?: MemoryType[], limit = 10) => {
    const { data } = await api.post<{ results: MemorySearchResult[]; count: number }>(
      "/memory/search",
      { query, memory_types: types, limit }
    );
    return data;
  },

  list: async (memoryType?: MemoryType) => {
    const { data } = await api.get<Memory[]>("/memory", { params: { memory_type: memoryType } });
    return data;
  },

  create: async (content: string, type: MemoryType, title?: string, importance?: number) => {
    const { data } = await api.post("/memory", { content, memory_type: type, title, importance });
    return data;
  },

  delete: async (id: string) => {
    await api.delete(`/memory/${id}`);
  },

  getStats: async () => {
    const { data } = await api.get("/memory/stats");
    return data;
  },
};

// ─── Analytics API ────────────────────────────────────────

export const analyticsAPI = {
  getDashboard: async () => {
    const { data } = await api.get<DashboardMetrics>("/analytics/dashboard");
    return data;
  },

  getWeekly: async (weekOffset = 0) => {
    const { data } = await api.get("/analytics/weekly", { params: { week_offset: weekOffset } });
    return data;
  },

  getMonthly: async (monthOffset = 0) => {
    const { data } = await api.get("/analytics/monthly", { params: { month_offset: monthOffset } });
    return data;
  },

  getQuarterly: async (quarterOffset = 0) => {
    const { data } = await api.get("/analytics/quarterly", { params: { quarter_offset: quarterOffset } });
    return data;
  },

  generateAIReport: async (type: "weekly" | "monthly" = "weekly") => {
    const { data } = await api.post("/analytics/generate-ai-report", null, {
      params: { report_type: type }
    });
    return data;
  },

  listReports: async (type?: string) => {
    const { data } = await api.get<Report[]>("/analytics/reports", { params: { report_type: type } });
    return data;
  },
};

// ─── Agents API ───────────────────────────────────────────

export const agentsAPI = {
  skillGap: async (targetRole: string, currentSkills: string[] = []) => {
    const { data } = await api.post("/agents/career/skill-gap", { target_role: targetRole, current_skills: currentSkills });
    return data;
  },

  evaluateStartup: async (idea: string, context?: string) => {
    const { data } = await api.post("/agents/startup/evaluate", { idea, context });
    return data;
  },

  planWeek: async (goals: string[] = [], focusAreas: string[] = []) => {
    const { data } = await api.post("/agents/productivity/week-plan", { goals, focus_areas: focusAreas });
    return data;
  },

  researchTopic: async (topic: string, depth = "overview") => {
    const { data } = await api.post("/agents/research/topic", null, { params: { topic, depth } });
    return data;
  },

  weeklyReview: async () => {
    const { data } = await api.post("/agents/reflection/weekly-review");
    return data;
  },
};

// ─── Finance API ──────────────────────────────────────────

export const financeAPI = {
  list: async (type?: string) => {
    const { data } = await api.get<FinanceEntry[]>("/finance", { params: { entry_type: type } });
    return data;
  },

  create: async (entry: {
    entry_type: string; category: string; amount: number;
    description?: string; entry_date?: string;
  }) => {
    const { data } = await api.post("/finance", entry);
    return data;
  },

  getSummary: async (year?: number, month?: number) => {
    const { data } = await api.get<FinanceSummary>("/finance/summary", { params: { year, month } });
    return data;
  },
};

// ─── Reflection API ───────────────────────────────────────

export const reflectionAPI = {
  list: async (type?: string) => {
    const { data } = await api.get<Reflection[]>("/reflection", { params: { reflection_type: type } });
    return data;
  },

  create: async (reflection: {
    reflection_type?: string; content: string;
    mood?: number; energy?: number;
    wins?: string[]; challenges?: string[];
    lessons?: string[]; gratitude?: string[];
  }) => {
    const { data } = await api.post("/reflection", reflection);
    return data;
  },

  generateInsights: async (id: string) => {
    const { data } = await api.post(`/reflection/${id}/ai-insights`);
    return data;
  },

  getDecisions: async () => {
    const { data } = await api.get("/reflection/decisions/list");
    return data;
  },

  createDecision: async (decision: {
    title: string; context: string; decision_made: string;
    rationale?: string; confidence_level?: number;
  }) => {
    const { data } = await api.post("/reflection/decisions", decision);
    return data;
  },
};

// ─── Knowledge API ────────────────────────────────────────

export const knowledgeAPI = {
  getGraph: async () => {
    const { data } = await api.get<KnowledgeGraph>("/knowledge/graph");
    return data;
  },

  createNode: async (node: { title: string; content?: string; node_type?: string; tags?: string[] }) => {
    const { data } = await api.post("/knowledge/nodes", node);
    return data;
  },

  search: async (query: string) => {
    const { data } = await api.post("/knowledge/search", null, { params: { query } });
    return data;
  },
};

// ─── Voice API ────────────────────────────────────────────

export const voiceAPI = {
  transcribe: async (audioBlob: Blob) => {
    const formData = new FormData();
    formData.append("audio", audioBlob, "recording.webm");
    const { data } = await axios.post(`${API_URL}/api/v1/voice/transcribe`, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: `Bearer ${getAccessToken()}`,
      },
    });
    return data as { text: string; language: string };
  },
};

// ─── Settings API ─────────────────────────────────────────

export const settingsAPI = {
  get: async () => {
    const { data } = await api.get("/settings");
    return data;
  },

  health: async () => {
    const { data } = await api.get("/settings/health");
    return data;
  },

  changePassword: async (currentPassword: string, newPassword: string) => {
    const { data } = await api.post("/settings/change-password", {
      current_password: currentPassword,
      new_password: newPassword,
    });
    return data;
  },
};

export default api;
