"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { authAPI } from "@/lib/api";
import { useAuthStore } from "@/store";
import toast from "react-hot-toast";
import { Sparkles, Eye, EyeOff } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const setUser = useAuthStore(s => s.setUser);
  const [tab, setTab] = useState<"login" | "register">("login");
  const [form, setForm] = useState({ username: "", password: "", display_name: "" });
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  const handle = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      let tokens;
      if (tab === "login") {
        tokens = await authAPI.login(form.username, form.password);
      } else {
        tokens = await authAPI.register(form.username, form.password, form.display_name);
      }
      const user = await authAPI.me();
      setUser(user);
      toast.success(`Welcome back, ${tokens.display_name || tokens.username}!`);
      router.replace("/");
    } catch (err: any) {
      toast.error(err?.response?.data?.detail || "Authentication failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-arx-bg flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-arx-gradient mb-4 glow-accent">
            <Sparkles size={24} className="text-white" />
          </div>
          <h1 className="font-display text-3xl font-bold gradient-text">ARX OS</h1>
          <p className="text-arx-text-muted text-sm mt-1">Your Personal AI Operating System</p>
        </div>

        <div className="arx-card p-6">
          {/* Tabs */}
          <div className="flex rounded-xl bg-arx-muted p-1 mb-6 gap-1">
            {(["login", "register"] as const).map(t => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  tab === t
                    ? "bg-arx-accent text-white shadow-sm"
                    : "text-arx-text-muted hover:text-arx-text"
                }`}
              >
                {t === "login" ? "Sign In" : "Create Account"}
              </button>
            ))}
          </div>

          <form onSubmit={handle} className="space-y-4">
            {tab === "register" && (
              <div>
                <label className="arx-label">Display Name</label>
                <input
                  className="arx-input"
                  placeholder="Your name"
                  value={form.display_name}
                  onChange={e => setForm(f => ({ ...f, display_name: e.target.value }))}
                />
              </div>
            )}
            <div>
              <label className="arx-label">Username</label>
              <input
                className="arx-input"
                placeholder="username"
                value={form.username}
                onChange={e => setForm(f => ({ ...f, username: e.target.value }))}
                required
              />
            </div>
            <div>
              <label className="arx-label">Password</label>
              <div className="relative">
                <input
                  type={showPass ? "text" : "password"}
                  className="arx-input pr-10"
                  placeholder="••••••••"
                  value={form.password}
                  onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPass(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-arx-text-muted hover:text-arx-text"
                >
                  {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="arx-btn-primary w-full justify-center py-3 mt-2"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  {tab === "login" ? "Signing in…" : "Creating account…"}
                </span>
              ) : (
                tab === "login" ? "Sign In" : "Create Account"
              )}
            </button>
          </form>

          {tab === "login" && (
            <p className="text-center text-xs text-arx-text-muted mt-4">
              Default: <span className="font-mono text-arx-accent">admin</span> / <span className="font-mono text-arx-accent">arxos2024</span>
            </p>
          )}
        </div>

        <p className="text-center text-xs text-arx-text-muted mt-4">
          100% local · All data stays on your machine
        </p>
      </div>
    </div>
  );
}
