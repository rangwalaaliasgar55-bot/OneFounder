"use client";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { goalsAPI } from "@/lib/api";
import toast from "react-hot-toast";
import { Target, Plus, CheckCircle2, Circle, Pause, XCircle, ChevronRight, Sparkles } from "lucide-react";
import type { Goal, GoalCategory } from "@/types";
import { clsx } from "clsx";
import { format } from "date-fns";

const STATUS_ICONS: Record<string, any> = {
  active: Circle, completed: CheckCircle2, paused: Pause, abandoned: XCircle,
};
const STATUS_COLORS: Record<string, string> = {
  active: "text-arx-accent", completed: "text-arx-success",
  paused: "text-arx-warning", abandoned: "text-arx-danger",
};
const CATEGORIES: GoalCategory[] = ["career","startup","learning","health","finance","personal","relationship"];
const CAT_COLORS: Record<string, string> = {
  career:"#6c63ff", startup:"#ffa502", learning:"#2ed573",
  health:"#ff6b6b", finance:"#00d4aa", personal:"#74b9ff", relationship:"#fd79a8",
};

export default function GoalsPage() {
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [filter, setFilter] = useState<string>("active");
  const [form, setForm] = useState({
    title:"", description:"", category:"personal" as GoalCategory,
    priority:3, target_date:"",
  });

  const { data: goals = [], isLoading } = useQuery({
    queryKey: ["goals", filter],
    queryFn: () => goalsAPI.list({ status: filter === "all" ? undefined : filter }),
  });

  const createMutation = useMutation({
    mutationFn: () => goalsAPI.create({ ...form, target_date: form.target_date || undefined }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["goals"] });
      setShowCreate(false);
      setForm({ title:"", description:"", category:"personal", priority:3, target_date:"" });
      toast.success("Goal created!");
    },
  });

  const updateProgress = useMutation({
    mutationFn: ({ id, progress }: { id: string; progress: number }) =>
      goalsAPI.checkIn(id, progress),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["goals"] }); toast.success("Progress updated!"); },
  });

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold flex items-center gap-2">
            <Target className="text-arx-accent" size={22} /> Goals
          </h1>
          <p className="text-arx-text-muted text-sm mt-0.5">{goals.length} {filter} goals</p>
        </div>
        <button onClick={() => setShowCreate(v => !v)} className="arx-btn-primary gap-2">
          <Plus size={15} /> New Goal
        </button>
      </div>

      {/* Status filter */}
      <div className="flex gap-1.5">
        {["active","completed","paused","all"].map(s => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={clsx(
              "px-3 py-1.5 rounded-lg text-xs font-medium transition-all",
              filter === s ? "bg-arx-accent text-white" : "bg-arx-muted text-arx-text-muted hover:text-arx-text"
            )}
          >
            {s.charAt(0).toUpperCase() + s.slice(1)}
          </button>
        ))}
      </div>

      {/* Create form */}
      {showCreate && (
        <div className="arx-card p-5 space-y-4 animate-slide-down">
          <h3 className="font-semibold">New Goal</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <label className="arx-label">Goal</label>
              <input className="arx-input" placeholder="What do you want to achieve?"
                value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} />
            </div>
            <div className="col-span-2">
              <label className="arx-label">Description</label>
              <textarea className="arx-input resize-none" rows={2} placeholder="Why does this matter?"
                value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
            </div>
            <div>
              <label className="arx-label">Category</label>
              <select className="arx-input" value={form.category}
                onChange={e => setForm(f => ({ ...f, category: e.target.value as GoalCategory }))}>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="arx-label">Target Date</label>
              <input type="date" className="arx-input" value={form.target_date}
                onChange={e => setForm(f => ({ ...f, target_date: e.target.value }))} />
            </div>
            <div>
              <label className="arx-label">Priority (1-5)</label>
              <input type="range" min={1} max={5} className="w-full mt-2 accent-arx-accent"
                value={form.priority} onChange={e => setForm(f => ({ ...f, priority: +e.target.value }))} />
              <div className="flex justify-between text-xs text-arx-text-muted mt-1">
                <span>Low</span><span className="text-arx-accent font-bold">{form.priority}</span><span>High</span>
              </div>
            </div>
          </div>
          <div className="flex gap-2 justify-end">
            <button onClick={() => setShowCreate(false)} className="arx-btn-ghost">Cancel</button>
            <button onClick={() => createMutation.mutate()}
              disabled={!form.title || createMutation.isPending} className="arx-btn-primary">
              {createMutation.isPending ? "Creating…" : "Create Goal"}
            </button>
          </div>
        </div>
      )}

      {/* Goals list */}
      {isLoading ? (
        <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="arx-card h-24 animate-pulse" />)}</div>
      ) : goals.length === 0 ? (
        <div className="arx-card p-10 text-center">
          <Target size={32} className="text-arx-text-muted mx-auto mb-3" />
          <p className="text-arx-text-muted">No {filter} goals yet.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {(goals as Goal[]).map(g => {
            const Icon = STATUS_ICONS[g.status];
            const catColor = CAT_COLORS[g.category] || "#6c63ff";
            return (
              <div key={g.id} className="arx-card p-5 hover:border-arx-border/60 transition-colors">
                <div className="flex items-start gap-3">
                  <Icon size={18} className={clsx("mt-0.5 flex-shrink-0", STATUS_COLORS[g.status])} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-medium">{g.title}</h3>
                      <span className="text-xs px-2 py-0.5 rounded-full font-medium"
                        style={{ background: catColor + "18", color: catColor }}>
                        {g.category}
                      </span>
                      {Array.from({ length: g.priority }, (_, i) => (
                        <span key={i} className="text-arx-warning text-xs">★</span>
                      ))}
                    </div>
                    {g.description && <p className="text-arx-text-muted text-sm mt-1">{g.description}</p>}
                    <div className="mt-3">
                      <div className="flex justify-between text-xs text-arx-text-muted mb-1.5">
                        <span>Progress</span>
                        <span className="font-medium text-arx-text">{g.progress}%</span>
                      </div>
                      <div className="progress-bar">
                        <div className="progress-fill" style={{ width: `${g.progress}%` }} />
                      </div>
                    </div>
                    <div className="flex items-center gap-4 mt-3">
                      {g.target_date && (
                        <span className="text-xs text-arx-text-muted">
                          Due: {format(new Date(g.target_date), "MMM d, yyyy")}
                        </span>
                      )}
                      <button
                        onClick={() => {
                          const p = prompt("Update progress (0-100):", String(g.progress));
                          if (p !== null && !isNaN(+p)) updateProgress.mutate({ id: g.id, progress: +p });
                        }}
                        className="text-xs text-arx-accent hover:underline"
                      >
                        Update progress
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
