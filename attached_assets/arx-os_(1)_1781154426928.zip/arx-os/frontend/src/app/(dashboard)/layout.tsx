"use client";
import { useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import Link from "next/link";
import { useAuthStore, useUIStore } from "@/store";
import {
  LayoutDashboard, MessageSquare, Brain, Target, FolderKanban,
  Zap, BookOpen, TrendingUp, BarChart3, Settings, ChevronLeft,
  ChevronRight, LogOut, User, Lightbulb, DollarSign, Sparkles,
} from "lucide-react";
import { clsx } from "clsx";

const NAV = [
  { href: "/",           icon: LayoutDashboard, label: "Home"       },
  { href: "/chat",       icon: MessageSquare,   label: "Chat"        },
  { href: "/memory",     icon: Brain,           label: "Memory"      },
  { href: "/goals",      icon: Target,          label: "Goals"       },
  { href: "/projects",   icon: FolderKanban,    label: "Projects"    },
  { href: "/habits",     icon: Zap,             label: "Habits"      },
  { href: "/learning",   icon: BookOpen,        label: "Learning"    },
  { href: "/reflection", icon: Lightbulb,       label: "Reflect"     },
  { href: "/finance",    icon: DollarSign,      label: "Finance"     },
  { href: "/reports",    icon: BarChart3,       label: "Reports"     },
  { href: "/settings",   icon: Settings,        label: "Settings"    },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const { user, isAuthenticated, isLoading, logout } = useAuthStore();
  const { sidebarCollapsed, toggleSidebar } = useUIStore();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) router.replace("/login");
  }, [isLoading, isAuthenticated]);

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-arx-bg">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-arx-gradient animate-pulse" />
          <span className="text-arx-text-muted text-sm">Loading ARX OS…</span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) return null;

  return (
    <div className="flex h-screen bg-arx-bg overflow-hidden">
      {/* ── Sidebar ── */}
      <aside
        className={clsx(
          "flex flex-col bg-arx-surface border-r border-arx-border transition-all duration-300 flex-shrink-0",
          sidebarCollapsed ? "w-[64px]" : "w-[220px]"
        )}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-5 border-b border-arx-border min-h-[65px]">
          <div className="w-8 h-8 rounded-lg bg-arx-gradient flex items-center justify-center flex-shrink-0">
            <Sparkles size={14} className="text-white" />
          </div>
          {!sidebarCollapsed && (
            <span className="font-display font-bold text-lg gradient-text tracking-tight">ARX OS</span>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
          {NAV.map(({ href, icon: Icon, label }) => {
            const active = href === "/" ? pathname === "/" : pathname.startsWith(href);
            return (
              <Link
                key={href}
                href={href}
                className={clsx(active ? "nav-item-active" : "nav-item", "justify-start")}
                title={sidebarCollapsed ? label : undefined}
              >
                <Icon size={17} className="flex-shrink-0" />
                {!sidebarCollapsed && <span>{label}</span>}
              </Link>
            );
          })}
        </nav>

        {/* User + collapse */}
        <div className="border-t border-arx-border p-2 space-y-1">
          <Link href="/settings" className="nav-item" title={sidebarCollapsed ? "Profile" : undefined}>
            <div className="w-6 h-6 rounded-full bg-arx-accent/20 flex items-center justify-center flex-shrink-0">
              <User size={12} className="text-arx-accent" />
            </div>
            {!sidebarCollapsed && (
              <span className="truncate text-xs">{user?.display_name || user?.username}</span>
            )}
          </Link>
          <button onClick={logout} className="nav-item w-full" title={sidebarCollapsed ? "Logout" : undefined}>
            <LogOut size={15} className="flex-shrink-0 text-arx-danger/70" />
            {!sidebarCollapsed && <span className="text-arx-danger/70">Logout</span>}
          </button>
          <button
            onClick={toggleSidebar}
            className="nav-item w-full"
            title={sidebarCollapsed ? "Expand" : "Collapse"}
          >
            {sidebarCollapsed
              ? <ChevronRight size={15} />
              : <><ChevronLeft size={15} /><span>Collapse</span></>
            }
          </button>
        </div>
      </aside>

      {/* ── Main ── */}
      <main className="flex-1 overflow-y-auto">
        {children}
      </main>
    </div>
  );
}
