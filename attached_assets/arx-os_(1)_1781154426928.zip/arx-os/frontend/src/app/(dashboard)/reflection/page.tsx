"use client";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { reflectionAPI, agentsAPI } from "@/lib/api";
import { Lightbulb, Plus, Sparkles, Loader2 } from "lucide-react";
import toast from "react-hot-toast";
import { format } from "date-fns";

export default function ReflectionPage() {
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [weeklyReview, setWeeklyReview] = useState<any>(null);
  const [form, setForm] = useState({ content:"", mood:3, energy:3, wins:[""], challenges:[""], lessons:[""] });

  const { data: reflections=[] } = useQuery({ queryKey:["reflections"], queryFn:()=>reflectionAPI.list() });
  const createMutation = useMutation({
    mutationFn: ()=>reflectionAPI.create({...form,wins:form.wins.filter(Boolean),challenges:form.challenges.filter(Boolean),lessons:form.lessons.filter(Boolean)}),
    onSuccess: ()=>{ qc.invalidateQueries({queryKey:["reflections"]}); setShowCreate(false); toast.success("Reflection saved!"); },
  });
  const weeklyMutation = useMutation({ mutationFn: agentsAPI.weeklyReview, onSuccess: setWeeklyReview });

  const ListInput = ({arr,onChange,placeholder}:{arr:string[];onChange:(a:string[])=>void;placeholder:string}) => (
    <div className="space-y-1.5">
      {arr.map((v,i)=>(<input key={i} className="arx-input text-sm" value={v} placeholder={placeholder} onChange={e=>{const n=[...arr];n[i]=e.target.value;onChange(n);}}/>))}
      <button onClick={()=>onChange([...arr,""])} className="text-xs text-arx-accent hover:underline">+ Add</button>
    </div>
  );

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold flex items-center gap-2"><Lightbulb className="text-arx-warning" size={22}/> Reflect</h1>
        <div className="flex gap-2">
          <button onClick={()=>weeklyMutation.mutate()} disabled={weeklyMutation.isPending} className="arx-btn-ghost gap-2">
            {weeklyMutation.isPending?<Loader2 size={13} className="animate-spin"/>:<Sparkles size={13}/>} AI Weekly Review
          </button>
          <button onClick={()=>setShowCreate(v=>!v)} className="arx-btn-primary gap-2"><Plus size={14}/> New Entry</button>
        </div>
      </div>

      {weeklyReview && (
        <div className="arx-card p-5 border-arx-accent/20 space-y-2">
          <h3 className="font-semibold flex items-center gap-2 text-sm"><Sparkles size={13} className="text-arx-accent"/> AI Weekly Review</h3>
          {weeklyReview.wins?.length>0&&<p className="text-sm"><span className="text-arx-success font-medium">Wins: </span>{weeklyReview.wins.join(" · ")}</p>}
          {weeklyReview.patterns_noticed?.length>0&&<p className="text-sm"><span className="text-arx-warning font-medium">Patterns: </span>{weeklyReview.patterns_noticed.join(" · ")}</p>}
          {weeklyReview.next_week_focus?.length>0&&<p className="text-sm"><span className="text-arx-accent font-medium">Next week: </span>{weeklyReview.next_week_focus.join(" · ")}</p>}
          {weeklyReview.key_reflection_questions?.length>0&&(
            <div className="mt-2 pt-2 border-t border-arx-border">
              <p className="text-xs text-arx-text-muted mb-1">Reflection questions:</p>
              {weeklyReview.key_reflection_questions.map((q:string,i:number)=><p key={i} className="text-xs text-arx-text-muted">• {q}</p>)}
            </div>
          )}
        </div>
      )}

      {showCreate && (
        <div className="arx-card p-5 space-y-4 animate-slide-down">
          <h3 className="font-semibold">New Reflection</h3>
          <textarea className="arx-input resize-none" rows={4} placeholder="What's on your mind? How did this period go?"
            value={form.content} onChange={e=>setForm(f=>({...f,content:e.target.value}))}/>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="arx-label">Mood (1-5): {form.mood}</label><input type="range" min={1} max={5} className="w-full accent-arx-accent mt-2" value={form.mood} onChange={e=>setForm(f=>({...f,mood:+e.target.value}))}/></div>
            <div><label className="arx-label">Energy (1-5): {form.energy}</label><input type="range" min={1} max={5} className="w-full accent-arx-highlight mt-2" value={form.energy} onChange={e=>setForm(f=>({...f,energy:+e.target.value}))}/></div>
          </div>
          <div><label className="arx-label">Wins 🏆</label><ListInput arr={form.wins} onChange={wins=>setForm(f=>({...f,wins}))} placeholder="What went well?"/></div>
          <div><label className="arx-label">Challenges 💪</label><ListInput arr={form.challenges} onChange={challenges=>setForm(f=>({...f,challenges}))} placeholder="What was hard?"/></div>
          <div><label className="arx-label">Lessons 🧠</label><ListInput arr={form.lessons} onChange={lessons=>setForm(f=>({...f,lessons}))} placeholder="What did you learn?"/></div>
          <div className="flex gap-2 justify-end">
            <button onClick={()=>setShowCreate(false)} className="arx-btn-ghost">Cancel</button>
            <button onClick={()=>createMutation.mutate()} disabled={!form.content||createMutation.isPending} className="arx-btn-primary">{createMutation.isPending?"Saving…":"Save"}</button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {(reflections as any[]).map(r=>(
          <div key={r.id} className="arx-card p-5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-arx-text-muted">{format(new Date(r.reflection_date),"EEEE, MMMM d, yyyy")}</span>
              <div className="flex gap-3 text-xs text-arx-text-muted">{r.mood&&<span>😊 {r.mood}/5</span>}{r.energy&&<span>⚡ {r.energy}/5</span>}</div>
            </div>
            <p className="text-sm leading-relaxed">{r.content}</p>
            {r.wins?.filter(Boolean).length>0&&(
              <div className="mt-3 flex flex-wrap gap-1.5">
                {r.wins.filter(Boolean).map((w:string,i:number)=><span key={i} className="text-xs bg-arx-success/10 text-arx-success px-2 py-0.5 rounded-full">✓ {w}</span>)}
              </div>
            )}
          </div>
        ))}
        {reflections.length===0&&<div className="arx-card p-10 text-center"><Lightbulb size={32} className="text-arx-text-muted mx-auto mb-3"/><p className="text-arx-text-muted">No reflections yet. Take a moment to reflect.</p></div>}
      </div>
    </div>
  );
}
