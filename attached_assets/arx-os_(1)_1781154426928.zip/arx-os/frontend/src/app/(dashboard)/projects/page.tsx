"use client";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { projectsAPI } from "@/lib/api";
import { FolderKanban, Plus, CheckSquare, Circle } from "lucide-react";
import toast from "react-hot-toast";
import type { Project, Task } from "@/types";

const SC: Record<string,string> = { planning:"#6b6b8a",active:"#6c63ff",on_hold:"#ffa502",completed:"#2ed573",cancelled:"#ff4757" };

export default function ProjectsPage() {
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [activeProject, setActiveProject] = useState<string|null>(null);
  const [form, setForm] = useState({ title:"", description:"", category:"" });
  const [taskTitle, setTaskTitle] = useState("");

  const { data:projects=[] } = useQuery({ queryKey:["projects"], queryFn:()=>projectsAPI.list() });
  const { data:projectDetail } = useQuery({ queryKey:["project",activeProject], queryFn:()=>projectsAPI.get(activeProject!), enabled:!!activeProject });

  const createMutation = useMutation({ mutationFn:()=>projectsAPI.create(form), onSuccess:()=>{ qc.invalidateQueries({queryKey:["projects"]}); setShowCreate(false); setForm({title:"",description:"",category:""}); toast.success("Project created!"); } });
  const taskMutation = useMutation({ mutationFn:()=>projectsAPI.createTask({title:taskTitle,project_id:activeProject||undefined}), onSuccess:()=>{ qc.invalidateQueries({queryKey:["project",activeProject]}); setTaskTitle(""); toast.success("Task added!"); } });
  const updateTask = useMutation({ mutationFn:({id,status}:{id:string,status:string})=>projectsAPI.updateTask(id,{status:status as any}), onSuccess:()=>qc.invalidateQueries({queryKey:["project",activeProject,"projects"]}) });

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold flex items-center gap-2"><FolderKanban className="text-arx-warning" size={22}/> Projects</h1>
        <button onClick={()=>setShowCreate(v=>!v)} className="arx-btn-primary gap-2"><Plus size={14}/> New Project</button>
      </div>
      {showCreate && (
        <div className="arx-card p-5 space-y-3 animate-slide-down">
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2"><label className="arx-label">Project Name</label><input className="arx-input" value={form.title} onChange={e=>setForm(f=>({...f,title:e.target.value}))}/></div>
            <div className="col-span-2"><label className="arx-label">Description</label><textarea className="arx-input resize-none" rows={2} value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))}/></div>
            <div><label className="arx-label">Category</label><input className="arx-input" placeholder="work, side-project…" value={form.category} onChange={e=>setForm(f=>({...f,category:e.target.value}))}/></div>
          </div>
          <div className="flex gap-2 justify-end">
            <button onClick={()=>setShowCreate(false)} className="arx-btn-ghost">Cancel</button>
            <button onClick={()=>createMutation.mutate()} disabled={!form.title} className="arx-btn-primary">Create</button>
          </div>
        </div>
      )}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {(projects as Project[]).map(p=>(
          <div key={p.id} onClick={()=>setActiveProject(p.id===activeProject?null:p.id)} className={`arx-card p-5 cursor-pointer transition-all hover:border-arx-accent/30 ${activeProject===p.id?"border-arx-accent/50":""}`}>
            <div className="flex items-start justify-between mb-3">
              <div><h3 className="font-semibold">{p.title}</h3>{p.description&&<p className="text-xs text-arx-text-muted mt-0.5 line-clamp-1">{p.description}</p>}</div>
              <span className="text-xs px-2 py-0.5 rounded-full ml-2 flex-shrink-0" style={{background:SC[p.status]+"18",color:SC[p.status]}}>{p.status.replace("_"," ")}</span>
            </div>
            <div className="progress-bar mb-2"><div className="progress-fill" style={{width:`${p.progress}%`}}/></div>
            <div className="flex justify-between text-xs text-arx-text-muted"><span className="flex items-center gap-1"><CheckSquare size={11}/> {p.tasks_done}/{p.task_count} tasks</span><span>{p.progress.toFixed(0)}%</span></div>
            {activeProject===p.id && projectDetail && (
              <div className="mt-4 pt-4 border-t border-arx-border space-y-2" onClick={e=>e.stopPropagation()}>
                <div className="flex gap-2">
                  <input className="arx-input flex-1 text-sm py-1.5" placeholder="Add task…" value={taskTitle} onChange={e=>setTaskTitle(e.target.value)} onKeyDown={e=>e.key==="Enter"&&taskTitle&&taskMutation.mutate()}/>
                  <button onClick={()=>taskTitle&&taskMutation.mutate()} className="arx-btn-primary px-3 py-1.5 text-xs"><Plus size={13}/></button>
                </div>
                {projectDetail.tasks?.map((t:Task)=>(
                  <div key={t.id} className="flex items-center gap-2 py-1">
                    <button onClick={()=>updateTask.mutate({id:t.id,status:t.status==="done"?"todo":"done"})} className="flex-shrink-0">
                      {t.status==="done"?<CheckSquare size={15} className="text-arx-success"/>:<Circle size={15} className="text-arx-text-muted"/>}
                    </button>
                    <span className={`text-sm flex-1 ${t.status==="done"?"line-through text-arx-text-muted":""}`}>{t.title}</span>
                    <span className={`text-xs px-1.5 py-0.5 rounded ${t.priority==="urgent"?"bg-arx-danger/10 text-arx-danger":t.priority==="high"?"bg-arx-warning/10 text-arx-warning":"text-arx-text-muted"}`}>{t.priority}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
        {projects.length===0&&<div className="arx-card p-10 text-center col-span-2"><FolderKanban size={32} className="text-arx-text-muted mx-auto mb-3"/><p className="text-arx-text-muted">No projects yet.</p></div>}
      </div>
    </div>
  );
}
