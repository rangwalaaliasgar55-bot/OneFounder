"use client";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { habitsAPI } from "@/lib/api";
import toast from "react-hot-toast";
import { Plus, Flame, Check, X, Zap } from "lucide-react";
import { format, subDays, eachDayOfInterval } from "date-fns";
import { clsx } from "clsx";

const COLORS = ["#6c63ff","#00d4aa","#ffa502","#ff4757","#2ed573","#74b9ff","#fd79a8","#a29bfe"];

function HabitCard({ habit, onLog }: { habit: any; onLog: (id: string) => void }) {
  return (
    <div className="arx-card p-4 flex items-center gap-4">
      <button
        onClick={() => !habit.completed_today && onLog(habit.id)}
        className={clsx(
          "w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-200",
          habit.completed_today
            ? "scale-95"
            : "hover:scale-105 border-2 border-dashed border-arx-border hover:border-arx-accent"
        )}
        style={habit.completed_today
          ? { background: habit.color || "#6c63ff", boxShadow: `0 0 12px ${habit.color || "#6c63ff"}44` }
          : {}
        }
      >
        {habit.completed_today
          ? <Check size={18} className="text-white" />
          : <div className="w-3 h-3 rounded-full" style={{ background: habit.color || "#6c63ff" }} />
        }
      </button>

      <div className="flex-1 min-w-0">
        <div className={clsx("font-medium text-sm", habit.completed_today && "line-through text-arx-text-muted")}>
          {habit.title}
        </div>
        <div className="flex items-center gap-3 mt-0.5">
          {habit.streak_current > 0 && (
            <span className="text-xs text-arx-warning flex items-center gap-1">
              <Flame size={11} /> {habit.streak_current}d streak
            </span>
          )}
          <span className="text-xs text-arx-text-muted">{habit.frequency}</span>
        </div>
      </div>

      <div className="text-right">
        <div className="text-xs text-arx-text-muted">{habit.total_completions} total</div>
        {habit.streak_best > 0 && (
          <div className="text-xs text-arx-text-muted">best: {habit.streak_best}</div>
        )}
      </div>
    </div>
  );
}

function MiniHeatmap({ habitId }: { habitId: string }) {
  const { data = [] } = useQuery({
    queryKey: ["habit-heatmap", habitId],
    queryFn: () => habitsAPI.getHeatmap(habitId, 28),
  });
  const dateMap = new Map((data as any[]).map((d: any) => [d.date, d.count]));
  const days = eachDayOfInterval({ start: subDays(new Date(), 27), end: new Date() });

  return (
    <div className="flex gap-0.5 flex-wrap">
      {days.map(day => {
        const key = format(day, "yyyy-MM-dd");
        const done = dateMap.has(key);
        return (
          <div
            key={key}
            title={key}
            className="w-3 h-3 rounded-sm"
            style={{ background: done ? "#6c63ff" : "#1e1e2e" }}
          />
        );
      })}
    </div>
  );
}

export default function HabitsPage() {
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({
    title: "", frequency: "daily", target_count: 1,
    color: COLORS[0], category: "", unit: "",
  });

  const { data: habits = [], isLoading } = useQuery({
    queryKey: ["habits", "today"],
    queryFn: habitsAPI.getToday,
  });

  const logMutation = useMutation({
    mutationFn: (habitId: string) => habitsAPI.log(habitId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["habits"] });
      toast.success("Habit logged! 🎯");
    },
    onError: () => toast.error("Already logged today"),
  });

  const createMutation = useMutation({
    mutationFn: () => habitsAPI.create(form),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["habits"] });
      setShowCreate(false);
      setForm({ title: "", frequency: "daily", target_count: 1, color: COLORS[0], category: "", unit: "" });
      toast.success("Habit created!");
    },
  });

  const completed = habits.filter((h: any) => h.completed_today).length;

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold flex items-center gap-2">
            <Zap className="text-arx-highlight" size={22} /> Habits
          </h1>
          <p className="text-arx-text-muted text-sm mt-0.5">
            {completed}/{habits.length} done today · {format(new Date(), "EEEE, MMM d")}
          </p>
        </div>
        <button onClick={() => setShowCreate(v => !v)} className="arx-btn-primary gap-2">
          <Plus size={15} /> New Habit
        </button>
      </div>

      {/* Progress bar */}
      {habits.length > 0 && (
        <div>
          <div className="flex justify-between text-xs text-arx-text-muted mb-1.5">
            <span>Daily Progress</span>
            <span>{Math.round(completed / Math.max(habits.length, 1) * 100)}%</span>
          </div>
          <div className="progress-bar h-2">
            <div className="progress-fill" style={{ width: `${completed / Math.max(habits.length, 1) * 100}%` }} />
          </div>
        </div>
      )}

      {/* Create form */}
      {showCreate && (
        <div className="arx-card p-5 space-y-4 animate-slide-down">
          <h3 className="font-semibold">New Habit</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <label className="arx-label">Habit Name</label>
              <input
                className="arx-input"
                placeholder="Morning run, Read 30min…"
                value={form.title}
                onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
              />
            </div>
            <div>
              <label className="arx-label">Frequency</label>
              <select
                className="arx-input"
                value={form.frequency}
                onChange={e => setForm(f => ({ ...f, frequency: e.target.value }))}
              >
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
              </select>
            </div>
            <div>
              <label className="arx-label">Category</label>
              <input
                className="arx-input"
                placeholder="health, learning…"
                value={form.category}
                onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
              />
            </div>
            <div>
              <label className="arx-label">Color</label>
              <div className="flex gap-2 flex-wrap mt-1">
                {COLORS.map(c => (
                  <button
                    key={c}
                    onClick={() => setForm(f => ({ ...f, color: c }))}
                    className="w-7 h-7 rounded-lg transition-transform hover:scale-110"
                    style={{
                      background: c,
                      outline: form.color === c ? `2px solid ${c}` : "none",
                      outlineOffset: "2px",
                    }}
                  />
                ))}
              </div>
            </div>
          </div>
          <div className="flex gap-2 justify-end">
            <button onClick={() => setShowCreate(false)} className="arx-btn-ghost">Cancel</button>
            <button
              onClick={() => createMutation.mutate()}
              disabled={!form.title || createMutation.isPending}
              className="arx-btn-primary"
            >
              {createMutation.isPending ? "Creating…" : "Create Habit"}
            </button>
          </div>
        </div>
      )}

      {/* Habits list */}
      {isLoading ? (
        <div className="space-y-3">
          {[1,2,3].map(i => <div key={i} className="arx-card h-16 animate-pulse" />)}
        </div>
      ) : habits.length === 0 ? (
        <div className="arx-card p-10 text-center">
          <Zap size={32} className="text-arx-text-muted mx-auto mb-3" />
          <p className="text-arx-text-muted">No habits yet. Build your first one.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {habits.map((h: any) => (
            <div key={h.id} className="space-y-2">
              <HabitCard habit={h} onLog={id => logMutation.mutate(id)} />
              <div className="px-4">
                <MiniHeatmap habitId={h.id} />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
