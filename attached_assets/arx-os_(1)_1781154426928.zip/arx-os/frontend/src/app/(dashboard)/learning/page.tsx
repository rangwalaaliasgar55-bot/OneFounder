"use client";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { learningAPI } from "@/lib/api";
import { BookOpen, Plus, Clock, CheckCircle2, Play } from "lucide-react";
import type { LearningItem } from "@/types";
import toast from "react-hot-toast";

const TYPE_ICONS: Record<string,string> = { book:"📚", course:"🎓", video:"🎬", article:"📄", podcast:"🎙️" };

export default function LearningPage() {
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [showSession, setShowSession] = useState(false);
  const [form, setForm] = useState({ title:"", resource_type:"book", author:"", category:"", resource_url:"" });
  const [session, setSession] = useState({ duration_minutes:30, topic:"", focus_score:8 });

  const { data: items = [] } = useQuery({ queryKey:["learning"], queryFn: () => learningAPI.list() });
  const { data: stats } = useQuery({ queryKey:["learning-stats"], queryFn: learningAPI.getStats });

  const createMutation = useMutation({
    mutationFn: () => learningAPI.create(form),
    onSuccess: () => { qc.invalidateQueries({queryKey:["learning"]}); setShowCreate(false); setForm({title:"",resource_type:"book",author:"",category:"",resource_url:""}); toast.success("Added!"); },
  });
  const sessionMutation = useMutation({
    mutationFn: () => learningAPI.logSession(session),
    onSuccess: () => { qc.invalidateQueries({queryKey:["learning","learning-stats"]}); setShowSession(false); toast.success("Session logged! 📖"); },
  });
  const updateMutation = useMutation({
    mutationFn: ({id,status}:{id:string,status:string}) => learningAPI.update(id,{status:status as any}),
    onSuccess: () => qc.invalidateQueries({queryKey:["learning"]}),
  });

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold flex items-center gap-2">
            <BookOpen className="text-arx-success" size={22}/> Learning
          </h1>
          <p className="text-arx-text-muted text-sm">{stats?.total_hours_spent ?? 0}h total · {stats?.completed_items ?? 0} completed</p>
        </div>
        <div className="flex gap-2">
          <button onClick={()=>setShowSession(v=>!v)} className="arx-btn-ghost gap-2"><Clock size={14}/> Log Session</button>
          <button onClick={()=>setShowCreate(v=>!v)} className="arx-btn-primary gap-2"><Plus size={14}/> Add Resource</button>
        </div>
      </div>

      {showSession && (
        <div className="arx-card p-5 space-y-3 animate-slide-down">
          <h3 className="font-semibold">Log Learning Session</h3>
          <div className="grid grid-cols-3 gap-3">
            <div><label className="arx-label">Duration (min)</label><input type="number" className="arx-input" value={session.duration_minutes} onChange={e=>setSession(s=>({...s,duration_minutes:+e.target.value}))}/></div>
            <div><label className="arx-label">Topic</label><input className="arx-input" placeholder="What did you study?" value={session.topic} onChange={e=>setSession(s=>({...s,topic:e.target.value}))}/></div>
            <div><label className="arx-label">Focus (1-10)</label><input type="number" min={1} max={10} className="arx-input" value={session.focus_score} onChange={e=>setSession(s=>({...s,focus_score:+e.target.value}))}/></div>
          </div>
          <div className="flex gap-2 justify-end">
            <button onClick={()=>setShowSession(false)} className="arx-btn-ghost">Cancel</button>
            <button onClick={()=>sessionMutation.mutate()} className="arx-btn-primary">Log</button>
          </div>
        </div>
      )}

      {showCreate && (
        <div className="arx-card p-5 space-y-3 animate-slide-down">
          <h3 className="font-semibold">Add Resource</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2"><label className="arx-label">Title</label><input className="arx-input" value={form.title} onChange={e=>setForm(f=>({...f,title:e.target.value}))}/></div>
            <div><label className="arx-label">Type</label>
              <select className="arx-input" value={form.resource_type} onChange={e=>setForm(f=>({...f,resource_type:e.target.value}))}>
                {["book","course","video","article","podcast"].map(t=><option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div><label className="arx-label">Author</label><input className="arx-input" value={form.author} onChange={e=>setForm(f=>({...f,author:e.target.value}))}/></div>
            <div className="col-span-2"><label className="arx-label">URL (optional)</label><input className="arx-input" value={form.resource_url} onChange={e=>setForm(f=>({...f,resource_url:e.target.value}))}/></div>
          </div>
          <div className="flex gap-2 justify-end">
            <button onClick={()=>setShowCreate(false)} className="arx-btn-ghost">Cancel</button>
            <button onClick={()=>createMutation.mutate()} disabled={!form.title} className="arx-btn-primary">Add</button>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {(items as LearningItem[]).map(item=>(
          <div key={item.id} className="arx-card p-4 flex items-center gap-4 hover:border-arx-border/60 transition-colors">
            <div className="text-2xl">{TYPE_ICONS[item.resource_type]||"📖"}</div>
            <div className="flex-1 min-w-0">
              <div className="font-medium text-sm">{item.title}</div>
              <div className="text-xs text-arx-text-muted mt-0.5">{item.author&&`${item.author} · `}{item.resource_type} · {item.hours_spent}h spent</div>
              {item.status==="in_progress" && (
                <div className="mt-2"><div className="progress-bar"><div className="progress-fill" style={{width:`${item.progress}%`}}/></div></div>
              )}
            </div>
            <div className="flex items-center gap-2">
              {item.status==="planned" && <button onClick={()=>updateMutation.mutate({id:item.id,status:"in_progress"})} className="arx-btn-ghost text-xs gap-1"><Play size={11}/> Start</button>}
              {item.status==="in_progress" && <button onClick={()=>updateMutation.mutate({id:item.id,status:"completed"})} className="arx-btn-ghost text-xs gap-1 text-arx-success"><CheckCircle2 size={11}/> Done</button>}
              <span className={`text-xs px-2 py-0.5 rounded-full ${item.status==="completed"?"bg-arx-success/10 text-arx-success":item.status==="in_progress"?"bg-arx-accent/10 text-arx-accent":"bg-arx-muted text-arx-text-muted"}`}>
                {item.status.replace("_"," ")}
              </span>
            </div>
          </div>
        ))}
        {items.length===0 && (
          <div className="arx-card p-10 text-center">
            <BookOpen size={32} className="text-arx-text-muted mx-auto mb-3"/>
            <p className="text-arx-text-muted">No resources yet. Add books, courses, articles…</p>
          </div>
        )}
      </div>
    </div>
  );
}
