"use client";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { financeAPI } from "@/lib/api";
import { DollarSign, Plus, TrendingUp, TrendingDown, PiggyBank } from "lucide-react";
import toast from "react-hot-toast";

const TC: Record<string,string> = { income:"#2ed573", expense:"#ff4757", investment:"#6c63ff", saving:"#00d4aa" };

export default function FinancePage() {
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ entry_type:"expense", category:"", amount:"", description:"" });
  const { data: summary } = useQuery({ queryKey:["finance-summary"], queryFn:()=>financeAPI.getSummary() });
  const { data: entries=[] } = useQuery({ queryKey:["finance"], queryFn:()=>financeAPI.list() });
  const createMutation = useMutation({
    mutationFn:()=>financeAPI.create({...form,amount:parseFloat(form.amount)}),
    onSuccess:()=>{ qc.invalidateQueries({queryKey:["finance","finance-summary"]}); setShowCreate(false); setForm({entry_type:"expense",category:"",amount:"",description:""}); toast.success("Entry added!"); },
  });
  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold flex items-center gap-2"><DollarSign className="text-arx-success" size={22}/> Finance</h1>
        <button onClick={()=>setShowCreate(v=>!v)} className="arx-btn-primary gap-2"><Plus size={14}/> Add Entry</button>
      </div>
      {summary && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[{l:"Income",v:summary.income,c:"arx-success"},{l:"Expenses",v:summary.expenses,c:"arx-danger"},{l:"Net",v:summary.net,c:summary.net>=0?"arx-highlight":"arx-danger"},{l:"Savings",v:summary.savings,c:"arx-accent"}].map(s=>(
            <div key={s.l} className="arx-card p-4">
              <div className={`text-2xl font-bold text-${s.c}`}>${Math.abs(s.v||0).toLocaleString()}</div>
              <div className="text-xs text-arx-text-muted mt-0.5">{s.l}</div>
            </div>
          ))}
        </div>
      )}
      {showCreate && (
        <div className="arx-card p-5 space-y-3 animate-slide-down">
          <h3 className="font-semibold">New Entry</h3>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="arx-label">Type</label>
              <select className="arx-input" value={form.entry_type} onChange={e=>setForm(f=>({...f,entry_type:e.target.value}))}>
                {["income","expense","investment","saving"].map(t=><option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div><label className="arx-label">Amount ($)</label><input type="number" step="0.01" className="arx-input" placeholder="0.00" value={form.amount} onChange={e=>setForm(f=>({...f,amount:e.target.value}))}/></div>
            <div><label className="arx-label">Category</label><input className="arx-input" placeholder="salary, food, rent…" value={form.category} onChange={e=>setForm(f=>({...f,category:e.target.value}))}/></div>
            <div><label className="arx-label">Description</label><input className="arx-input" value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))}/></div>
          </div>
          <div className="flex gap-2 justify-end">
            <button onClick={()=>setShowCreate(false)} className="arx-btn-ghost">Cancel</button>
            <button onClick={()=>createMutation.mutate()} disabled={!form.amount||!form.category||createMutation.isPending} className="arx-btn-primary">Add</button>
          </div>
        </div>
      )}
      <div className="space-y-2">
        {(entries as any[]).map(e=>(
          <div key={e.id} className="arx-card p-4 flex items-center gap-3">
            <div className="w-2 h-2 rounded-full flex-shrink-0" style={{background:TC[e.entry_type]||"#6c63ff"}}/>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium">{e.category}</div>
              {e.description&&<div className="text-xs text-arx-text-muted">{e.description}</div>}
            </div>
            <div className={`font-bold ${e.entry_type==="expense"?"text-arx-danger":"text-arx-success"}`}>
              {e.entry_type==="expense"?"-":"+"}${Number(e.amount).toLocaleString()}
            </div>
            <div className="text-xs text-arx-text-muted w-20 text-right">{e.entry_date}</div>
          </div>
        ))}
        {entries.length===0&&<div className="arx-card p-10 text-center"><PiggyBank size={32} className="text-arx-text-muted mx-auto mb-3"/><p className="text-arx-text-muted">No entries yet. Start tracking your finances.</p></div>}
      </div>
    </div>
  );
}
