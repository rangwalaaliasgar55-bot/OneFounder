"use client";
import { useQuery } from "@tanstack/react-query";
import { analyticsAPI, goalsAPI, habitsAPI, learningAPI } from "@/lib/api";
import { useAuthStore } from "@/store";
import { format } from "date-fns";
import {
  Target, Zap, BookOpen, CheckSquare, TrendingUp,
  Brain, MessageSquare, Flame, ArrowRight, Sparkles,
} from "lucide-react";
import Link from "next/link";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

function StatCard({ label, value, sub, icon: Icon, color = "arx-accent" }: any) {
  return (
    <div className="arx-card p-5">
      <div className="flex items-start justify-between mb-3">
        <div className={`p-2 rounded-lg bg-${color}/10`}>
          <Icon size={16} className={`text-${color}`} />
        </div>
      </div>
      <div className="text-2xl font-bold font-display">{value ?? "—"}</div>
      <div className="text-xs text-arx-text-muted mt-0.5">{label}</div>
      {sub && <div className="text-xs text-arx-highlight mt-1">{sub}</div>}
    </div>
  );
}

export default function HomePage() {
  const { user } = useAuthStore();

  const { data: dash } = useQuery({
    queryKey: ["dashboard"],
    queryFn: analyticsAPI.getDashboard,
  });
  const { data: goals = [] } = useQuery({
    queryKey: ["goals", "active"],
    queryFn: () => goalsAPI.list({ status: "active" }),
  });
  const { data: todayHabits = [] } = useQuery({
    queryKey: ["habits", "today"],
    queryFn: habitsAPI.getToday,
  });
  const { data: learningStats } = useQuery({
    queryKey: ["learning", "stats"],
    queryFn: learningAPI.getStats,
  });

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return "Good morning";
    if (h < 18) return "Good afternoon";
    return "Good evening";
  };

  const habitsCompleted = todayHabits.filter((h: any) => h.completed_today).length;
  const habitsTotal = todayHabits.length;

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold">
            {greeting()}, <span className="gradient-text">{user?.display_name || user?.username}</span>
          </h1>
          <p className="text-arx-text-muted text-sm mt-0.5">{format(new Date(), "EEEE, MMMM d, yyyy")}</p>
        </div>
        <Link href="/chat" className="arx-btn-primary gap-2">
          <Sparkles size={15} />
          Chat with ARX
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Active Goals"
          value={dash?.today?.goals?.active ?? goals.length}
          sub={`${dash?.today?.goals?.avg_progress?.toFixed(0) ?? 0}% avg progress`}
          icon={Target}
          color="arx-accent"
        />
        <StatCard
          label="Habits Today"
          value={`${habitsCompleted}/${habitsTotal}`}
          sub={habitsTotal > 0 ? `${Math.round(habitsCompleted / Math.max(habitsTotal, 1) * 100)}% done` : "No habits yet"}
          icon={Zap}
          color="arx-highlight"
        />
        <StatCard
          label="Learning Hours"
          value={`${learningStats?.total_hours_spent ?? 0}h`}
          sub={`${learningStats?.completed_items ?? 0} items completed`}
          icon={BookOpen}
          color="arx-warning"
        />
        <StatCard
          label="Tasks Done"
          value={dash?.this_week?.tasks?.completed ?? 0}
          sub="this week"
          icon={CheckSquare}
          color="arx-success"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Goals Progress */}
        <div className="arx-card p-5 col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold flex items-center gap-2">
              <Target size={16} className="text-arx-accent" /> Active Goals
            </h2>
            <Link href="/goals" className="text-xs text-arx-text-muted hover:text-arx-accent flex items-center gap-1">
              View all <ArrowRight size={12} />
            </Link>
          </div>
          <div className="space-y-3">
            {goals.slice(0, 5).map((g: any) => (
              <div key={g.id}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="truncate pr-4">{g.title}</span>
                  <span className="text-arx-text-muted flex-shrink-0">{g.progress}%</span>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: `${g.progress}%` }} />
                </div>
              </div>
            ))}
            {goals.length === 0 && (
              <div className="text-center py-4 text-arx-text-muted text-sm">
                No active goals yet.{" "}
                <Link href="/goals" className="text-arx-accent">Create one →</Link>
              </div>
            )}
          </div>
        </div>

        {/* Streaks */}
        <div className="arx-card p-5">
          <h2 className="font-semibold flex items-center gap-2 mb-4">
            <Flame size={16} className="text-arx-warning" /> Top Streaks
          </h2>
          <div className="space-y-3">
            {(dash?.top_streaks || []).map((s: any, i: number) => (
              <div key={i} className="flex items-center gap-3">
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold"
                  style={{ background: s.color + "22", color: s.color }}
                >
                  {s.streak}
                </div>
                <div>
                  <div className="text-sm font-medium truncate">{s.title}</div>
                  <div className="text-xs text-arx-text-muted">{s.streak} day streak</div>
                </div>
              </div>
            ))}
            {(!dash?.top_streaks || dash.top_streaks.length === 0) && (
              <div className="text-center py-4 text-arx-text-muted text-sm">
                <Link href="/habits" className="text-arx-accent">Start a habit →</Link>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Today's Habits */}
      <div className="arx-card p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold flex items-center gap-2">
            <Zap size={16} className="text-arx-highlight" /> Today's Habits
          </h2>
          <div className="text-xs text-arx-text-muted">
            {habitsCompleted}/{habitsTotal} complete
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {todayHabits.map((h: any) => (
            <div
              key={h.id}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl border text-sm transition-all"
              style={{
                borderColor: h.completed_today ? h.color || "#6c63ff" : "#1e1e2e",
                background: h.completed_today ? (h.color || "#6c63ff") + "18" : "transparent",
                color: h.completed_today ? h.color || "#6c63ff" : "#6b6b8a",
              }}
            >
              <div
                className="w-2 h-2 rounded-full"
                style={{ background: h.completed_today ? h.color || "#6c63ff" : "#2a2a3e" }}
              />
              {h.title}
              {h.streak_current > 0 && (
                <span className="text-xs opacity-70">🔥{h.streak_current}</span>
              )}
            </div>
          ))}
          {todayHabits.length === 0 && (
            <p className="text-arx-text-muted text-sm">
              No habits tracked.{" "}
              <Link href="/habits" className="text-arx-accent">Set up habits →</Link>
            </p>
          )}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { href: "/chat", icon: MessageSquare, label: "New Chat", color: "#6c63ff" },
          { href: "/reflection", icon: Brain, label: "Reflect", color: "#00d4aa" },
          { href: "/reports", icon: TrendingUp, label: "Weekly Report", color: "#ffa502" },
          { href: "/learning", icon: BookOpen, label: "Log Learning", color: "#2ed573" },
        ].map(({ href, icon: Icon, label, color }) => (
          <Link
            key={href}
            href={href}
            className="arx-card p-4 flex items-center gap-3 hover:border-arx-accent/40 transition-colors group"
          >
            <div className="p-2 rounded-lg" style={{ background: color + "18" }}>
              <Icon size={15} style={{ color }} />
            </div>
            <span className="text-sm font-medium group-hover:text-arx-accent transition-colors">{label}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
