"use client";
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { analyticsAPI } from "@/lib/api";
import { BarChart3, TrendingUp, Sparkles, Calendar, Loader2 } from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis,
  Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";
import ReactMarkdown from "react-markdown";
import { format } from "date-fns";

const TOOLTIP_STYLE = {
  contentStyle: { background: "#111118", border: "1px solid #1e1e2e", borderRadius: 8, fontSize: 12 },
  labelStyle: { color: "#6b6b8a" },
};

export default function ReportsPage() {
  const [period, setPeriod] = useState<"weekly"|"monthly">("weekly");
  const [offset, setOffset] = useState(0);
  const [aiReport, setAiReport] = useState<string | null>(null);

  const { data: weekly } = useQuery({
    queryKey: ["analytics", "weekly", offset],
    queryFn: () => analyticsAPI.getWeekly(offset),
    enabled: period === "weekly",
  });
  const { data: monthly } = useQuery({
    queryKey: ["analytics", "monthly", offset],
    queryFn: () => analyticsAPI.getMonthly(offset),
    enabled: period === "monthly",
  });
  const { data: savedReports = [] } = useQuery({
    queryKey: ["reports", period],
    queryFn: () => analyticsAPI.listReports(period),
  });

  const generateReport = useMutation({
    mutationFn: () => analyticsAPI.generateAIReport(period),
    onSuccess: (data) => setAiReport(data.ai_summary),
  });

  const data = period === "weekly" ? weekly : monthly;
  const habitByDay = data?.habit_by_day || {};

  const habitChartData = Object.entries(habitByDay).map(([date, count]) => ({
    day: format(new Date(date), "EEE"),
    habits: count,
  }));

  const metrics = [
    { label: "Goals Active", value: data?.goals?.active ?? "—", sub: `${data?.goals?.avg_progress?.toFixed(0) ?? 0}% avg progress` },
    { label: "Tasks Done", value: data?.tasks?.completed ?? "—", sub: `${data?.tasks?.completion_rate?.toFixed(0) ?? 0}% completion rate` },
    { label: "Habit Adherence", value: `${data?.habits?.adherence_pct ?? 0}%`, sub: `${data?.habits?.completions ?? 0} completions` },
    { label: "Learning Hours", value: `${data?.learning?.hours ?? 0}h`, sub: `${data?.learning?.items_completed ?? 0} items done` },
  ];

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold flex items-center gap-2">
            <BarChart3 className="text-arx-warning" size={22} /> Reports
          </h1>
          <p className="text-arx-text-muted text-sm mt-0.5">Track your growth over time</p>
        </div>
        <button
          onClick={() => generateReport.mutate()}
          disabled={generateReport.isPending}
          className="arx-btn-primary gap-2"
        >
          {generateReport.isPending
            ? <><Loader2 size={14} className="animate-spin" /> Generating…</>
            : <><Sparkles size={14} /> AI Report</>
          }
        </button>
      </div>

      {/* Period selector */}
      <div className="flex items-center gap-4">
        <div className="flex gap-1 bg-arx-muted rounded-xl p-1">
          {(["weekly","monthly"] as const).map(p => (
            <button key={p} onClick={() => { setPeriod(p); setOffset(0); }}
              className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
                period === p ? "bg-arx-surface text-arx-text shadow-sm" : "text-arx-text-muted hover:text-arx-text"
              }`}>
              {p.charAt(0).toUpperCase() + p.slice(1)}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => setOffset(o => o + 1)} className="arx-btn-ghost px-2 py-1 text-xs">← Prev</button>
          <span className="text-xs text-arx-text-muted px-2">{offset === 0 ? "Current" : `${offset} ${period === "weekly" ? "week" : "month"}s ago`}</span>
          <button onClick={() => setOffset(o => Math.max(0, o - 1))} disabled={offset === 0}
            className="arx-btn-ghost px-2 py-1 text-xs disabled:opacity-30">Next →</button>
        </div>
      </div>

      {/* Metrics grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {metrics.map(m => (
          <div key={m.label} className="arx-card p-4">
            <div className="text-2xl font-bold font-display">{m.value}</div>
            <div className="text-xs text-arx-text-muted mt-0.5">{m.label}</div>
            <div className="text-xs text-arx-highlight mt-1">{m.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Habit chart */}
        <div className="arx-card p-5">
          <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
            <TrendingUp size={15} className="text-arx-highlight" /> Habit Completions
          </h3>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={habitChartData} barSize={20}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e1e2e" />
              <XAxis dataKey="day" tick={{ fill: "#6b6b8a", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#6b6b8a", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip {...TOOLTIP_STYLE} />
              <Bar dataKey="habits" fill="#6c63ff" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Stats breakdown */}
        <div className="arx-card p-5 space-y-3">
          <h3 className="font-semibold text-sm mb-4">Period Breakdown</h3>
          {[
            { label: "Tasks Completion Rate", pct: data?.tasks?.completion_rate ?? 0, color: "#6c63ff" },
            { label: "Habit Adherence", pct: data?.habits?.adherence_pct ?? 0, color: "#00d4aa" },
            { label: "Goal Progress (avg)", pct: data?.goals?.avg_progress ?? 0, color: "#ffa502" },
          ].map(item => (
            <div key={item.label}>
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-arx-text-muted">{item.label}</span>
                <span className="font-medium">{item.pct.toFixed(0)}%</span>
              </div>
              <div className="progress-bar h-2">
                <div className="h-full rounded-full transition-all duration-700"
                  style={{ width: `${Math.min(item.pct, 100)}%`, background: item.color }} />
              </div>
            </div>
          ))}
          {data && (
            <div className="pt-2 border-t border-arx-border text-xs text-arx-text-muted">
              Period: {data.period?.start} → {data.period?.end} ({data.period?.days} days)
            </div>
          )}
        </div>
      </div>

      {/* AI Report */}
      {aiReport && (
        <div className="arx-card p-6 border-arx-accent/30">
          <h3 className="font-semibold flex items-center gap-2 mb-4">
            <Sparkles size={15} className="text-arx-accent" /> AI-Generated Report
          </h3>
          <div className="prose-arx text-sm">
            <ReactMarkdown>{aiReport}</ReactMarkdown>
          </div>
        </div>
      )}

      {/* Saved reports */}
      {(savedReports as any[]).length > 0 && (
        <div>
          <h3 className="font-semibold text-sm mb-3 text-arx-text-muted">Past Reports</h3>
          <div className="space-y-2">
            {(savedReports as any[]).map(r => (
              <div key={r.id} className="arx-card p-4 flex items-center justify-between">
                <div>
                  <div className="font-medium text-sm">{r.title}</div>
                  <div className="text-xs text-arx-text-muted mt-0.5">
                    <Calendar size={10} className="inline mr-1" />
                    {r.period_start} → {r.period_end}
                  </div>
                </div>
                {r.ai_summary && (
                  <button
                    onClick={() => setAiReport(r.ai_summary)}
                    className="text-xs text-arx-accent hover:underline"
                  >
                    View →
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
