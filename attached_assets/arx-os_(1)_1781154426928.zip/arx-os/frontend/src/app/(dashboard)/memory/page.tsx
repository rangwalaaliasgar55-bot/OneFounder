"use client";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { memoryAPI } from "@/lib/api";
import { Brain, Search, Plus, Trash2 } from "lucide-react";
import type { Memory, MemoryType } from "@/types";
import { format } from "date-fns";
import { clsx } from "clsx";

const TYPE_COLORS: Record<string, string> = {
  episodic: "#6c63ff", semantic: "#00d4aa",
  procedural: "#ffa502", reflection: "#fd79a8",
};

export default function MemoryPage() {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [filter, setFilter] = useState<MemoryType | "all">("all");
  const [showCreate, setShowCreate] = useState(false);
  const [newMem, setNewMem] = useState({ content: "", memory_type: "semantic" as MemoryType, title: "" });

  const { data: memories = [] } = useQuery({
    queryKey: ["memories", filter],
    queryFn: () => memoryAPI.list(filter === "all" ? undefined : filter),
  });
  const { data: stats } = useQuery({ queryKey: ["memory-stats"], queryFn: memoryAPI.getStats });

  const searchMutation = useMutation({
    mutationFn: () => memoryAPI.search(search, filter === "all" ? undefined : [filter]),
    onSuccess: (d) => setSearchResults(d.results),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => memoryAPI.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["memories"] }); },
  });

  const createMutation = useMutation({
    mutationFn: () => memoryAPI.create(newMem.content, newMem.memory_type, newMem.title),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["memories"] });
      setShowCreate(false);
      setNewMem({ content: "", memory_type: "semantic", title: "" });
    },
  });

  const displayMems = searchResults.length > 0
    ? searchResults.map(r => ({ id: r.id, ...r.payload, score: r.score }))
    : memories;

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold flex items-center gap-2">
            <Brain className="text-arx-highlight" size={22} /> Memory
          </h1>
          <p className="text-arx-text-muted text-sm">{stats?.total_memories ?? 0} total memories</p>
        </div>
        <button onClick={() => setShowCreate(v => !v)} className="arx-btn-primary gap-2">
          <Plus size={15} /> Store Memory
        </button>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-4 gap-3">
          {Object.entries(TYPE_COLORS).map(([type, color]) => (
            <div key={type} className="arx-card p-3 text-center">
              <div className="text-xl font-bold" style={{ color }}>{stats.by_type?.[type] ?? 0}</div>
              <div className="text-xs text-arx-text-muted mt-0.5 capitalize">{type}</div>
            </div>
          ))}
        </div>
      )}

      {/* Search */}
      <div className="flex gap-2">
        <input className="arx-input flex-1" placeholder="Semantic search your memories…"
          value={search} onChange={e => { setSearch(e.target.value); if (!e.target.value) setSearchResults([]); }}
          onKeyDown={e => e.key === "Enter" && search && searchMutation.mutate()} />
        <button onClick={() => search && searchMutation.mutate()}
          disabled={searchMutation.isPending || !search} className="arx-btn-primary px-4">
          <Search size={15} />
        </button>
      </div>

      {/* Type filter */}
      <div className="flex gap-1.5 flex-wrap">
        {(["all","episodic","semantic","procedural","reflection"] as const).map(t => (
          <button key={t} onClick={() => { setFilter(t); setSearchResults([]); }}
            className={clsx("px-3 py-1 rounded-lg text-xs font-medium transition-all",
              filter === t ? "text-white" : "bg-arx-muted text-arx-text-muted hover:text-arx-text"
            )}
            style={filter === t ? { background: TYPE_COLORS[t] || "#6c63ff" } : {}}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Create form */}
      {showCreate && (
        <div className="arx-card p-5 space-y-3 animate-slide-down">
          <input className="arx-input" placeholder="Title (optional)"
            value={newMem.title} onChange={e => setNewMem(m => ({ ...m, title: e.target.value }))} />
          <textarea className="arx-input resize-none" rows={3} placeholder="What do you want ARX to remember?"
            value={newMem.content} onChange={e => setNewMem(m => ({ ...m, content: e.target.value }))} />
          <select className="arx-input" value={newMem.memory_type}
            onChange={e => setNewMem(m => ({ ...m, memory_type: e.target.value as MemoryType }))}>
            <option value="semantic">Semantic (facts about you)</option>
            <option value="episodic">Episodic (events/experiences)</option>
            <option value="procedural">Procedural (workflows/habits)</option>
            <option value="reflection">Reflection (lessons/insights)</option>
          </select>
          <div className="flex gap-2 justify-end">
            <button onClick={() => setShowCreate(false)} className="arx-btn-ghost">Cancel</button>
            <button onClick={() => createMutation.mutate()}
              disabled={!newMem.content || createMutation.isPending} className="arx-btn-primary">
              Store
            </button>
          </div>
        </div>
      )}

      {/* Memory list */}
      <div className="space-y-2">
        {(displayMems as any[]).map((m: any) => {
          const type = m.memory_type || "semantic";
          const color = TYPE_COLORS[type] || "#6c63ff";
          return (
            <div key={m.id} className="arx-card p-4 hover:border-arx-border/60 transition-colors group">
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full mt-2 flex-shrink-0" style={{ background: color }} />
                <div className="flex-1 min-w-0">
                  {m.title && <div className="font-medium text-sm mb-0.5">{m.title}</div>}
                  <p className="text-arx-text-muted text-sm leading-relaxed line-clamp-3">{m.content}</p>
                  <div className="flex items-center gap-3 mt-2 text-xs text-arx-text-muted/60">
                    <span className="capitalize" style={{ color }}>{type}</span>
                    {m.score && <span>relevance: {(m.score * 100).toFixed(0)}%</span>}
                    {m.created_at && <span>{format(new Date(m.created_at), "MMM d, yyyy")}</span>}
                    {m.importance && <span>importance: {(m.importance * 10).toFixed(0)}/10</span>}
                  </div>
                </div>
                <button onClick={() => deleteMutation.mutate(m.id)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity arx-btn-ghost p-1.5 text-arx-danger/60 hover:text-arx-danger">
                  <Trash2 size={13} />
                </button>
              </div>
            </div>
          );
        })}
        {displayMems.length === 0 && (
          <div className="arx-card p-10 text-center">
            <Brain size={32} className="text-arx-text-muted mx-auto mb-3" />
            <p className="text-arx-text-muted">
              {search ? "No memories match your search." : "No memories yet. Chat with ARX to build your memory."}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
