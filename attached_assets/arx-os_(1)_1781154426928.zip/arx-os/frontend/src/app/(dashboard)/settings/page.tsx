"use client";
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { settingsAPI } from "@/lib/api";
import { useAuthStore } from "@/store";
import { Settings, Shield, Cpu, Database } from "lucide-react";
import toast from "react-hot-toast";

export default function SettingsPage() {
  const { user } = useAuthStore();
  const [pw, setPw] = useState({ current:"", next:"", confirm:"" });
  const { data: health } = useQuery({ queryKey:["health"], queryFn: settingsAPI.health, refetchInterval:15000 });
  const { data: cfg } = useQuery({ queryKey:["settings"], queryFn: settingsAPI.get });
  const changePw = useMutation({
    mutationFn: () => settingsAPI.changePassword(pw.current, pw.next),
    onSuccess: () => { toast.success("Password changed!"); setPw({current:"",next:"",confirm:""}); },
    onError: () => toast.error("Failed — check current password"),
  });
  const Dot = ({ok}:{ok:boolean}) => <div className={`w-2 h-2 rounded-full ${ok?"bg-arx-success":"bg-arx-danger"} animate-pulse`}/>;
  return (
    <div className="p-6 max-w-2xl mx-auto space-y-6 animate-fade-in">
      <h1 className="font-display text-2xl font-bold flex items-center gap-2"><Settings size={22}/> Settings</h1>
      <div className="arx-card p-5 space-y-3">
        <h2 className="font-semibold flex items-center gap-2"><Cpu size={15} className="text-arx-accent"/> System Status</h2>
        {[{l:"API Backend",ok:!!health},{l:"Ollama LLM",ok:health?.ollama},{l:"Qdrant Vector DB",ok:health?.qdrant}].map(s=>(
          <div key={s.l} className="flex items-center justify-between py-2 border-b border-arx-border last:border-0">
            <span className="text-sm">{s.l}</span>
            <div className="flex items-center gap-2"><Dot ok={!!s.ok}/><span className={`text-xs ${s.ok?"text-arx-success":"text-arx-danger"}`}>{s.ok?"Online":"Offline"}</span></div>
          </div>
        ))}
        {cfg?.ollama && <p className="text-xs text-arx-text-muted pt-1">Model: <span className="text-arx-accent font-mono">{cfg.ollama.current_model}</span> · Available: {cfg.ollama.available_models?.join(", ")||"none"}</p>}
      </div>
      <div className="arx-card p-5 space-y-4">
        <h2 className="font-semibold flex items-center gap-2"><Shield size={15} className="text-arx-warning"/> Security</h2>
        <p className="text-sm text-arx-text-muted">Signed in as <span className="text-arx-text font-medium">{user?.username}</span></p>
        {[{l:"Current Password",k:"current"},{l:"New Password",k:"next"},{l:"Confirm New",k:"confirm"}].map(f=>(
          <div key={f.k}><label className="arx-label">{f.l}</label>
            <input type="password" className="arx-input" value={(pw as any)[f.k]} onChange={e=>setPw(p=>({...p,[f.k]:e.target.value}))}/>
          </div>
        ))}
        <button onClick={()=>{if(pw.next!==pw.confirm){toast.error("Passwords don't match");return;}changePw.mutate();}}
          disabled={!pw.current||!pw.next||changePw.isPending} className="arx-btn-primary">
          {changePw.isPending?"Changing…":"Change Password"}
        </button>
      </div>
      <div className="arx-card p-5">
        <h2 className="font-semibold flex items-center gap-2 mb-3"><Database size={15} className="text-arx-highlight"/> Storage</h2>
        <div className="space-y-1 text-sm text-arx-text-muted">
          <p>✓ PostgreSQL — conversations, goals, habits, learning, finance</p>
          <p>✓ Qdrant — vector embeddings for semantic memory search</p>
          <p>✓ Local filesystem — audio files, logs, exports</p>
          <p className="text-xs mt-3 text-arx-success">All data is 100% local. Nothing leaves your machine.</p>
        </div>
      </div>
    </div>
  );
}
