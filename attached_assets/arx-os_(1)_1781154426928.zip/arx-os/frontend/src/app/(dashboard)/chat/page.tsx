"use client";
import { useState, useEffect, useRef, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { chatAPI, voiceAPI } from "@/lib/api";
import { useChatStore, useAuthStore } from "@/store";
import { getAccessToken } from "@/lib/api";
import ReactMarkdown from "react-markdown";
import toast from "react-hot-toast";
import {
  Send, Mic, MicOff, Plus, Trash2, Bot, User,
  ChevronDown, Sparkles, Brain, Briefcase, Rocket,
  Zap, BookOpen, Search, Lightbulb,
} from "lucide-react";
import { format } from "date-fns";
import { clsx } from "clsx";

const AGENTS = [
  { id: "master",       label: "ARX",          icon: Sparkles,   color: "#6c63ff" },
  { id: "career",       label: "Career",        icon: Briefcase,  color: "#00d4aa" },
  { id: "startup",      label: "Startup",       icon: Rocket,     color: "#ffa502" },
  { id: "learning",     label: "Learning",      icon: BookOpen,   color: "#2ed573" },
  { id: "productivity", label: "Productivity",  icon: Zap,        color: "#ff6b6b" },
  { id: "research",     label: "Research",      icon: Search,     color: "#a29bfe" },
  { id: "reflection",   label: "Reflect",       icon: Lightbulb,  color: "#fd79a8" },
  { id: "memory",       label: "Memory",        icon: Brain,      color: "#74b9ff" },
];

function TypingIndicator() {
  return (
    <div className="flex gap-1.5 px-4 py-3 chat-message-ai w-fit">
      {[0, 1, 2].map(i => (
        <span
          key={i}
          className="w-1.5 h-1.5 bg-arx-text-muted rounded-full animate-bounce"
          style={{ animationDelay: `${i * 0.15}s` }}
        />
      ))}
    </div>
  );
}

export default function ChatPage() {
  const qc = useQueryClient();
  const { user } = useAuthStore();
  const {
    conversations, activeConversationId, messages, isStreaming, streamingContent, agentType,
    setConversations, setActiveConversation, setMessages, appendMessage,
    setStreaming, appendStreamChunk, clearStream, setAgentType,
  } = useChatStore();

  const [input, setInput] = useState("");
  const [recording, setRecording] = useState(false);
  const [showAgents, setShowAgents] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  // Load conversations
  const { data: convData } = useQuery({
    queryKey: ["conversations"],
    queryFn: chatAPI.listConversations,
  });

  useEffect(() => {
    if (convData) setConversations(convData);
  }, [convData]);

  // Load messages when conversation changes
  useEffect(() => {
    if (!activeConversationId) return;
    chatAPI.getMessages(activeConversationId).then(setMessages).catch(() => {});
  }, [activeConversationId]);

  // Auto-scroll
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, streamingContent]);

  const startNewConversation = async () => {
    const conv = await chatAPI.createConversation(agentType);
    setActiveConversation(conv.id);
    setMessages([]);
    qc.invalidateQueries({ queryKey: ["conversations"] });
  };

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim() || isStreaming) return;

    let convId = activeConversationId;
    if (!convId) {
      const conv = await chatAPI.createConversation(agentType);
      convId = conv.id;
      setActiveConversation(convId);
      qc.invalidateQueries({ queryKey: ["conversations"] });
    }

    // Optimistically add user message
    const userMsg = {
      id: Date.now().toString(),
      role: "user" as const,
      content: text,
      created_at: new Date().toISOString(),
    };
    appendMessage(userMsg);
    setInput("");
    setStreaming(true);
    clearStream();

    // Open WebSocket
    if (wsRef.current?.readyState === WebSocket.OPEN) wsRef.current.close();

    const ws = new WebSocket(chatAPI.getWsUrl(convId));
    wsRef.current = ws;

    ws.onopen = () => {
      ws.send(JSON.stringify({
        token: getAccessToken(),
        message: text,
        agent_type: agentType,
      }));
    };

    ws.onmessage = (e) => {
      const data = JSON.parse(e.data);
      if (data.type === "chunk") {
        appendStreamChunk(data.content);
      } else if (data.type === "done") {
        setStreaming(false);
        // Reload messages to get persisted version
        chatAPI.getMessages(convId!).then(setMessages);
        clearStream();
        qc.invalidateQueries({ queryKey: ["conversations"] });
      } else if (data.type === "error") {
        toast.error(data.detail || "Stream error");
        setStreaming(false);
        clearStream();
      }
    };

    ws.onerror = () => {
      toast.error("Connection error — check that the backend is running");
      setStreaming(false);
      clearStream();
    };
  }, [activeConversationId, agentType, isStreaming]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  // Voice recording
  const toggleRecording = async () => {
    if (recording) {
      recorderRef.current?.stop();
      setRecording(false);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = e => chunksRef.current.push(e.data);
      recorder.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        try {
          const { text } = await voiceAPI.transcribe(blob);
          if (text) setInput(text);
        } catch {
          toast.error("Transcription failed");
        }
        stream.getTracks().forEach(t => t.stop());
      };
      recorder.start();
      recorderRef.current = recorder;
      setRecording(true);
    } catch {
      toast.error("Microphone access denied");
    }
  };

  const activeAgent = AGENTS.find(a => a.id === agentType) || AGENTS[0];

  return (
    <div className="flex h-screen">
      {/* Conversation List */}
      <div className="w-56 border-r border-arx-border bg-arx-surface flex flex-col flex-shrink-0">
        <div className="p-3 border-b border-arx-border">
          <button onClick={startNewConversation} className="arx-btn-primary w-full justify-center gap-2 text-xs py-2">
            <Plus size={13} /> New Chat
          </button>
        </div>
        <div className="flex-1 overflow-y-auto py-2 px-2 space-y-0.5">
          {conversations.map(c => (
            <button
              key={c.id}
              onClick={() => setActiveConversation(c.id)}
              className={clsx(
                "w-full text-left px-3 py-2 rounded-lg text-xs transition-all group",
                activeConversationId === c.id
                  ? "bg-arx-accent/15 text-arx-accent"
                  : "text-arx-text-muted hover:bg-arx-muted hover:text-arx-text"
              )}
            >
              <div className="truncate font-medium">{c.title || "New conversation"}</div>
              <div className="text-arx-text-muted/60 mt-0.5">{format(new Date(c.updated_at), "MMM d")}</div>
            </button>
          ))}
          {conversations.length === 0 && (
            <p className="text-center text-arx-text-muted text-xs py-6">No conversations yet</p>
          )}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <div className="border-b border-arx-border px-4 py-3 flex items-center gap-3 bg-arx-surface">
          {/* Agent selector */}
          <div className="relative">
            <button
              onClick={() => setShowAgents(v => !v)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-arx-muted text-sm hover:bg-arx-border transition-colors"
            >
              <activeAgent.icon size={14} style={{ color: activeAgent.color }} />
              <span>{activeAgent.label}</span>
              <ChevronDown size={12} className="text-arx-text-muted" />
            </button>
            {showAgents && (
              <div className="absolute top-full left-0 mt-1 bg-arx-surface border border-arx-border rounded-xl p-1.5 z-50 grid grid-cols-2 gap-0.5 w-56 shadow-2xl">
                {AGENTS.map(a => (
                  <button
                    key={a.id}
                    onClick={() => { setAgentType(a.id); setShowAgents(false); }}
                    className={clsx(
                      "flex items-center gap-2 px-2.5 py-2 rounded-lg text-xs transition-all text-left",
                      agentType === a.id ? "bg-arx-accent/15 text-arx-accent" : "hover:bg-arx-muted text-arx-text-muted"
                    )}
                  >
                    <a.icon size={12} style={{ color: a.color }} />
                    {a.label}
                  </button>
                ))}
              </div>
            )}
          </div>
          <span className="text-arx-text-muted text-xs">
            {activeConversationId
              ? conversations.find(c => c.id === activeConversationId)?.title || "New conversation"
              : "Select or start a conversation"}
          </span>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 && !isStreaming && (
            <div className="flex flex-col items-center justify-center h-full text-center gap-4 pb-20">
              <div className="w-14 h-14 rounded-2xl bg-arx-gradient flex items-center justify-center glow-accent">
                <Sparkles size={22} className="text-white" />
              </div>
              <div>
                <h2 className="font-display text-xl font-bold gradient-text">ARX is ready</h2>
                <p className="text-arx-text-muted text-sm mt-1">Ask anything. I remember everything about you.</p>
              </div>
              <div className="grid grid-cols-2 gap-2 mt-2 w-full max-w-sm">
                {[
                  "What should I focus on this week?",
                  "Analyze my career progress",
                  "Evaluate my startup idea",
                  "Create a learning plan",
                ].map(q => (
                  <button
                    key={q}
                    onClick={() => sendMessage(q)}
                    className="arx-card p-3 text-left text-xs hover:border-arx-accent/40 transition-colors"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map(msg => (
            <div key={msg.id} className={clsx("flex gap-3", msg.role === "user" ? "flex-row-reverse" : "flex-row")}>
              <div className={clsx(
                "w-7 h-7 rounded-lg flex-shrink-0 flex items-center justify-center text-xs mt-1",
                msg.role === "user" ? "bg-arx-accent/20" : "bg-arx-gradient"
              )}>
                {msg.role === "user"
                  ? <User size={13} className="text-arx-accent" />
                  : <Sparkles size={12} className="text-white" />
                }
              </div>
              <div className={msg.role === "user" ? "chat-message-user" : "chat-message-ai"}>
                {msg.role === "assistant"
                  ? <div className="prose-arx text-sm"><ReactMarkdown>{msg.content}</ReactMarkdown></div>
                  : <p className="text-sm">{msg.content}</p>
                }
                <div className="text-arx-text-muted/50 text-xs mt-1.5">
                  {format(new Date(msg.created_at), "HH:mm")}
                </div>
              </div>
            </div>
          ))}

          {/* Streaming response */}
          {isStreaming && (
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-lg bg-arx-gradient flex-shrink-0 flex items-center justify-center animate-pulse-glow mt-1">
                <Sparkles size={12} className="text-white" />
              </div>
              <div className="chat-message-ai">
                {streamingContent
                  ? <div className="prose-arx text-sm"><ReactMarkdown>{streamingContent}</ReactMarkdown></div>
                  : <TypingIndicator />
                }
              </div>
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div className="border-t border-arx-border p-4 bg-arx-surface">
          <div className="flex gap-2 items-end">
            <div className="flex-1 relative">
              <textarea
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={`Message ${activeAgent.label}… (Enter to send, Shift+Enter for newline)`}
                rows={1}
                disabled={isStreaming}
                className="arx-input resize-none min-h-[44px] max-h-32 py-3 pr-4 leading-snug"
                style={{ height: "auto" }}
                onInput={e => {
                  const t = e.currentTarget;
                  t.style.height = "auto";
                  t.style.height = Math.min(t.scrollHeight, 128) + "px";
                }}
              />
            </div>
            <button
              onClick={toggleRecording}
              className={clsx("arx-btn h-11 w-11 justify-center", recording ? "arx-btn-danger" : "arx-btn-ghost")}
            >
              {recording ? <MicOff size={16} /> : <Mic size={16} />}
            </button>
            <button
              onClick={() => sendMessage(input)}
              disabled={!input.trim() || isStreaming}
              className="arx-btn-primary h-11 w-11 justify-center disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Send size={15} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
