// ═══════════════════════════════════════════════════════════
// ARX OS — Zustand Global Store
// ═══════════════════════════════════════════════════════════
import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { User, Conversation, Message } from "@/types";

// ─── Auth Store ───────────────────────────────────────────

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  setUser: (user: User | null) => void;
  setLoading: (v: boolean) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      isLoading: true,
      setUser: (user) => set({ user, isAuthenticated: !!user, isLoading: false }),
      setLoading: (isLoading) => set({ isLoading }),
      logout: () => {
        set({ user: null, isAuthenticated: false });
        localStorage.removeItem("arx_access_token");
        localStorage.removeItem("arx_refresh_token");
        window.location.href = "/login";
      },
    }),
    {
      name: "arx-auth",
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
    }
  )
);

// ─── Chat Store ───────────────────────────────────────────

interface ChatState {
  conversations: Conversation[];
  activeConversationId: string | null;
  messages: Message[];
  isStreaming: boolean;
  streamingContent: string;
  agentType: string;
  setConversations: (convs: Conversation[]) => void;
  setActiveConversation: (id: string | null) => void;
  setMessages: (msgs: Message[]) => void;
  appendMessage: (msg: Message) => void;
  setStreaming: (v: boolean) => void;
  appendStreamChunk: (chunk: string) => void;
  clearStream: () => void;
  setAgentType: (type: string) => void;
}

export const useChatStore = create<ChatState>((set) => ({
  conversations: [],
  activeConversationId: null,
  messages: [],
  isStreaming: false,
  streamingContent: "",
  agentType: "master",
  setConversations: (conversations) => set({ conversations }),
  setActiveConversation: (activeConversationId) => set({ activeConversationId }),
  setMessages: (messages) => set({ messages }),
  appendMessage: (msg) => set((s) => ({ messages: [...s.messages, msg] })),
  setStreaming: (isStreaming) => set({ isStreaming }),
  appendStreamChunk: (chunk) => set((s) => ({ streamingContent: s.streamingContent + chunk })),
  clearStream: () => set({ streamingContent: "" }),
  setAgentType: (agentType) => set({ agentType }),
}));

// ─── UI Store ─────────────────────────────────────────────

interface UIState {
  sidebarCollapsed: boolean;
  theme: "dark" | "light";
  activePanel: string | null;
  notifications: Notification[];
  toggleSidebar: () => void;
  setTheme: (theme: "dark" | "light") => void;
  setActivePanel: (panel: string | null) => void;
  addNotification: (n: Omit<Notification, "id">) => void;
  removeNotification: (id: string) => void;
}

interface Notification {
  id: string;
  type: "success" | "error" | "info" | "warning";
  title: string;
  message?: string;
}

export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      sidebarCollapsed: false,
      theme: "dark",
      activePanel: null,
      notifications: [],
      toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
      setTheme: (theme) => set({ theme }),
      setActivePanel: (activePanel) => set({ activePanel }),
      addNotification: (n) =>
        set((s) => ({
          notifications: [...s.notifications, { ...n, id: Date.now().toString() }],
        })),
      removeNotification: (id) =>
        set((s) => ({ notifications: s.notifications.filter((n) => n.id !== id) })),
    }),
    { name: "arx-ui", partialize: (s) => ({ sidebarCollapsed: s.sidebarCollapsed, theme: s.theme }) }
  )
);
