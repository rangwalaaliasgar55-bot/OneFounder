"use client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "react-hot-toast";
import { useEffect, useState } from "react";
import { useAuthStore } from "@/store";
import { authAPI } from "@/lib/api";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { staleTime: 30_000, retry: 1 },
  },
});

function AuthInit({ children }: { children: React.ReactNode }) {
  const { setUser, setLoading } = useAuthStore();

  useEffect(() => {
    const token = localStorage.getItem("arx_access_token");
    if (!token) { setLoading(false); return; }
    authAPI.me()
      .then(setUser)
      .catch(() => { setUser(null); setLoading(false); });
  }, []);

  return <>{children}</>;
}

export function Providers({ children }: { children: React.ReactNode }) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return (
    <QueryClientProvider client={queryClient}>
      <AuthInit>
        {mounted && children}
      </AuthInit>
      <Toaster
        position="bottom-right"
        toastOptions={{
          style: {
            background: "#111118",
            color: "#e8e8f0",
            border: "1px solid #1e1e2e",
            borderRadius: "12px",
            fontSize: "14px",
          },
          success: { iconTheme: { primary: "#2ed573", secondary: "#0a0a0f" } },
          error:   { iconTheme: { primary: "#ff4757", secondary: "#0a0a0f" } },
        }}
      />
    </QueryClientProvider>
  );
}
