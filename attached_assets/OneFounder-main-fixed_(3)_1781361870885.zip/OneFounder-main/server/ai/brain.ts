import { detectExpertMode, type ExpertMode, type RouteResult } from './router.js'
import { enhancePrompt } from './promptEnhancer.js'
import { getAIProvider } from './index.js'
import { assembleFounderContext, type FounderContext } from './context.js'
import { extractAndStoreMemories } from './memory.js'
import { extractEntitiesFromConversation } from '../knowledge/entityExtractor.js'
import { getMemoryContextForQuery } from '../memory/memoryRetrieval.js'
import { assembleRAGContext } from '../rag/contextAssembler.js'
import { gatherWebContext, formatWebContextForPrompt } from './webSearch.js'
import { db } from '../db/index.js'
import { chatMessages } from '../db/schema.js'
import { eq, and } from 'drizzle-orm'
import { v4 as uuidv4 } from 'uuid'

export interface BrainRequest {
  userId: string
  message: string
  sessionId?: string
  forcedMode?: ExpertMode
  useWebSearch?: boolean
  model?: string
}

export interface BrainResponse {
  response: string
  sessionId: string
  mode: ExpertMode
  modeLabel: string
  confidence: 'high' | 'medium' | 'low'
  detectedKeywords: string[]
  webSearchUsed: boolean
}

export interface BrainStreamChunk {
  type: 'mode' | 'token' | 'done' | 'error'
  data: string | Partial<BrainResponse>
}

const MODE_LABELS: Record<ExpertMode, string> = {
  code: '💻 Engineering Agent',
  seo: '🔍 SEO Command Center',
  security: '🔒 Security Agent',
  data: '📊 Data Agent',
  research: '🔬 Deep Research Engine',
  finance: '💰 Finance Agent',
  product: '🧩 Product Agent',
  startup: '🚀 Founder Agent',
  founder: '⚡ OneFounder Supreme',
  marketing: '📣 Marketing Agent',
  sales: '💼 Sales Agent',
  devops: '☁️ DevOps Agent',
  legal: '⚖️ Legal Ops Agent',
}

function formatContext(ctx: FounderContext): string {
  return [
    `Founder Stage: ${ctx.stage} | Industry: ${ctx.industry} | Goal: ${ctx.goals}`,
    `Business Snapshot:\n${ctx.businessSnapshot}`,
    `Financial Context: ${ctx.financialContext}`,
    ctx.urgentItems !== 'No urgent items flagged' ? `Urgent Items:\n${ctx.urgentItems}` : '',
    `Persistent Memories:\n${ctx.memories}`,
    `Recent Activity: ${ctx.recentActivity}`,
  ].filter(Boolean).join('\n\n')
}

export class OneFounderBrain {
  async process(req: BrainRequest): Promise<BrainResponse> {
    const session = req.sessionId || uuidv4()

    await db.insert(chatMessages).values({
      userId: req.userId,
      sessionId: session,
      role: 'user',
      content: req.message,
      model: 'brain',
    })

    const route = req.forcedMode
      ? { mode: req.forcedMode, confidence: 'high' as const, detectedKeywords: [] }
      : detectExpertMode(req.message)

    // Build context in parallel: founder context, memory retrieval, RAG
    let founderContext: string | undefined
    let memoryContext = ''
    let ragContext = ''

    try {
      const [ctx, memCtx, ragCtx] = await Promise.all([
        assembleFounderContext(req.userId).catch(() => null),
        getMemoryContextForQuery(req.userId, req.message).catch(() => ''),
        assembleRAGContext(req.userId, req.message).catch(() => ''),
      ])
      if (ctx) founderContext = formatContext(ctx)
      memoryContext = memCtx
      ragContext = ragCtx
    } catch {}

    const { systemPrompt, enhancedMessage } = enhancePrompt(req.message, route.mode, founderContext)

    let finalSystemPrompt = systemPrompt
    if (memoryContext) finalSystemPrompt += `\n\n${memoryContext}`
    if (ragContext) finalSystemPrompt += `\n\n${ragContext}`

    let webSearchUsed = false

    const shouldSearchWeb = req.useWebSearch !== false && (
      route.mode === 'research' ||
      route.mode === 'seo' ||
      route.mode === 'startup' ||
      /\b(trend|news|recent|latest|current|competitor|market|industry)\b/i.test(req.message)
    )

    if (shouldSearchWeb) {
      try {
        const webCtx = await gatherWebContext(req.message)
        if (webCtx.results.length > 0 || webCtx.news.length > 0) {
          finalSystemPrompt = finalSystemPrompt + '\n\n' + formatWebContextForPrompt(webCtx)
          webSearchUsed = true
        }
      } catch {}
    }

    const history = await db.select().from(chatMessages)
      .where(and(eq(chatMessages.userId, req.userId), eq(chatMessages.sessionId, session)))
      .orderBy(chatMessages.createdAt)

    const messages = [
      { role: 'system' as const, content: finalSystemPrompt },
      ...history.map(m => ({ role: m.role as 'user' | 'assistant', content: m.content })),
    ]

    const lastUserMsg = messages[messages.length - 1]
    if (lastUserMsg?.role === 'user') {
      lastUserMsg.content = enhancedMessage
    }

    const ai = await getAIProvider()
    const response = await ai.chat(messages)

    await db.insert(chatMessages).values({
      userId: req.userId,
      sessionId: session,
      role: 'assistant',
      content: response,
      model: `brain:${route.mode}`,
    })

    // Fire-and-forget memory + entity extraction
    extractAndStoreMemories(req.userId, req.message, response, `brain:${route.mode}`).catch(() => {})
    extractEntitiesFromConversation(req.userId, req.message, response).catch(() => {})

    return {
      response,
      sessionId: session,
      mode: route.mode,
      modeLabel: MODE_LABELS[route.mode],
      confidence: route.confidence,
      detectedKeywords: route.detectedKeywords,
      webSearchUsed,
    }
  }

  async *stream(req: BrainRequest): AsyncGenerator<BrainStreamChunk> {
    const session = req.sessionId || uuidv4()

    await db.insert(chatMessages).values({
      userId: req.userId,
      sessionId: session,
      role: 'user',
      content: req.message,
      model: 'brain',
    }).catch(() => {})

    const route = req.forcedMode
      ? { mode: req.forcedMode, confidence: 'high' as const, detectedKeywords: [] }
      : detectExpertMode(req.message)

    yield { type: 'mode', data: JSON.stringify({ mode: route.mode, modeLabel: MODE_LABELS[route.mode], sessionId: session }) }

    // Build all context in parallel before responding
    let founderContext: string | undefined
    let memoryContext = ''
    let ragContext = ''

    try {
      const [ctx, memCtx, ragCtx] = await Promise.all([
        assembleFounderContext(req.userId).catch(() => null),
        getMemoryContextForQuery(req.userId, req.message).catch(() => ''),
        assembleRAGContext(req.userId, req.message).catch(() => ''),
      ])
      if (ctx) founderContext = formatContext(ctx)
      memoryContext = memCtx
      ragContext = ragCtx
    } catch {}

    const { systemPrompt, enhancedMessage } = enhancePrompt(req.message, route.mode, founderContext)

    let finalSystemPrompt = systemPrompt
    if (memoryContext) finalSystemPrompt += `\n\n${memoryContext}`
    if (ragContext) finalSystemPrompt += `\n\n${ragContext}`

    let webSearchUsed = false

    const shouldSearchWeb = req.useWebSearch !== false && (
      route.mode === 'research' || route.mode === 'seo' || route.mode === 'startup' ||
      /\b(trend|news|recent|latest|competitor|market)\b/i.test(req.message)
    )

    if (shouldSearchWeb) {
      try {
        const webCtx = await gatherWebContext(req.message)
        if (webCtx.results.length > 0 || webCtx.news.length > 0) {
          finalSystemPrompt = finalSystemPrompt + '\n\n' + formatWebContextForPrompt(webCtx)
          webSearchUsed = true
        }
      } catch {}
    }

    const history = await db.select().from(chatMessages)
      .where(and(eq(chatMessages.userId, req.userId), eq(chatMessages.sessionId, session)))
      .orderBy(chatMessages.createdAt)

    const messages = [
      { role: 'system' as const, content: finalSystemPrompt },
      ...history.map(m => ({ role: m.role as 'user' | 'assistant', content: m.content })),
    ]

    const lastUserMsg = messages[messages.length - 1]
    if (lastUserMsg?.role === 'user') {
      lastUserMsg.content = enhancedMessage
    }

    try {
      const ai = await getAIProvider()
      const ollamaBaseUrl = process.env.OLLAMA_BASE_URL || 'http://localhost:11434'
      const ollamaModel = req.model || process.env.OLLAMA_MODEL || 'llama3.2'

      let fullResponse = ''
      let ollamaStreamed = false

      try {
        const streamRes = await fetch(`${ollamaBaseUrl}/api/chat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ model: ollamaModel, messages, stream: true }),
          signal: AbortSignal.timeout(120000),
        })

        if (streamRes.ok && streamRes.body) {
          const reader = streamRes.body.getReader()
          const decoder = new TextDecoder()

          while (true) {
            const { done, value } = await reader.read()
            if (done) break
            const chunk = decoder.decode(value, { stream: true })
            const lines = chunk.split('\n').filter(l => l.trim())
            for (const line of lines) {
              try {
                const parsed = JSON.parse(line)
                const token = parsed.message?.content || ''
                if (token) {
                  fullResponse += token
                  yield { type: 'token', data: token }
                }
              } catch {}
            }
          }
          ollamaStreamed = true
        }
      } catch {
        // Ollama not available — fall through to provider fallback
      }

      if (!ollamaStreamed) {
        const response = await ai.chat(messages)
        fullResponse = response
        for (const word of response.split(' ')) {
          yield { type: 'token', data: word + ' ' }
          await new Promise(r => setTimeout(r, 8))
        }
      }

      await db.insert(chatMessages).values({
        userId: req.userId,
        sessionId: session,
        role: 'assistant',
        content: fullResponse,
        model: `brain:${route.mode}`,
      }).catch(() => {})

      // Fire-and-forget enrichment
      extractAndStoreMemories(req.userId, req.message, fullResponse, `brain:${route.mode}`).catch(() => {})
      extractEntitiesFromConversation(req.userId, req.message, fullResponse).catch(() => {})

      yield {
        type: 'done',
        data: JSON.stringify({
          sessionId: session,
          mode: route.mode,
          modeLabel: MODE_LABELS[route.mode],
          confidence: route.confidence,
          webSearchUsed,
        }),
      }
    } catch (err: any) {
      yield { type: 'error', data: err.message || 'AI request failed' }
    }
  }
}

export const brain = new OneFounderBrain()
