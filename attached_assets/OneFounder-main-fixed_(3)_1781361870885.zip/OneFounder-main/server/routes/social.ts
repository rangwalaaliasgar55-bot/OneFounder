import { Router } from 'express'
import { requireAuth } from '../middleware/auth.js'
import { db } from '../db/index.js'
import { socialPosts } from '../db/schema.js'
import { eq, desc } from 'drizzle-orm'
import { getAIProvider } from '../ai/index.js'

const router = Router()

router.get('/', requireAuth, async (req, res) => {
  const user = (req as any).user
  const posts = await db.select().from(socialPosts)
    .where(eq(socialPosts.userId, user.id))
    .orderBy(desc(socialPosts.createdAt))
  res.json(posts)
})

router.post('/', requireAuth, async (req, res) => {
  const user = (req as any).user
  const { platform, content, hashtags, scheduledAt } = req.body
  const [post] = await db.insert(socialPosts).values({
    userId: user.id,
    platform,
    content,
    hashtags: hashtags || [],
    scheduledAt: scheduledAt ? new Date(scheduledAt) : undefined,
  }).returning()
  res.json(post)
})

router.post('/generate', requireAuth, async (req, res) => {
  const user = (req as any).user
  const { platform, topic, tone, businessContext } = req.body

  const platformGuides: Record<string, string> = {
    linkedin: 'Professional tone, 1300 chars max, storytelling hook, industry insights, 3-5 hashtags',
    twitter: 'Punchy, max 280 chars, conversational, 1-2 hashtags, strong hook',
    instagram: 'Visual-first caption, emojis welcome, 30 hashtags max, call to action',
    tiktok: 'Gen Z friendly, trendy language, 150 chars, viral hook, 5-7 hashtags',
    facebook: 'Conversational, 500 chars, community-focused, question to drive comments',
  }

  const prompt = `Write a ${platform} post about: ${topic}
Tone: ${tone || 'professional and engaging'}
Business context: ${businessContext || 'startup founder sharing insights'}
Platform guide: ${platformGuides[platform] || 'engaging and on-brand'}

Return JSON: { "content": "post text", "hashtags": ["tag1", "tag2"] }`

  try {
    const ai = await getAIProvider()
    const response = await ai.generate(prompt, 'You are a social media expert. Return ONLY valid JSON.')

    let result = { content: '', hashtags: [] as string[] }
    try {
      const jsonMatch = response.match(/\{[\s\S]*\}/)
      if (jsonMatch) result = JSON.parse(jsonMatch[0])
    } catch {
      result = {
        content: `🚀 ${topic}\n\nAs a founder, I've learned that the best solutions come from real problems. Here's what I discovered...\n\n[Add your story here]\n\n#startup #founder #entrepreneurship`,
        hashtags: ['startup', 'founder', 'entrepreneurship'],
      }
    }

    const [post] = await db.insert(socialPosts).values({
      userId: user.id,
      platform: platform as any,
      content: result.content,
      hashtags: result.hashtags,
    }).returning()

    res.json(post)
  } catch (error: any) {
    res.status(500).json({ error: error.message })
  }
})

router.patch('/:id', requireAuth, async (req, res) => {
  const user = (req as any).user
  const [updated] = await db.update(socialPosts)
    .set({ ...req.body, updatedAt: new Date() })
    .where(eq(socialPosts.id, req.params.id as string))
    .returning()
  res.json(updated)
})

router.delete('/:id', requireAuth, async (req, res) => {
  await db.delete(socialPosts).where(eq(socialPosts.id, req.params.id as string))
  res.json({ success: true })
})

export default router
